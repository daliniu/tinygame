----------------------------------------------------------
-- file:	storage/head.lua
-- Author:	page
-- Time:	2015/06/24	11:34
-- Desc:	npc interface for outer
----------------------------------------------------------
--[[
relationship:
head.lua
|--bag.lua
	|--storagebase.lua
		|--item/head.lua
	
]]
require "script/core/storage/bag"