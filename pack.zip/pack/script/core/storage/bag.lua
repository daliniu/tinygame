----------------------------------------------------------
-- file:	bag.lua
-- Author:	page
-- Time:	2015/06/02
-- Desc:	����
----------------------------------------------------------
require "script/core/storage/storagebase"

--data struct 
local TB_STRUCT_BAG_BASE = {

}
--------------------------------)
KGC_BAG_TYPE = class("KGC_BAG_TYPE", KGC_STORAGE_BASE_TYPE, TB_STRUCT_BAG_BASE)
--------------------------------
--function
--------------------------------

function KGC_BAG_TYPE:ctor()	

end

function KGC_BAG_TYPE:OnInit(tbItems)
	
end
-------------------------------------------------------------

