---------------------------------------------------------------
-- file:	playfactory.lua
-- Author:	page
-- Time:	2015/06/23 
-- Desc:	在player之上的一个对象：创建一个player，一个怪物盒子等
--			
---------------------------------------------------------------
require ("script/core/player/monsterbox");
require ("script/core/player/player");

local l_tbMonsterBox = require("script/cfg/monsterbox")
local l_tbMonsterConfig =  require ("script/cfg/monster")
local l_tbCharacterConfig = require("script/cfg/character")
local l_tbCharacterConfigGuide = require("script/cfg/newcharacter")
local l_tbHeroBox = require("script/cfg/client/herobox")

---------------------------------------------------------------
local TB_STRUCT_PLAYER_FACTORY = {
	m_pLogic = nil,
}

KGC_PLAYER_FACTORY_TYPE = class("KGC_PLAYER_FACTORY_TYPE", CLASS_BASE_TYPE, TB_STRUCT_PLAYER_FACTORY)

function KGC_PLAYER_FACTORY_TYPE:getInstance()
	if not KGC_PLAYER_FACTORY_TYPE.m_pLogic then
        KGC_PLAYER_FACTORY_TYPE.m_pLogic = KGC_PLAYER_FACTORY_TYPE.new()
	end
	return KGC_PLAYER_FACTORY_TYPE.m_pLogic
end

function KGC_PLAYER_FACTORY_TYPE:CreatePlayer(playerdata)
 	local player =  KGC_PLAYER_TYPE.new()
	player:init(playerdata)
	return player
end

--@function	: 根据怪物盒子创建一个战斗对象
--@nBoxID	: 怪物盒子的ID
function KGC_PLAYER_FACTORY_TYPE:CreateMonsterBox(nBoxID)
	print("CreateMonsterBox ... ", nBoxID);
	local tbConfig = l_tbMonsterBox[nBoxID]
	if not tbConfig then
		print(string.format("[Error]怪物盒子ID(%s)没有找到", tostring(nBoxID)))
		return nil;
	end
	
	local nType = tbConfig.Type;
	local tbMonsters = tbConfig.Organism
	if not tbMonsters or type(tbMonsters) ~= "table" or #tbMonsters <= 0 then
		print("[Error]怪物数据配置有问题！")
		return nil;
	end
	
	--构造怪物数据
	local enemyData = {}
	enemyData.teamList = {};
	
	for i, id in ipairs(tbMonsters) do
		local nPos = self:GetPosition(nType, i);
		cclog("\t位置(%d), id(%d)", nPos, id)
		if gf_IsValidPos(nPos) then
			local tbNpc = {}
			tbNpc.heroId = id;				--模版ID
			-- tbNpc.level = 1;				--等级
			tbNpc.pos = nPos;				--位置
			table.insert(enemyData.teamList, tbNpc);
		end
	end
	
	-- return enemyData;
	local box = KGC_MONSTER_BOX_TYPE.new();
	box:init(enemyData)
	
	return box;
end

--@function: 怪物在阵上的位置
--@function: 当前第几只怪
function KGC_PLAYER_FACTORY_TYPE:GetPosition(nType, nIndex)
	print("GetPosition: ",  nType, nIndex)
	local nPos = 0;
	if nType == 1 then				-- 和英雄角色一样的站位
		nPos = nIndex + 3;
	elseif nType == 2 then			-- 单一的一个boss
		nPos = 5;
	elseif nType == 3 then			-- 前排有三个旗子
		nPos = nIndex;
	end
	
	return nPos;
end

--@function: 获取玩家所有的英雄(不包括指引用到的英雄)
function KGC_PLAYER_FACTORY_TYPE:GetAllHeros()
	local tbHeros = {};
	for id, tbData in pairs(l_tbCharacterConfig) do
		tbData.heroId = id;
		local hero = KG_HERO_TYPE.new();
		hero:Init(tbData)
		table.insert(tbHeros, hero);
	end
	return tbHeros;
end

--@function: 获取玩家所有的英雄(不包括指引用到的英雄)
function KGC_PLAYER_FACTORY_TYPE:GetFightBg(nBoxID)
	print("RandomFightBg ... ", nBoxID);
	local tbConfig = l_tbMonsterBox[nBoxID]
	if not tbConfig then
		print(string.format("[Error]怪物盒子ID(%s)没有找到", tostring(nBoxID)))
		return nil;
	end
	
	local tbPics = tbConfig.BattlePic;
	return tbPics;
end
------------------------------------------------------------
-- test
function KGC_PLAYER_FACTORY_TYPE:TestCreatePlayer(nID)
	local nID = nID or 1;
	local tbPlayerInfo = {
		[1] = {
			["level"] = 1,
			-- ["bagList"] = {
				-- ["max"] = 100,
				-- ["equipList"] = {
					-- ["1013102"] = {
						-- ["star"] = 0,
						-- ["n2"] = 20,
						-- ["id"] = 10131,
						-- ["n3"] = 111,
						-- ["n4"] = 0,
						-- ["sn"] = 0,
						-- ["a1"] = 2,
						-- ["a2"] = 5,
						-- ["num"] = 1,
						-- ["sa"] = 0,
						-- ["ss"] = 0,
						-- ["a4"] = -1,
						-- ["a3"] = 6,
						-- ["n1"] = 999,
					-- },
					-- ["10135"] = {
						-- ["star"] = 0,
						-- ["n2"] = 0,
						-- ["id"] = 10135,
						-- ["n3"] = 0,
						-- ["n4"] = 0,
						-- ["sn"] = 0,
						-- ["a1"] = 1,
						-- ["a2"] = 0,
						-- ["num"] = 1,
						-- ["sa"] = 0,
						-- ["ss"] = 0,
						-- ["a4"] = -1,
						-- ["a3"] = 0,
						-- ["n1"] = 20,
					-- },
					-- ["1013101"] = {
						-- ["star"] = 0,
						-- ["n2"] = 20,
						-- ["id"] = 10131,
						-- ["n3"] = 111,
						-- ["n4"] = 0,
						-- ["sn"] = 0,
						-- ["a1"] = 2,
						-- ["a2"] = 5,
						-- ["num"] = 1,
						-- ["sa"] = 0,
						-- ["ss"] = 0,
						-- ["a4"] = -1,
						-- ["a3"] = 6,
						-- ["n1"] = 999,
					-- },
					-- ["10141"] = {
						-- ["star"] = 0,
						-- ["n2"] = 20,
						-- ["id"] = 10141,
						-- ["n3"] = 20,
						-- ["n4"] = 20,
						-- ["sn"] = 0,
						-- ["a1"] = 1,
						-- ["a2"] = 1,
						-- ["num"] = 1,
						-- ["sa"] = 0,
						-- ["ss"] = 0,
						-- ["a4"] = 1,
						-- ["a3"] = 1,
						-- ["n1"] = 20,
					-- },
				-- },
				-- ["itemList"] = {
					-- ["16001"] = {
						-- ["num"] = 2,
					-- },
					-- ["15101"] = {
						-- ["num"] = 1,
					-- },
					-- ["19201"] = {
						-- ["num"] = 2,
					-- },
					-- ["16026"] = {
						-- ["num"] = 5,
					-- },
					-- ["16023"] = {
						-- ["num"] = 2,
					-- },
					-- ["16020"] = {
						-- ["num"] = 2,
					-- },
					-- ["16013"] = {
						-- ["num"] = 2,
					-- },
					-- ["16002"] = {
						-- ["num"] = 2,
					-- },
					-- ["15001"] = {
						-- ["num"] = 11,
					-- },
					-- ["16007"] = {
						-- ["num"] = 2,
					-- },
					-- ["15102"] = {
						-- ["num"] = 1,
					-- },
					-- ["17902"] = {
						-- ["num"] = 5,
					-- },
				-- },
			-- },
			-- ["uuid"] = "test039",
			["teamList"] = {
				["10004"] = {
					["level"] = 1,
					["star"] = 1,
					["skillSlotList"] = {
						["4"] = {
							["level"] = 1,
						},
						["1"] = {
							["level"] = 1,
						},
						["5"] = {
							["level"] = 1,
						},
						["2"] = {
							["level"] = 1,
						},
						["6"] = {
							["level"] = 1,
						},
					 ["3"] = {
							["level"] = 1,
						},
					},
					["suitId2"] = 18,
					["heroId"] = 10004,
					["suitId1"] = 20,
					["pos"] = 4,
					["suitId3"] = 18,
					["quality"] = 1,
					["suitId4"] = 18,
					["curExp"] = 0,
					["suitId5"] = 18,
				},
				["10006"] = {
					["level"] = 1,
					["star"] = 1,
					["skillSlotList"] = {
						["4"] = {
							["level"] = 1,
						},
						["1"] = {
							["level"] = 1,
						},
						["5"] = {
							["level"] = 1,
						},
						["2"] = {
							["level"] = 1,
						},
						["6"] = {
							["level"] = 1,
						},
						["3"] = {
							["level"] = 1,
						},
					},
					["suitId2"] = 30,
					["heroId"] = 10006,
					["suitId1"] = 30,
					["pos"] = 6,
					["suitId3"] = 28,
					["quality"] = 1,
					["suitId4"] = 27,
					["curExp"] = 0,
					["suitId5"] = 26,
				},
				["10005"] = {
					["level"] = 1,
					["star"] = 1,
					["skillSlotList"] = {
						["4"] = {
							["level"] = 1,
						},
						["1"] = {
							["level"] = 1,
						},
						["5"] = {
							["level"] = 1,
						},
						["2"] = {
							["level"] = 1,
						},
						["6"] = {
							["level"] = 1,
						},
						["3"] = {
							["level"] = 1,
						},
					},
					["suitId2"] = 23,
					["heroId"] = 10005,
					["suitId1"] = 25,
					["pos"] = 5,
					["suitId3"] = 23,
					["quality"] = 1,
					["suitId4"] = 24,
					["curExp"] = 0,
					["suitId5"] = 23,
				},
			},
			["action"] = 10000,
			["diamond"] = 100,
			["gold"] = 99,
			["equipList"] = {
				["2"] = {
				},
				["1"] = {
				},
				["3"] = {
				},
			},
			["vip"] = 0,
			["curExp"] = 0,
			["userName"] = "test039",
		},
		[2] = {
			["level"] = 1,
			["teamList"] = {
				["10004"] = {
					["level"] = 1,
					["star"] = 1,
					["skillSlotList"] = {
						["4"] = {
							["level"] = 1,
						},
						["1"] = {
							["level"] = 1,
						},
						["5"] = {
							["level"] = 1,
						},
						["2"] = {
							["level"] = 1,
						},
						["6"] = {
							["level"] = 1,
						},
					 ["3"] = {
							["level"] = 1,
						},
					},
					["heroId"] = 10004,
					["pos"] = 4,
					["quality"] = 1,
				},
				["10005"] = {
					["level"] = 1,
					["star"] = 1,
					["skillSlotList"] = {
						["4"] = {
							["level"] = 1,
						},
						["1"] = {
							["level"] = 1,
						},
						["5"] = {
							["level"] = 1,
						},
						["2"] = {
							["level"] = 1,
						},
						["6"] = {
							["level"] = 1,
						},
						["3"] = {
							["level"] = 1,
						},
					},
					["heroId"] = 10005,
					["pos"] = 5,
					["quality"] = 1,
				},
				-- ["10005"] = {
					-- ["level"] = 1,
					-- ["star"] = 1,
					-- ["heroId"] = 10005,
					-- ["pos"] = 5,
					-- ["quality"] = 1,
				-- },
			},
			["equipList"] = {
				["2"] = {
				},
				["1"] = {
				},
				["3"] = {
				},
			},
		}
	}
	local tbPlayerInfo = {};
	local tbConfig = l_tbHeroBox[nID] or {};
	local tbData = {};
	table.insert(tbData, tbConfig.Organism1);
	table.insert(tbData, tbConfig.Organism2);
	table.insert(tbData, tbConfig.Organism3);
	tbPlayerInfo.teamList = {};
	for _, data in pairs(tbData) do
		if data then
			local nHeroID, nPos = unpack(data);
			tbPlayerInfo.teamList[nHeroID] = {};
			tbPlayerInfo.teamList[nHeroID].heroId = nHeroID;
			tbPlayerInfo.teamList[nHeroID].pos = nPos;
		end
	end
	
	tst_print_lua_table(tbPlayerInfo);
	
	return self:CreatePlayer(tbPlayerInfo);
end

------------------------------------------------------------
--relization
g_PlayerFactory = KGC_PLAYER_FACTORY_TYPE:getInstance()
