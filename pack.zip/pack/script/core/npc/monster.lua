----------------------------------------------------------
-- file:	monster.lua
-- Author:	page
-- Time:	2015/07/27 17:01
-- Desc:	��Լ����
----------------------------------------------------------
require "script/core/npc/npc"
--------------------------------
--define @ 2015/01/27 17:35
-- �ඨ���data�����ô�д
-- 
--------------------------------
local l_tbMonsterConfig = require("script/cfg/monster");
--data struct 
local TB_STRUCT_MONSTER = {
	
}

KGC_MONSTER_TYPE = class("KGC_MONSTER_TYPE", KG_NPC_BASE_TYPE, TB_STRUCT_MONSTER)

local tbNpcType = def_GetNpcType();
--------------------------------
--function
--------------------------------
function KGC_MONSTER_TYPE:ctor()

end

function KGC_MONSTER_TYPE:GetConfigInfo(nID)
	return l_tbMonsterConfig[nID]
end

--@function: 
function KGC_MONSTER_TYPE:OnInit(tbArg)
	local nPos = self:GetPos();
	print("KGC_MONSTER_TYPE:OnInit, nPos = ", nPos)
	self:SetBloodShare(true)
	print("OnInit: ", self:GetName(), self:IsBloodShare())
end
---------------------------------------------------------
--test
