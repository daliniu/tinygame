----------------------------------------------------------
-- file:	head.lua
-- Author:	page
-- Time:	2015/03/12 10:06
-- Desc:	core�����һ��ͷ�ļ�����
----------------------------------------------------------
require "script/class/class_base"
require "script/class/class_data_base"
require "script/lib/basefunctions"

-- if not _SERVER then
require "script/lib/testfunctions"
require "script/lib/definefunctions"
-- end
----------------------------------------------------------

