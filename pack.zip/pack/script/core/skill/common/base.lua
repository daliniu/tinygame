----------------------------------------------------------
-- file:	base.lua
-- Author:	page
-- Time:	2015/02/02 10:41
-- Desc:	技能基类
--			
----------------------------------------------------------
require "script/core/head"
require "script/lib/definefunctions"
require "script/core/skill/common/data"
require "script/core/skill/effect/head"
require "script/core/skill/statemanager"

local l_tbResultConfig = require("script/cfg/skillresults")
----------------------------------------------------------
local l_tbConditions = require("script/cfg/condition")
local l_tbHitType = def_GetHitTypeData();
local l_tbConfig = def_GetSkillBaseConfigData();
local l_tbFSIndex, l_tbFightState = def_GetFightStateData()
local l_tbPos = def_GetPosData();
local l_tbSkillCastRet = def_GetSkillCastRetData();
local l_tbCondID, l_tbCondName = def_GetConditionData();
local l_tbTargetSelectMethod,l_tbTSMName = def_GetTargetSelectMethondDATA();
local l_tbSkillScope, l_tbSSName = def_GetSkillScopeData()
local l_tbCamp = def_GetFightCampData();
local l_tbEffect = def_GetEffectType();
local l_tbStateCheckType = def_GetStateCheckType();
local l_tbSkillType = def_GetSkillTypeData();

--data struct
local TB_SKILL_BASE_DATA = {
	--config
	------------------------------------
	m_nCost = 0,			--技能所需费用
	m_nID = 0,				--技能ID
	m_szName = "",			--技能名称
	m_szDesc = "",			--技能描述
	m_szIcon = "",			--技能图标
	m_nLevel = 0,			--技能等级
	m_nType = 0,			--技能类型(普通、契约、合作)
	m_nHitType = 0,			--命中类型
	m_nBHR = 100,			--技能基础命中参数
	m_bVam = true,			--是否吸血
	
	m_nCastType = 0,		--释放方式
	m_nCondID = 0,			--触发技能条件ID
	m_nTarCamp = 0,			--目标阵营
	m_nEffID = 0,			--技能效果类型
	m_tbEffData = {			--技能效果数据
		nID = 0,				--技能效果ID
		nType = 0,				--技能效果类型
		tbState = {				--附带状态
			nStaID = 0,				--状态ID
			nConID = 0,				--条件ID
		},
		tbArgs = {}			--参数
	},
	m_tbTargetSelect = {	--目标筛选
		nType = 0,				--方式
		tbPos = {},				--基准位置
		nCost = 0,				--目标费用
		nTarget2 = 0,			--二次目标筛选
		nRangeType = 0,			--范围类型
		nMax = 0,				--最大目标数量
	},
	------------------------------------
	m_Hero = nil,			--释放技能的对象
	m_tbHeros = {},			--释放技能的对象(有多个)
	m_Targets = nil,		--技能目标
	m_fPro = 0,				--释放概率(m_nfPro%)
	m_Lau = nil,			--选择的攻击源
	m_tbRetStates = {},		--搜集各种状态结果
	m_nCastRet = l_tbSkillCastRet.SUCCESS,	--上一次技能释放结果，用于决定是否重新释放
	m_nRet = l_tbSkillCastRet.FAILED;		--本次技能的释放结果
	m_tbMulCost = {},		--多重施法的费用表
	m_tbUIEffect = {},		--保存临时特效(例如多重施法脚底特效)
}

KGC_SKILL_BASE_TYPE = class("KGC_SKILL_BASE_TYPE", KGC_OBS_OBJECT_BASE_TYPE, TB_SKILL_BASE_DATA)

--客户端部分
if not _SERVER then
require "script/ui/publicview/uiskill/uibase"
end
----------------------------------------
--function
----------------------------------------
function KGC_SKILL_BASE_TYPE:ctor()
	local tbTemp = gf_CopyTable(TB_SKILL_BASE_DATA)
	for k, v in pairs(tbTemp) do
		self[k] = v;
	end
end

function KGC_SKILL_BASE_TYPE:Init(tbConfig, tbInfo)
-- tst_PrintTime(7000)
	tbConfig = tbConfig or {}
	if tbConfig.nID then
		self.m_nID = tbConfig.nID
	end
	
	if tbConfig.nLevel then
		self.m_nLevel = tbConfig.nLevel or 0;
	end
	-- if tbConfig.nCost then
		-- self.m_nCost = tbConfig.nCost
	-- end
	if tbConfig.fPro then
		self.m_fPro = tbConfig.fPro;
	end
	--读取配置表
	if type(tbInfo) == "table" then
		self:SetName(tbInfo.name)
		self:SetDesc(tbInfo.desc)
		self:SetFightText(tbInfo.fighttext)
		self:SetIcon(tbInfo.icon)
		self:SetCastType(tbInfo.casttype)
		self:SetCost(tbInfo.cost)
		self:SetCondID(tbInfo.conid)
		self:SetType(tbInfo.type)
		self:SetLevel(tbInfo.level)
		self:SetPro(tbInfo.probability)
		self:SetTarCamp(tbInfo.camp)
		self:SetTargetSelect(tbInfo.target1, tbInfo.pos, tbInfo.costarg, tbInfo.target2, tbInfo.rangetype, tbInfo.max)
		self:SetHitType(tbInfo.hittype)
		self:SetEffectByID(tbInfo.skillresultsid)
	end
	
	if not _SERVER then
		--初始化表现配置表
		self:InitUIEffectShow(self:GetID());
	end
	--触发类添加到观察者
	-- if self:GetCastType() == 1 then
		-- self:Attach(g_CondTrigger)
	-- end
-- tst_PrintTime(7002)
	self:OnInit(tbInfo)
end

function KGC_SKILL_BASE_TYPE:OnInit()
	--test
	if self.m_nID == 30011 then
		print("多重施法初始化")
		self:SetPro(100)
	end
	--test end
end

--@function: 战斗逻辑
function KGC_SKILL_BASE_TYPE:Cast(launchers, targets, data)
	if type(launchers) ~= "table" or type(targets) ~= "table" then
		cclog("[Error]Data Error! @Cast()")
		return false;
	end
	
	local tbRet = {}
	
	--默认只攻击一次
	local nRet = l_tbSkillCastRet.SUCCESS;
	--launcher
	local tbRetLaus = {}
	local tbRetDefs = {}
	self.m_tbRetStates = {};			--收集各种状态
	
	-- tst_PrintTime(10000)
	--选择攻击目标
	local launcher = self:GetCaster()
	local nCostMaxOld = launcher:GetFightShip():GetMaxCost();	-- 逻辑中会增加费用上限
	
	-- tst_PrintTime(10001)
	local nTot = 0;	--总伤害(计算吸血)
	for _, def in pairs(targets) do
		-- tst_PrintTime(12000)
		--命中类型检测
		local bHit = self:IsHit(launcher, def);
		if bHit then
			--暴击检测
			local bCrit = self:IsCrit(launcher, def);
			-- tst_PrintTime(12000)
			--伤害结算
			local data, nDamage, nRetTemp = self:CalcLogic(launcher, def, bCrit)
			-- tst_PrintTime(12001)
			nRet = nRetTemp;
			nTot = nTot + nDamage;
			table.insert(tbRetDefs, data)
		else
			--miss
			print("[log]miss了");
			local data = KGC_DATA_DEFEND_SAVE_TYPE.new()
			data:Init(false, def:GetPos(), def:GetFightShip():GetCamp(), def, self)
			table.insert(tbRetDefs, data);
		end
		-- tst_PrintTime(12002)
	end
	-- tst_PrintTime(10002)
	--计算吸血
	for _, lau in pairs(launchers) do
		local data = KGC_DATA_LAUNCHER_SAVE_TYPE.new()
		local nVam = 0;
		if lau == launcher then
			if self:IsVam() then
				nVam = self:CalcVampire(launcher, nTot);
			end
		end
		data:Init(lau:GetPos(), lau:GetFightShip():GetCamp(), lau, self, bCrit, bCA, nVam);
		if lau == launcher then
			data:SetSrc(true)
			print("设置攻击者的位置为@SetSrc：", launcher:GetPos(), launcher:GetFightShip():GetCamp())
			local nBefore, nChange = lau:GetFightShip():GetTempCost();
			local nCostMaxNew = lau:GetFightShip():GetMaxCost()
			cclog("[log]skillbase(%s)当前费用：%d, 之前总费用:%d, before:%d, nChange:%d， 之后总费用: %d", self:GetName(), lau:GetFightShip():GetCost(), nCostMaxOld, nBefore or 0, nChange or 0, nCostMaxNew)
			data:SetCost(lau:GetFightShip():GetCost(), nCostMaxOld, nBefore, nChange, nCostMaxNew);
		end
		table.insert(tbRetLaus, data);
	end
	-- tst_PrintTime(10003)
	--test
	print("生成状态结果个数", #(self.m_tbRetStates or {}))
	--反击流程
	self:CalcCounterAttack(launcher, tbRetLaus, tbRetDefs)
	
	--触发技能：释放<>触发
	self:StartTriggerSkillsCondition(nil, targets);
	-- tst_PrintTime(10004)
	print("nRet", nRet)
	self.m_nRet = nRet;
	return tbRetLaus, tbRetDefs, self.m_tbRetStates, nRet;
end

--@function: 真实命中率
function KGC_SKILL_BASE_TYPE:CalcRealHitRate(launcher, defend)
	-- print("CalcRealHitRate")
	--命中修正系数(/100)
	local objLau = launcher:GetHeroObj()
	local objDef = defend:GetHeroObj()
	local nFactor = (objLau:GetLevel() - objDef:GetLevel())/100;
	local nRate = objLau:GetHitRate() - objDef:GetDodgeRate() + nFactor
	-- print("修正系数，命中率，闪避率：", nFactor, objLau:GetHitRate(), objDef:GetDodgeRate())
	
	local nMin = 0.1;
	if nRate < nMin then
		nRate = nMin;
	end
	--保留一位小数
	-- print("真实命中率:", nRate)
	return gf_GetPreciseDecimal(nRate, 3);
end

--@function: 技能命中率计算公式
function KGC_SKILL_BASE_TYPE:CalcSkillHitRate(launcher, defend)
	local objLau = launcher:GetHeroObj()
	local objDef = defend:GetHeroObj()
	--命中修正系数(/100)
	local nFactor = (objLau:GetLevel() - objDef:GetLevel())/100;
	local nRate = self.m_nBHR/100 + objLau:GetHitRate() + nFactor;
	print("CalcSkillHitRate", nRate)
	return nRate;
end

--@function: 真实暴击率
function KGC_SKILL_BASE_TYPE:CalcRealCritRate(launcher, defend)
	local objLau = launcher:GetHeroObj()
	local objDef = defend:GetHeroObj()
	--命中修正系数(/200)
	local nFactor = (objLau:GetLevel() - objDef:GetLevel())/200;
	local nRate = objLau:GetCritRate() - objDef:GetNoCritRate() + nFactor
	
	-- Page@2015/11/05 - hss 修改：0.05-->0.01
	local nMin = 0.01
	-- local nMin = 0;
	if nRate < nMin then
		nRate = nMin;
	end

	return nRate;
end

function KGC_SKILL_BASE_TYPE:IsMiss(defend)
	local bHit, tbState = defend:StateCheck(self, l_tbStateCheckType.STUN)
	if bHit then
		-- for _, state in ipairs(tbState) do
			-- state:Work();
		-- end
		return false;
	end
	return true;
end

--@function: 命中类型检测
function KGC_SKILL_BASE_TYPE:IsHit(launcher, defend)
	local nHitType = self:GetHitType();

	local nRate = 0;
	-- print("hit type", nHitType, l_tbHitType.MISS_DIFF, l_tbHitType.HIT_DIFF)
	if nHitType == l_tbHitType.MISS_DIFF then
		nRate = self:CalcRealHitRate(launcher, defend);
	elseif nHitType == l_tbHitType.HIT_DIFF then
		nRate = self:CalcSkillHitRate(launcher, defend);
	elseif nHitType == l_tbHitType.HIT then
		nRate = 1;
	end
	
	local bHit = self:IsWinLottery(nRate)
	
	--状态检测不可闪避
	if not self:IsMiss(defend) then
		bHit = true;
	end
	--test
	cclog("[log]命中类型(%d)以概率%f是否命中%s", nHitType, nRate, tostring(bHit))
	--test end
	return bHit;
end

--@function: 暴击检测
function KGC_SKILL_BASE_TYPE:IsCrit(launcher, defend)
	local nRate = self:CalcRealCritRate(launcher, defend)
	
	local bRet = self:IsWinLottery(nRate)
	print("是否暴击：", bRet)
	return bRet;
end

--@function: 随机的小数是否在给定的范围内，即中奖^_^
function KGC_SKILL_BASE_TYPE:IsWinLottery(nRate)
	local nBase = 1000;
	nRate = nRate or -1;	--默认不会随到

	--test
	if DEBUG_SEED then
		local szLog = "IsWinLottery\n";
		tst_write_file("tst_random_function.txt", szLog);
	end
	--test end
	local nRandom = gf_Random(1, nBase);
	print("IsWinLottery", nRandom, nRate, nBase, nRate * nBase)
	
	if nRandom <= nRate * nBase then
		return true;
	else
		return false;
	end
end

function KGC_SKILL_BASE_TYPE:SpecialSkill(launchers, defends)
end

--@function: 伤害计算
function KGC_SKILL_BASE_TYPE:CalcDamage(launcher, defend, bCrit)
	local tbArg = self:GetEffectArgs();
	local objLau = launcher:GetHeroObj()
	local objDef = defend:GetHeroObj()
	
	local nArg2 = tbArg[2] or 0;
	local nArg3 = tbArg[3] or 0;
	local nArg4 = tbArg[4] or 1;
	if nArg4 <= 0 then
		nArg4 = 1;
	end
	local nArg5 = tbArg[5] or 1;
	if nArg5 <= 0 then
		nArg5 = 1;
	end
	
	local nAtk = launcher:GetAttack();
	--放大攻击力
	local nAttack = (self:GetLevel() * nArg2 + nArg3 + nAtk/nArg4) * 1 / nArg5;
	local nDefRate = objDef:GetDefendRate(launcher:GetAttack())
	local nPenRate = objLau:GetPenetrationRate();
	print("base CalcDamage: ", nAttack, nAtk, self:GetLevel(), nArg2, nArg3, nArg4, nArg5, nDefRate, nPenRate, bCrit)
	local nDamage = nAttack * (1 - nDefRate) * (1 + nPenRate)
	if bCrit then
		nDamage = nDamage * l_tbConfig.CRIT_DOUBLE
	else
		--这里的费用是战斗时时费用
		nDamage = nDamage * (1 + launcher:GetHeroObj():GetCost() * 0.1)
	end
	print("CalcDamage", nDamage);
	
	--护盾
	local nSubDamage = defend:StateCheck(self, l_tbStateCheckType.SHIELD, nDamage)
	nDamage = nDamage - nSubDamage;
	cclog("减少了伤害:%d, 原伤害为：%d, 总伤害为：%d", nSubDamage, nDamage+nSubDamage, nDamage);
	
	--page@2015/11/23 增加一个浮动[-0.03, 0.03]
	local nFloat = gf_Random(97, 103);
	nDamage = math.floor(nDamage * nFloat / 100);
	cclog("[log]伤害计算，浮动百分比(0.03): *(%d)-->(%d)", nFloat, nDamage);
	
	if nDamage < 0 then
		nDamage = 0;
	end
	
	return nDamage;
end

--@function：技能效果治疗
function KGC_SKILL_BASE_TYPE:CalcCure(launcher, defend)
	local tbArg = self:GetEffectArgs();
	local objLau = launcher:GetHeroObj()
	local objDef = defend:GetHeroObj()
	
	local nArg1 = tbArg[1] or 0;
	local nArg2 = tbArg[2] or 0;
	local nArg3 = tbArg[3] or 0;
	
	local nHP = (self:GetLevel() * nArg1) * nArg2 + objDef:GetHP() * nArg3;
	print("加血：", nHP)
	return nHP;
end

--@function: 杀生物
function KGC_SKILL_BASE_TYPE:KillContract(launcher, defend)
	local nDamage = 0;
	local tbArg = self:GetEffectArgs();
	local objLau = launcher:GetHeroObj()
	local objDef = defend:GetHeroObj()
	
	local nArg1 = tbArg[1] or 0;
	local nArg2 = tbArg[2] or 0;
	local nArg3 = tbArg[3] or 0;
	local nArg4 = tbArg[4] or 0;
	local nArg5 = tbArg[5] or 0;
	local nArg6 = tbArg[6] or 0;
	local nArg7 = tbArg[7] or 0;
	if nArg3 <= 0 then
		nArg3 = 1;
	end
	if nArg4 <= 0 then
		nArg4 = 1;
	end
	if nArg7 <= 0 then
		nArg7 = 1;
	end
	--待定属性
	local nTest1 = 1;
	local nTest2 = 1;
	if objDef:IsSummon() then
		print("杀生物---是生物")
		nDamage = (nArg1 + self:GetLevel() * nArg2 + nTest1/nArg3 - nTest2/nArg4) / 100 * objDef:GetHP();
	else
		print("杀生物---不是生物")
		local nAtk = launcher:GetAttack();
		nDamage = nArg5 + nArg6 * self:GetLevel() + nAtk/nArg7;
	end

	print("杀生物造成伤害：", nDamage)
	return nDamage;
end

function KGC_SKILL_BASE_TYPE:CalcLogic(launcher, defend, bCrit)
-- 这个函数平均耗时1s
-- tst_PrintTime(13000)
	if not launcher or not defend then
		cclog("[Error]Data Error! @CalcLogic()")
		return false;
	end

	local nTot = 0;	--总伤害(计算吸血)
	local data = KGC_DATA_DEFEND_SAVE_TYPE.new()
	--for _, defend in pairs(targets) do
	local dataEffect = nil;
	local bImmune, tbState = defend:StateCheck(self, l_tbStateCheckType.IMMUNE);
	-- if bImmune then
		-- for _, state in ipairs(tbState) do
			-- state:Work();
		-- end
	-- end
	print("是否免疫一次伤害：", bImmune)
	local nRet = l_tbSkillCastRet.SUCCESS;
	local nDamage = 0;
	local nTargetHp = defend:GetHP();
	local nCurHP = nTargetHp - nDamage;
	local nTotHP = defend:GetHeroObj():GetHP()
	if not bImmune then
		--效果
		local nEffectType = self:GetEffectType() or 0;
		if nEffectType < l_tbEffect.E_MIN or nEffectType > l_tbEffect.E_MAX then
			nEffectType = l_tbEffect.E_MIN;
		end
		print("效果类型：", nEffectType)
		if nEffectType == l_tbEffect.E_ATK then						--攻击
			dataEffect = KGC_ED_ATTACk_TYPE.new()
			nDamage = self:CalcDamage(launcher, defend, bCrit)
			nCurHP = nTargetHp - nDamage;
			-- dataEffect:Init(1, nCurHP, defend:GetHeroObj():GetHP(), nDamage);
		elseif nEffectType == l_tbEffect.E_CURE then				--治疗
			dataEffect = KGC_ED_ATTACk_TYPE.new()
			local nHP = self:CalcCure(launcher, defend) or 0
			--和伤害值正负相反
			nDamage = -nHP;
			nCurHP = nTargetHp - nDamage;
			-- dataEffect:Init(1, nCurHP, defend:GetHeroObj():GetHP(), nDamage);
		elseif nEffectType == l_tbEffect.E_MUL then					--多重施法
			print("多重施法")
			nRet = l_tbSkillCastRet.MAGIC;
			local tbArgs = self:GetEffectArgs()
			local tbCost = {};
			for k, v in ipairs(tbArgs) do
				if v > 0 then
					table.insert(tbCost, v)
				end
			end
			self.m_tbMulCost = tbCost;
		elseif nEffectType == l_tbEffect.E_KILL then				--杀生物
			dataEffect = KGC_ED_ATTACk_TYPE.new()
			nDamage = self:KillContract(launcher, defend)
			nCurHP = nTargetHp - nDamage;
		elseif nEffectType == l_tbEffect.E_ADD then					--增加法力上限
			local tbArg = self:GetEffectArgs();
			local nAddCost = tbArg[1] or 0;
			if nAddCost > 0 then
				local nCost1 = launcher:GetFightShip():GetMaxCost();
				print("[Log]增加法力上限", nAddCost);
				launcher:GetFightShip():AddMaxCostAdd(nAddCost);
				local nCost2 = launcher:GetFightShip():GetMaxCost();
				print(222, nCost1, nCost2);
			end
		elseif nEffectType == l_tbEffect.E_CALL then				--召唤
			--技能特殊操作
			local nRetTemp, contract = self:SpecialSkill(launcher, defend);
			-- self:AddStateRet(stateData)
			nRet = nRetTemp;
			defend = contract;
			print("召唤: ", nRet)
			self:SetCastRet(nRet)
		elseif nEffectType == l_tbEffect.E_COPY then				--复制
		end
		
		-----------------------------------------------------------------------------
		--状态
		local _, stateData = self:StateLogic(launcher, defend)
		if stateData then
			self:AddStateRet({stateData})
		end
-- tst_PrintTime(14002)
		if self:IsCombo() then
			-- print("IsCombo ... ", self:GetName())
			local nRetTemp, stateData = self:SpecialSkill(launcher, defend);
			self:AddStateRet({stateData})
		end
		-----------------------------------------------------------------------------
		local fnCalcHP = function()
	-- tst_PrintTime(14001)		
			--表现上会好看一点
			print("nDamage", nDamage, nCurHP, nTargetHp, nTotHP);
			if nDamage == 0 then
				nDamage = 1;
				nCurHP = nTargetHp - nDamage;
			end
			
	-- tst_PrintTime(14003)
			if nCurHP <= 0 then
				-- 共用血条的没有死亡一说
				if not defend:GetHeroObj():IsBloodShare() then
					--死亡
					local tbRetState = defend:Death();
					self:AddStateRet(tbRetState);
					-- cclog("Test: 触发死亡'条件', 英雄位置(%d)", defend:GetPos())
					-- print("死亡后产生状态：#tbRetState", #tbRetState)
				end
			end
	-- tst_PrintTime(14004)		
			--更新角色战斗数据
			local nSaveHP = nCurHP;
			defend:SetHP(nCurHP);
			cclog("[共用血条]%s, 位置(%d)：是否共享血条(%s)", defend:GetName(), defend:GetPos(), tostring(defend:GetHeroObj():IsBloodShare()))
			if defend:GetHeroObj():IsBloodShare() then
				nCurHP = defend:GetFightShip():GetHP()
				nTotHP = defend:GetFightShip():GetMaxHP();
				print("[共用血条]nCurHP, nTotHP, nDamage", nCurHP, nTotHP, nDamage)
			end
			if nEffectType == l_tbEffect.E_CURE and nCurHP > nTotHP then
				local nAdd = nCurHP - nTotHP;
				defend:SetHP(nSaveHP - nAdd);
				nCurHP = nTotHP;
			end
			print("Target位置, nCurHP, nTotHP, nDamage", defend:GetPos(), nCurHP, nTotHP, nDamage)
			
			if dataEffect then
				dataEffect:Init(1, nCurHP, nTotHP, nDamage);
			end
	-- tst_PrintTime(14005)		
			--反击判断
			local bCA = self:CheckCounterAttack(defend)
			print("是否反击：", bCA)
			
			--给队友加血的不算
			if nDamage > 0 then
				nTot = nTot + nDamage;
			end
		end
		if self:IsCalcHP(nEffectType) then
			fnCalcHP();
		end
	end
-- tst_PrintTime(13002)
	--战斗结构数据
	data:Init(true, defend:GetPos(), defend:GetFightShip():GetCamp(), defend, self, bCrit, bCA, dataEffect, {nCurHP, nTotHP, nDamage})
-- tst_PrintTime(13003)
	--end
	print("nRet", nRet)
	return data, nDamage, nRet;
end

--@function：是否血量处理
function KGC_SKILL_BASE_TYPE:IsCalcHP(nEffectType)
	if nEffectType == l_tbEffect.E_ADD or
	nEffectType == l_tbEffect.E_CALL or
	nEffectType == l_tbEffect.E_MUL then
		return false;
	end
	return true;
end

--@function：技能效果处理
function KGC_SKILL_BASE_TYPE:EffectLogic(launcher, defend, bCrit)
	
end

--@function: 多重施法获取费用
function KGC_SKILL_BASE_TYPE:GetMulCost()
	return self.m_tbMulCost or {}
end

function KGC_SKILL_BASE_TYPE:StateLogic(lau, def)
-- tst_PrintTime(15000)
	local nStaID, nConID = self:GetEffectState();
	if nStaID <= 0 then
		return;
	end
	cclog("开始计算状态逻辑 ... ", nStaID, nConID);
	-- if nStaID ~= 60001 then
		-- return;
	-- end
-- tst_PrintTime(15001)
	local state = g_StateManager:CreateState(nStaID, def, self)
	local bRet, data = state:Cast(def)
	if data then
		data:SetTriggerConID(l_tbCondID.HIT);
	end
-- tst_PrintTime(15002)
	-- if nStaID == 1 then
		-- local tbFightShip = launcher:GetFightShip();
		-- --触发嘲讽
		-- local state = KGC_STATE_TAUNT_TYPE.new();
		-- local queueState = launcher:GetStateQueue();
		-- local bRet, data
		-- if queueState then
			-- bRet, data = state:Cast(launcher)
			-- --添加条件通知
			-- if bRet then
				-- print("添加观察主题")
				-- state:AttachSubject(g_CondTrigger, launcher:GetHeroObj(), launcher:GetFightShip():GetCamp())
			-- end
		-- end
		-- print("[嘲讽]logic触发, 生效结果", bRet)
		-- return bRet, data;
	-- end
	return bRet, data
end

function KGC_SKILL_BASE_TYPE:CalcCounterAttack(launcher, tbRetLaus, tbRetDefs)
	for _, v in pairs(tbRetDefs) do
		if v:GetCA() then
			local lau = nil
			for _, retlau in pairs(tbRetLaus) do
				if launcher == retlau:GetNpc() then
					lau = retlau;
					break;
				end
			end
			if lau then
				--local skillCA = 
				local nDamage = self:CalcDamage(launcher, v:GetNpc(), false);
				local nCurHP = launcher:GetHP() - nDamage
				print("反击伤害:", nDamage)
				v:SetCADamage(nCurHP, launcher:GetHeroObj():GetHP(), nDamage)
			end
		end
	end
end

function KGC_SKILL_BASE_TYPE:IsVam()
	return self.m_bVam;
end

--@function: 计算吸血
function KGC_SKILL_BASE_TYPE:CalcVampire(launcher, nDamage)
	local objLau = launcher:GetHeroObj()
	local nDiv = launcher:GetVamEff() + objLau:GetVLFactor()
	local nEff = 0;
	if nDiv ~= 0 then
		nEff = objLau:GetVampireLevel()/nDiv;
	end
	launcher:SetVamEff(nEff)
	
	local nHP = nDamage * nEff;
	
	print("吸血计算", nEff, bRet, nHP)
	return nHP;
end

function KGC_SKILL_BASE_TYPE:CheckCounterAttack(defend)
	local objDef = defend:GetHeroObj()
	
	local nRate = objDef:GetCALevel()/(defend:GetCARate() + objDef:GetCAFactor())
	defend:SetCARate(nRate)
	
	--print("反击", objDef:GetCALevel(), defend:GetCARate(), objDef:GetCAFactor(), nRate)
	return self:IsWinLottery(nRate);
end

--@function: 不用这个函数，改为GetCaster
-- function KGC_SKILL_BASE_TYPE:GetLauncher()
	-- local tbHeros = self:GetHeros() or {};
	-- local lau = tbHeros[1]

	-- self.m_Lau = lau;
	-- return lau
-- end

function KGC_SKILL_BASE_TYPE:GetRetLau(tbRetLau)
	local retLau = nil;
	for k, v in ipairs(tbRetLau) do
		if v:GetSrc() then
			retLau = v;
			break;
		end
	end
	return retLau;
end

--
function KGC_SKILL_BASE_TYPE:CreateLaunchers(launchers)
	local tbLaunchers = {}
	for _, lau in pairs(launchers) do
		local data = KGC_DATA_LAUNCHER_SAVE_TYPE.new()
		data:Init(lau:GetPos(), lau:GetFightShip():GetCamp(), lau, self, false, false, 0)
		table.insert(tbLaunchers, data)
	end
	
	return tbLaunchers
end

-- function KGC_SKILL_BASE_TYPE:CreateTargets(targets)
	-- local tbTargets = {}

	-- for _, target in pairs(targets) do
		-- local data = KGC_DATA_DEFEND_SAVE_TYPE.new()
		-- data:Init(target:GetPos(), target:GetFightShip():GetCamp(), target, self)
		-- table.insert(tbTargets, data);
	-- end
	-- return tbTargets;
-- end

function KGC_SKILL_BASE_TYPE:SetHitType(nType)
	nType = nType or 0;
	self.m_nHitType = nType;
end

function KGC_SKILL_BASE_TYPE:GetHitType()
	return self.m_nHitType;
end

function KGC_SKILL_BASE_TYPE:GetPartner()
end

--@lau：攻击者
--@tbLaus: 攻击者
function KGC_SKILL_BASE_TYPE:GetTarget(lau, tbDefs, tbLaus)
	local nPos = lau:GetPos()
	if not gf_IsValidPos(nPos) then
		return nil;
	end
		
	local tbTargets = tbDefs;

	if self:GetTarCamp() == l_tbCamp.MINE then
		tbTargets = tbLaus;
	end
	
	local nSelectType = self:GetSelectType()
	
	if not self:IsValidSelectType(nSelectType) then
		cclog("[Warning]不是有效的筛选目标方式(%s)，选择默认方式", tostring(nSelectType))
		nSelectType = l_tbTargetSelectMethod.M_DEFAULT;
	end
	
	cclog("Test: 筛选目标方式：%d - %s", nSelectType, l_tbTSMName[nSelectType])
	
	if type(tbTargets) ~= "table" then
		cclog("[Error]tbTargets is not table!@base:GetTarget()")
		return false;
	end
	
	local tbPos = {};
	local MAX_MAGIC = 3			--一排最大是三个
	
	--test
	local tbTestCmap = {
		[l_tbCamp.MINE] = "我方",
		[l_tbCamp.ENEMY] = "敌方",
	}
	cclog("[skill]攻击者(%s): 位置(%d), 阵营(%s) --->寻找攻击目标(总数:%d)", lau:GetName(), nPos, tbTestCmap[lau:GetFightShip():GetCamp()], #tbTargets)
	--test end

	-- local tbRet = {}
	--test
	if DEBUG_SEED then
		local szLog = "GetTarget:" .. nSelectType .. "," .. self:GetID() .. "\n";
		tst_write_file("tst_random_function.txt", szLog);
	end
	--test end
	
	local tbRefPos = {};			--基准位置
	if nSelectType == l_tbTargetSelectMethod.M_DEFAULT then			--默认方式
		--先找对位生物
		local nTarPos = (nPos-1)%MAX_MAGIC + 1;

		for nIndex, tar in pairs(tbTargets) do
			local pos = tar:GetPos()
			if pos == nTarPos then
				--攻击者带飞行状态
				local bFly = lau:StateCheck(self, l_tbStateCheckType.FLY);
				if not bFly or (bFly and tar:StateCheck(self, l_tbStateCheckType.FLY)) then
					table.insert(tbRefPos, nTarPos)
					-- table.insert(tbRet, tar);
					break;
					-- return {tar};
				end
			end
		end
		
		--找满足条件的生物(嘲讽)
		if #tbRefPos <= 0 then
			for _, tar in pairs(tbTargets) do
				cclog("[log]Test:检查状态，是否嘲讽(%s)", tostring(tar:StateCheck(self, l_tbStateCheckType.TAUNT)))
				if tar:GetHeroObj():IsSummon() then
					local bStateRet, tbState = tar:StateCheck(self, l_tbStateCheckType.TAUNT)
					if bStateRet then
						local bFly = lau:StateCheck(self, l_tbStateCheckType.FLY);
						if not bFly or (bFly and tar:StateCheck(self, l_tbStateCheckType.FLY)) then
							--生效
							-- for _, state in ipairs(tbState) do
								-- state:Work();
							-- end
							table.insert(tbRefPos, tar:GetPos())
							-- table.insert(tbRet, tar);
							break;
							-- return {tar}
						end
					end
				end
			end
		end
		
		--再英雄
		if #tbRefPos <= 0 then
			nTarPos = ((nPos-1)%MAX_MAGIC + 1) + MAX_MAGIC
			-- print("还是打英雄吧：nTarPos", nTarPos, #tbTargets);
			for nIndex, tar in pairs(tbTargets) do
				local pos = tar:GetPos()
				-- print("pos", pos)
				if pos == nTarPos then
					local szLog = nPos .. "--->--->|||" .. self:GetName() .. "|||--->--->" .. nTarPos;
					local nCamp = tar:GetFightShip():GetCamp()
					local nCampLau = lau:GetFightShip():GetCamp();
					--test
					-- print("阵营", nCamp)
					if nCampLau == 1 then
						szLog = "[我] " .. szLog
					else
						szLog = "[敌] " .. szLog
					end
					if nCamp == 1 then
						szLog = szLog .. " [我]";	
					else
						szLog = szLog .. " [敌]";
					end
					print(szLog);
					--test end
					table.insert(tbRefPos, nTarPos)
					-- table.insert(tbRet, tar);
					break;
					-- return {tar};
				end
			end
		end

	elseif nSelectType == l_tbTargetSelectMethod.M_POS then			--位置目标
		local tbPos = self:GetSelectPos()
		for k, v in ipairs(tbPos) do
			table.insert(tbRefPos, v)
		end
		print("#tbRefPos", #tbRefPos)
		-- print("+===============================================+")
	elseif nSelectType == l_tbTargetSelectMethod.M_SELF then		--自身
		table.insert(tbRefPos, lau:GetPos())
	elseif nSelectType == l_tbTargetSelectMethod.M_SINGLE then		--对位单体生物
		--先找对位生物
		local nTarPos = (nPos-1)%MAX_MAGIC + 1;
		print("对位单体生物的位置:", nTarPos)
		for nIndex, tar in pairs(tbTargets) do
			local pos = tar:GetPos()
			if pos == nTarPos then
				table.insert(tbRefPos, nTarPos)
				break;
			end
		end
		
	elseif nSelectType == l_tbTargetSelectMethod.M_MAXCOST then		--最高费生物
		tbRefPos = {}
		local fnCmp = function(a, b)
			return a:GetHeroObj():GetCost() > b:GetHeroObj():GetCost();
		end
		table.sort(tbTargets, fnCmp)
		local nMax = tbTargets[1]:GetHeroObj():GetCost()
		print("最高费用：", nMax)
		for _, tar in ipairs(tbTargets) do
			print("费用：", tar:GetHeroObj():GetCost())
			if tar:GetHeroObj():IsSummon() and tar:GetHeroObj():GetCost() == nMax then
				table.insert(tbRefPos, tar:GetPos())
			end
		end
	elseif nSelectType == l_tbTargetSelectMethod.M_MINCOST then		--最低费生物
		local fnCmp = function(a, b)
			return a:GetHeroObj():GetCost() < b:GetHeroObj():GetCost();
		end
		table.sort(tbTargets, fnCmp)
		local nMin = tbTargets[1]:GetHeroObj():GetCost()
		print("最低费用：", nMax)
		for _, tar in ipairs(tbTargets) do
			print("费用：", tar:GetHeroObj():GetCost(), tar:GetHeroObj():GetCost() == nMin)
			if tar:GetHeroObj():IsSummon() and tar:GetHeroObj():GetCost() == nMin then
				table.insert(tbRefPos, tar:GetPos())
			end
		end
	elseif nSelectType == l_tbTargetSelectMethod.M_UPCOST then		--<目标参数>以上的生物
		local nCost = self:SetSelectCost()
		for _, tar in ipairs(tbTargets) do
			print("位置，费用", tar:GetPos(), tar:GetHeroObj():GetCost())
			if tar:GetHeroObj():IsSummon() and tar:GetHeroObj():GetCost() > nCost then
				table.insert(tbRefPos, tar:GetPos())
			end
		end
	elseif nSelectType == l_tbTargetSelectMethod.M_DOWNCOST then	--<目标参数>以下的生物
		local nCost = self:SetSelectCost()
		for _, tar in ipairs(tbTargets) do
			print("位置，费用", tar:GetPos(), tar:GetHeroObj():GetCost())
			if tar:GetHeroObj():IsSummon() and tar:GetHeroObj():GetCost() < nCost then
				table.insert(tbRefPos, tar:GetPos())
			end
		end
	elseif nSelectType == l_tbTargetSelectMethod.M_RANDOM then		--随机目标
		--test
		if DEBUG_SEED then
			local szLog = "GetTarget\n";
			tst_write_file("tst_random_function.txt", szLog);
		end
		--test end
		local nRand = gf_Random(#tbTargets)
		print("随机目标：(随机数, 位置)", nRand, tbTargets[nRand]:GetPos())
		table.insert(tbRefPos, tbTargets[nRand]:GetPos())
	elseif nSelectType == l_tbTargetSelectMethod.M_MINLEFTHP then	--剩余HP百分比最少
		local nHP = 2;
		for _, tar in ipairs(tbTargets) do
			local nHPPro = tar:GetHP()/tar:GetHeroObj():GetHP()
			print("pos, nHPPro:", tar:GetPos(), nHPPro)
			if tar:GetHeroObj():IsSummon() and nHPPro < nHP then
				print("生物nHPPro:", nHPPro)
				nHP = nHPPro;
				table.insert(tbRefPos, tar:GetPos())
			end
		end
	elseif nSelectType == l_tbTargetSelectMethod.M_POSITION then	--对位英雄
		for _, tar in ipairs(tbTargets) do
			if tar:GetPos() == nPos then
				table.insert(tbRefPos, tar:GetPos())
				break;
			end
		end
	end
	
	--------------test

					local szLog = nPos .. "--->--->|||" .. self:GetName() .. "|||--->--->" ;

					local nCampLau = lau:GetFightShip():GetCamp();
					if nCampLau == 1 then
						szLog = "[我] " .. szLog
					else
						szLog = "[敌] " .. szLog
					end
					print(szLog);
	--------------test end
	-- print("攻击目标位置：")
	-- for _, v in ipairs(tbRefPos) do
		-- print(v)
	-- end
	--确定技能的最大目标数量
	local nSelectMax = self:GetSelectMax();
	-- print("最大目标数量：", nSelectMax)
	local tbRetPos = {}
	if nSelectMax > 0 then	--默认0为不判断
		for i=1, #tbRefPos do
			if i <= nSelectMax then
				table.insert(tbRetPos, tbRefPos[i])
			else
				break;
			end
		end
		tbRefPos = tbRetPos;
	end
	
	--二次目标筛选
	if not tbRefPos or #tbRefPos <= 0 then
		tbRefPos = self:GetTarget2(lau, tbDefs, tbLaus)
	end
	
	-- print("攻击目标位置2：", #tbRefPos)
	-- for _, v in ipairs(tbRefPos) do
		-- print(v)
	-- end
	
	--技能范围
	local nRangeType = self:GetSelectRangeType();
	-- cclog("技能(%s)范围类型%s", self:GetName(), tostring(nRangeType))
	local tbTarPos = self:GetRange(nRangeType, tbRefPos)
	local tbHash = {}
	for nIndex, tar in pairs(tbTargets) do
		-- print("英雄位置：", tar:GetPos())
		tbHash[tar:GetPos()] = tar;
	end
	local tbRet = {};
	-- print("#tbTarPos", #tbTarPos)
	for k, v in ipairs(tbTarPos) do
		-- print(v, tbHash[v])
		if tbHash[v] then
			table.insert(tbRet, tbHash[v]);
		end
	end
	
	-- 如果还是没有对象，就把所有的受击者当作目标
	if #tbRet <= 0 then
		print("[Warning]没有找到要攻击的目标，所有受击者作为目标!");
		for k, v in ipairs(tbTargets) do
			table.insert(tbRet, v);
		end
	end
	
	-- test 
	cclog("攻击目标位置：(%s)", tbTestCmap[self:GetTarCamp()])
	local szLog = "\t";
	for k, v in pairs(tbRet) do
		local szHero = string.format("英雄(%s), 位置(%d);", v:GetName(), v:GetPos());
		szLog = szLog .. szHero;
	end
	print(szLog);
	-- test end
	
	-- 保存targets
	self.m_Targets = tbRet;
	
	return tbRet, self:GetTarCamp();
end

--@function: 二次目标筛选
function KGC_SKILL_BASE_TYPE:GetTarget2(lau, tbDefs, tbLaus)
	local tbMode = {
		CONTRAT = 1,		--继续寻找敌方生物
		HERO = 2,			--寻找英雄
	}
	print("[skill]进入二次筛选")
	local nPos = lau:GetPos();
	local nTarget2 = self:GetSelectTarget2()
	-- local tbRet = {}
	local tbRetPos = {}
	
	local tbTargets = tbDefs;
	if self:GetTarCamp() == l_tbCamp.MINE then
		tbTargets = tbLaus;
	end
	
	if nTarget2 == tbMode.CONTRAT then
		for _, tar in ipairs(tbTargets) do
			if tar:GetHeroObj():IsSummon() then
				-- tbRet = {tar}
				table.insert(tbRetPos, tar:GetPos())
				break;
			end
		end
	end
	
	--notify: 继续找生物没有找到: 寻找对位英雄
	if #tbRetPos <= 0 then
		for _, tar in ipairs(tbTargets) do
			if tar:GetPos() == nPos then
				-- tbRet = {tar}
				table.insert(tbRetPos, tar:GetPos())
				break;
			end
		end
	end
	
	--@page@2015/07/28 依旧没有找到, 就找一个打(eg: 增加只有boss的情况)
	if #tbRetPos <= 0 then
		for _, tar in ipairs(tbTargets) do
			table.insert(tbRetPos, tar:GetPos())
			break;
		end
	end
	
	return tbRetPos;
end

--@function: 获取计算得到的受击者对象
function KGC_SKILL_BASE_TYPE:GetTargetObj()
	return self.m_Targets;
end

--基准位置
function KGC_SKILL_BASE_TYPE:IsValidSelectType(nType)
	nType = nType or 0;
	if nType >= l_tbTargetSelectMethod.M_MIN and nType <= l_tbTargetSelectMethod.M_MAX then
		return true;
	end
	return false;
end

function KGC_SKILL_BASE_TYPE:GetRange(nType, tbPos)
	local tbRet = {}
	if type(tbPos) ~= "table" then
		cclog("[Warning]没有基准位置！")
		return {}
	end
	
	if not gf_IsValidPos(tbPos[1]) then
		cclog("[Warning]基准位置是无效的(%s)", tostring(tbPos[1]))
		return {};
	end

	local MAX_COL = 3;
	local MAX_ROW = 2;
	local getCol = function(nPos)
		nPos = nPos or 1;
		local nCol = nPos%MAX_COL
		if nCol == 0 then 
			nCol = MAX_COL;
		end
		return nCol
	end
	local getRow = function(nPos)
		nPos = nPos or 1
		local nRow = (math.floor((nPos-1)/MAX_COL))%MAX_ROW + 1
		return nRow;
	end
	
	local getAll = function(nPos)
		local tbRet = {}
		for i = l_tbPos.POS_MIN, l_tbPos.POS_MAX do
			table.insert(tbRet, i);
		end
		return tbRet;
	end
	
	local getRows = function(nPos)
		local tbRet = {}
		local nRow = getRow(nPos)
		for i=1, MAX_COL do
			table.insert(tbRet, (nRow-1)*MAX_COL + i)
		end
		return tbRet;
	end
	
	local getCols = function(nPos)
		local tbRet = {}
		local nCol = getCol(nPos)
		for i=1, MAX_ROW do
			table.insert(tbRet, (i-1)*MAX_COL + nCol)
		end
		return tbRet;
	end
	
	local mesh = function(tbPos, tbTemp)
		tbTemp = tbTemp or {}
		tbPos = tbPos or {}
		local tbHash = {}
		for _, pos in ipairs(tbPos) do
			tbHash[pos] = true;
		end
		for _, pos in ipairs(tbTemp) do
			if not tbHash[pos] then
				table.insert(tbPos, pos);
				tbHash[pos] = true;
			end
		end
		return tbPos;
	end
	--test
	for i=1, 10 do
		-- local nRand = gf_Random(6)
		-- print("nRand", nRand)
		-- print("getCol", getCol(nRand))
		-- print("getRow", getRow(nRand))
		-- print("getAll", unpack(getAll(nRand)))
		-- print("getRows", unpack(getRows(nRand)))
		-- print("getCols", unpack(getCols(nRand)))
	end
	print("[skill]攻击范围类型：", l_tbSSName[nType], nType)
	-- for k, v in ipairs(tbPos) do
		-- print(v)
	-- end
	-- print("+++")
	--test end
	
	--logic
	nType = nType or l_tbSkillScope.SINGLE

	if nType == l_tbSkillScope.SINGLE then			--单体
		tbRet = tbPos;
	elseif nType == l_tbSkillScope.ALL then			--全体
		tbRet = getAll();
	elseif nType == l_tbSkillScope.ROW then			--横排
		for _, nPos in ipairs(tbPos) do
			local tbTemp = getRows(nPos)
			tbRet = mesh(tbRet, tbTemp)
		end
	elseif nType == l_tbSkillScope.COL then			--竖列
		for _, nPos in ipairs(tbPos) do
			local tbTemp = getCols(nPos)
			tbRet = mesh(tbRet, tbTemp)
		end
	elseif nType == l_tbSkillScope.CROSS then		--十字
		for _, nPos in ipairs(tbPos) do
			local tbTemp = getRows(nPos)
			tbRet = mesh(tbRet, tbTemp)
			tbTemp = getCols(nPos)
			tbRet = mesh(tbRet, tbTemp)
		end
	else											--填其他数字，原路返回
		tbRet = tbPos;
	end
	--test
	-- print("位置：")
	-- for k, v in ipairs(tbRet) do
		-- print(v)
	-- end
	--test end
	
	return tbRet;
end

--@function：触发技能条件触发
function KGC_SKILL_BASE_TYPE:StartTriggerSkillsCondition(tbIDs, targets)
	local tbIDs = tbIDs;
	
	--以下：默认是触发类技能
	if not tbIDs then
		tbIDs = {};
		if self:GetCastType() == 2 then
			--notify:注意这里是连续的才能这样写
			for id=l_tbCondID.CAST_1, l_tbCondID.CAST_4 do
				local tbCond = l_tbConditions[id]
				local nArg1 = tbCond.arg1 or 0;
				if nArg1 == self:GetType() then
					table.insert(tbIDs, id);
				end
			end
		end
	end
	
	local nCount = 0;
	-- print("#tbIDs", #tbIDs)
	for _, id in ipairs(tbIDs) do
		if id > 0 then
			g_CondTrigger:Notify(self, id)
		end
		
		nCount = nCount + 1
	end
	print("[skillbase]@StartTriggerSkillsCondition成功触发条件个数：", nCount, self:GetName())
	
	-- 条件: 信念， 攻击者和受击者相同阵营
	if self:GetTarCamp() == l_tbCamp.MINE then
		g_CondTrigger:Notify(self, l_tbCondID.FAITH)
	end
end

function KGC_SKILL_BASE_TYPE:GetCondIDByCastType(nType)
	local tbCondIDs = {
		[l_tbSkillType.NORMAL] = l_tbCondID.CAST_1,
		[l_tbSkillType.CONTRACT] = l_tbCondID.CAST_2,
		[l_tbSkillType.COMBO] = l_tbCondID.CAST_3,
		[l_tbSkillType.MAGIC] = l_tbCondID.CAST_4,
	}
	local nType = self:GetType();
	return tbCondIDs[nType];
end

function KGC_SKILL_BASE_TYPE:GetCastRet()
	return self.m_nRet;
end

--@function: 设置触发释放本技能的相关信息(连携、多重施法)
function KGC_SKILL_BASE_TYPE:SetSrcInfo(tbSrc)
	self.m_tbSrc = tbSrc;
end

function KGC_SKILL_BASE_TYPE:GetSrcInfo()
	if not self.m_tbSrc then
		self.m_tbSrc = {};
	end
	return self.m_tbSrc;
end
-----------------------------------------------------------------
function KGC_SKILL_BASE_TYPE:IsSkill()
	return true;
end

function KGC_SKILL_BASE_TYPE:IsCombo()
	return false;
end

function KGC_SKILL_BASE_TYPE:GetCost()
	return self.m_nCost or 0;
end

function KGC_SKILL_BASE_TYPE:SetCost(nCost)
	self.m_nCost = nCost or 0;
end

function KGC_SKILL_BASE_TYPE:SetHeros(tbHeros)
	if type(tbHeros) ~= "table" then
		return;
	end
	
	self.m_tbHeros = tbHeros
	self.m_Hero = tbHeros[1]
end

function KGC_SKILL_BASE_TYPE:GetHeros()
	return self.m_tbHeros;
end

--@function: 获取技能释放者
function KGC_SKILL_BASE_TYPE:GetCaster()
	return self.m_Hero;
end

function KGC_SKILL_BASE_TYPE:GetNpc()
	return self.m_Hero;
end

function KGC_SKILL_BASE_TYPE:SetPro(pro)
	pro = pro or 0;
	self.m_fPro = pro;
end

function KGC_SKILL_BASE_TYPE:GetPro()
	return self.m_fPro;
end

function KGC_SKILL_BASE_TYPE:GetID()
	return self.m_nID;
end

function KGC_SKILL_BASE_TYPE:GetName()
	return self.m_szName;
end

function KGC_SKILL_BASE_TYPE:SetName(szName)
	self.m_szName = szName or "";
end

function KGC_SKILL_BASE_TYPE:SetDesc(szDesc)
	self.m_szDesc = szDesc or "";
end

function KGC_SKILL_BASE_TYPE:GetDesc()
	return self.m_szDesc;
end

function KGC_SKILL_BASE_TYPE:SetFightText(szText)
	self.m_szFightText = szText or "";
end

--@function: 战斗界面的播报显示
function KGC_SKILL_BASE_TYPE:GetFightText()
	return self.m_szFightText;
end

function KGC_SKILL_BASE_TYPE:SetIcon(szIcon)
	self.m_szIcon = szIcon or "";
end

function KGC_SKILL_BASE_TYPE:GetIcon()
	return self.m_szIcon;
end

function KGC_SKILL_BASE_TYPE:SetCastType(nType)
	nType = nType or 0;
	self.m_nCastType = nType;
end

function KGC_SKILL_BASE_TYPE:GetCastType()
	return self.m_nCastType;
end

function KGC_SKILL_BASE_TYPE:SetCondID(nCondID)
	self.m_nCondID = nCondID or 0;
end

function KGC_SKILL_BASE_TYPE:GetCondID()
	return self.m_nCondID;
end

function KGC_SKILL_BASE_TYPE:SetType(nType)
	self.m_nType = nType or 0;
end

function KGC_SKILL_BASE_TYPE:GetType()
	return self.m_nType;
end

function KGC_SKILL_BASE_TYPE:SetLevel(nLevel)
	self.m_nLevel = nLevel or 0;
end

function KGC_SKILL_BASE_TYPE:GetLevel()
	return self.m_nLevel;
end

function KGC_SKILL_BASE_TYPE:SetTarCamp(nCamp)
	self.m_nTarCamp = nCamp or 0;
end

function KGC_SKILL_BASE_TYPE:GetTarCamp()
	return self.m_nTarCamp;
end

function KGC_SKILL_BASE_TYPE:SetEffectByID(nID)
	-- tst_PrintTime(9000)
	self.m_nEffID = nEffectType or 0;
	-- local tbConfig = require("script/cfg/skillresults")
	-- tst_PrintTime(9001)
	local tbEffect = l_tbResultConfig[nID]
	if not tbEffect then
		print("[Error]配置表错误或者ID错误, nID = ", nID)
	end
	local tbData = self:GetEffectData();
	tbData.nID = tbEffect.id
	tbData.nType = tbEffect.effecttype;
	-- print("SetEffectByID", tbData.nType)
	-- print("GetEffectType", self:GetEffectType());
	tbData.tbState = tbData.tbState or {}
	if type(tbEffect.status) == "table" then
		tbData.tbState.nStaID = tbEffect.status[1] or 0;
		tbData.tbState.nConID = tbEffect.status[2] or 0;
	end
	tbData.tbDisPel = tbEffect.dispel;
	tbData.tbArgs[1] = tbEffect.arg1
	tbData.tbArgs[2] = tbEffect.arg2
	tbData.tbArgs[3] = tbEffect.arg3
	tbData.tbArgs[4] = tbEffect.arg4
	tbData.tbArgs[5] = tbEffect.arg5
	tbData.tbArgs[6] = tbEffect.arg6
	tbData.tbArgs[7] = tbEffect.arg7
	tbData.tbArgs[8] = tbEffect.arg8
	-- tst_PrintTime(9002)
end

function KGC_SKILL_BASE_TYPE:GetEffectData()
	if not self.m_tbEffData then
		self.m_tbEffData = {}
	end
	return self.m_tbEffData;
end

function KGC_SKILL_BASE_TYPE:GetEffectID()
	local tbData = self:GetEffectData()
	return tbData.nID;
end

function KGC_SKILL_BASE_TYPE:GetEffectType()
	local tbData = self:GetEffectData()
	return tbData.nType;
end

function KGC_SKILL_BASE_TYPE:GetEffectArgs()
	local tbData = self:GetEffectData()
	return tbData.tbArgs;
end

function KGC_SKILL_BASE_TYPE:GetEffectState()
	local tbData = self:GetEffectData()
	return tbData.tbState.nStaID, tbData.tbState.nConID;
end

--@function: 目标筛选相关参数
--@nType: 目标筛选方式
--@tbPos: 基准位置
--@nCost: 目标费用参数
--@nTarget2: 二次目标筛选
function KGC_SKILL_BASE_TYPE:SetTargetSelect(nType, tbPos, nCost, nTarget2, nRangeType, nMax)
	if not self.m_tbTargetSelect then
		self.m_tbTargetSelect = {}
		self.m_tbTargetSelect.tbPos = {};
	end
	
	self:SetSelectType(nType);
	self:SetSelectPos(tbPos)
	self:SetSelectCost(nCost)
	self:SetSelectTarget2(nTarget2)
	self:SetSelectRangeType(nRangeType)
	self:SetSelectMax(nMax)
end

function KGC_SKILL_BASE_TYPE:SetSelectType(nType)
	self.m_tbTargetSelect.nType = nType or 0;
end

function KGC_SKILL_BASE_TYPE:GetSelectType()
	return self.m_tbTargetSelect.nType;
end

function KGC_SKILL_BASE_TYPE:SetSelectPos(tbPos)
	self.m_tbTargetSelect.tbPos = tbPos or {};
end

function KGC_SKILL_BASE_TYPE:GetSelectPos()
	return self.m_tbTargetSelect.tbPos;
end

function KGC_SKILL_BASE_TYPE:SetSelectCost(nCost)
	self.m_tbTargetSelect.nCost = nCost or 0;
end

function KGC_SKILL_BASE_TYPE:GetSelectCost()
	return self.m_tbTargetSelect.nCost;
end

function KGC_SKILL_BASE_TYPE:SetSelectTarget2(nTarget2)
	self.m_tbTargetSelect.nTarget2 = nTarget2 or 0;
end

function KGC_SKILL_BASE_TYPE:GetSelectTarget2()
	return self.m_tbTargetSelect.nTarget2;
end

function KGC_SKILL_BASE_TYPE:SetSelectRangeType(nType)
	self.m_tbTargetSelect.nRangeType = nType or 0;
end

function KGC_SKILL_BASE_TYPE:GetSelectRangeType()
	return self.m_tbTargetSelect.nRangeType;
end

function KGC_SKILL_BASE_TYPE:SetSelectMax(nMax)
	self.m_tbTargetSelect.nMax = nMax or 0;
end

function KGC_SKILL_BASE_TYPE:GetSelectMax()
	return self.m_tbTargetSelect.nMax;
end

function KGC_SKILL_BASE_TYPE:IsSameSkill(skill)
	--首先比较ID
	if skill:IsSkill() and skill:GetID() == self:GetID() then
		local heros1 = self:GetHeros()
		local heros2 = skill:GetHeros()

		local tbPos1, tbPos2 = {}, {}
		for _, hero in pairs(heros1) do
			-- print("heros1, pos", hero:GetPos())
			table.insert(tbPos1, hero:GetPos())
		end
		table.sort(tbPos1)
		for _, hero in pairs(heros2) do
			-- print("heros2, pos", hero:GetPos())
			table.insert(tbPos2, hero:GetPos())
		end
		table.sort(tbPos2)
		if #tbPos1 == #tbPos2 then
			local nCount = 0;
			for i=1, #tbPos1 do
				if tbPos1[i] ~= tbPos2[i] then
					break;
				end
				nCount = nCount + 1;
			end
			if nCount == #tbPos1 then
				return true;
			end
		end
	end
	return false;
end

function KGC_SKILL_BASE_TYPE:AddStateRet(tbElem)
	if not self.m_tbRetStates then
		self.m_tbRetStates = {}
	end

	tbElem = tbElem or {}

	--顺序ipairs
	for _, elem in ipairs(tbElem) do
		table.insert(self.m_tbRetStates, elem);
	end
end

function KGC_SKILL_BASE_TYPE:SetCastRet(nRet)
	self.m_nCastRet = nRet or l_tbSkillCastRet.SUCCESS
end

--@function: 判断技能是否是普通技能
function KGC_SKILL_BASE_TYPE:IsNormal()
	local nType = self:GetType();
	if l_tbSkillType.NORMAL_0 == nType then
		return true;
	end
	
	return false;
end
-- function KGC_SKILL_BASE_TYPE:GetCastRet2()
	-- return self.m_nCastRet;
-- end
----------------------------------------------------------

--relization

----------------------------------------------------------
--test
----------------------------------------------------------