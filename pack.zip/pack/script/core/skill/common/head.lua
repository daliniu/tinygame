----------------------------------------------------------
-- file:	head.lua
-- Author:	page
-- Time:	2015/02/02	15:49
-- Desc:	common skills interface for outer
----------------------------------------------------------
require "script/core/skill/common/normal"
require "script/core/skill/common/contract"
require "script/core/skill/common/combo"
require "script/core/skill/common/magic"

