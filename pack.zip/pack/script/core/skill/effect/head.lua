----------------------------------------------------------
-- file:	head.lua
-- Author:	page
-- Time:	2015/04/02	09:53:01
-- Desc:	effect interface for outer
----------------------------------------------------------
require "script/core/skill/effect/effect_attack"

