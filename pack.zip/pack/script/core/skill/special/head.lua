----------------------------------------------------------
-- file:	head.lua
-- Author:	page
-- Time:	2015/03/25	16:08
-- Desc:	special skills interface for outer
----------------------------------------------------------
require "script/core/skill/special/state_taunt"
require "script/core/skill/special/state_shield"

