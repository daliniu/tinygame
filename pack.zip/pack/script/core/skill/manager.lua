----------------------------------------------------------
-- file:	skill.lua
-- Author:	page
-- Time:	2015/02/02 10:41
-- Desc:	技能管理类，全局
--			
----------------------------------------------------------
require "script/core/head"
require "script/core/skill/common/head"
----------------------------------------------------------
local l_tbSkillsInfo = require("script/cfg/skills")

local l_tbSkillType = def_GetSkillTypeData();

--data struct
local TB_SKILL_DATA = {
	--config
	------------------------------------
	------------------------------------
	m_tbSkillsID2Obj = {
		[l_tbSkillType.NORMAL_0] = KGC_SKILL_NORMAL_TYPE,
		[l_tbSkillType.NORMAL] = KGC_SKILL_NORMAL_TYPE,
		[l_tbSkillType.CONTRACT] = KGC_SKILL_CONTRACT_TYPE,
		[l_tbSkillType.COMBO] = KGC_SKILL_COMBO_TYPE,
		-- [l_tbSkillType.CON_CLOUD_PLAIN] = KGC_SKILL_CONTRACT_CLOUD_PLAIN_TYPE,
		[l_tbSkillType.MAGIC] = KGC_SKILL_MAGIC_TYPE,
	}
	--每一个具体技能需要注册到该类中
	-- m_tbSkillsClass = {},
}

KGC_SKILL_MANAGER_TYPE = class("KGC_SKILL_MANAGER_TYPE", CLASS_BASE_TYPE, TB_SKILL_DATA)
----------------------------------------
--function
----------------------------------------
function KGC_SKILL_MANAGER_TYPE:Init()
end

----------------------------------------------------------
function KGC_SKILL_MANAGER_TYPE:CastSkill(launchers, targets, skill, products)
	if type(launchers) ~= "table" or type(targets) ~= "table" then
		cclog("[Error]launchers or targets is NULL！@CastSkill()")
		return false;
	end
	-- cclog("释放技能CastSkill：|||||%s|||||", skill:GetName())
	if not skill then
		return;
	end
-- tst_PrintTime(10000)
	local tbLauncher, tbDefends, tbRetState, nRet = skill:Cast(launchers, targets, products)
-- tst_PrintTime(10001)	
	return tbLauncher, tbDefends, tbRetState, nRet;
end

function KGC_SKILL_MANAGER_TYPE:CreateSkill(nID, tbConfig)
-- tst_PrintTime(6000)
	local skillType = self:GetSkillType(nID)
	local skill = skillType.new()
	local tbInfo = self:GetSkillInfo(nID)
-- tst_PrintTime(6001)
	-------------------------------------
	--config
	tbConfig = tbConfig or {} ---???question：以后修改为配置表读取的数据
	tbConfig.nID = nID;

	skill:Init(tbConfig, tbInfo)
	-------------------------------------
-- tst_PrintTime(6002)
	return skill;
end

function KGC_SKILL_MANAGER_TYPE:GetSkillType(nID)
	local skillType =  self.m_tbSkillsID2Obj[nID]
	if not skillType then
		local tbInfo = self:GetSkillInfo(nID)
		skillType = self.m_tbSkillsID2Obj[tbInfo.type]
	end
	
	--触发类技能
	-- if tbInfo.casttype == 1 then
		-- skillType = KGC_SKILL_TRIGGER_TYPE;
	-- end
	
	return skillType;
end

-- function KGC_SKILL_MANAGER_TYPE:IsComboSkill(nID)
	-- return nID == l_tbSkillType.COMBO;
-- end

function KGC_SKILL_MANAGER_TYPE:GetSkillInfo(nID)
	if not l_tbSkillsInfo[nID] then
		cclog("[Error]没有找到技能信息GetSkillInfo(%s)", nID);
	end
	return l_tbSkillsInfo[nID]
end
----------------------------------------------------------

--数据结构
--[[
m_tbProducts = {
	--攻击者数据
	[1] = {位置ID, 技能, },
	--被攻击者数据
	[2] = {位置ID, 伤害, 被动},
}

--战斗过程数据结构
m_tbStructFightData = {
	ship = me/tbEnemy,
	tbHeros = {
		[1] = {
			hero = nil,
			tbFightInfo = {
				nPos = ,					--位置信息，有可能被击到别的位置
				nHp=,						--血量
				nCost,						--费用
				nState,						--状态{死亡}
				tbNpcAttribute = {			--特殊一些魔法属性:buff类
					--在前还是后，直接作为属性类的一个成员
				},		
			},
		}
		[2] = {},
	}
}
]]

--relization
g_SkillManager = KGC_SKILL_MANAGER_TYPE.new(TB_SKILL_DATA)
----------------------------------------------------------
--test
----------------------------------------------------------
