----------------------------------------------------------
-- file:	factory.lua
-- Author:	page
-- Time:	2015/12/02 16:02 
-- Desc:	pvp竞技场数据处理工厂
----------------------------------------------------------
--data struct 
local TB_STRUCT_ARENA_FACTORY = {
	m_Instance = nil;
	----------------------------------
	-- 1. 日赛
	m_bArenaNormalSignup = false,			-- 是否报名
	m_nArenaNormalWinCount = 0,			-- 已经胜利的场数统计
	m_tbRewardFlag = {},				-- 宝箱领取标记
	m_nArenaNormalFightCount = 0,		-- 战斗次数
	
	-- 2. 日锦标赛
	m_bDailySignup = false,				-- 是否已经报名
	m_tbDailyChipsFightInfo = {},			-- 筹码赛战斗数据
	m_tbDailyEightFightInfo = {},		-- 八强赛战斗数据
	m_nArenaDailyChipsTurn = 0,			-- 筹码赛自己打了多少轮
	m_nArenaDailyChipsMaxTurn = 0,		-- 筹码赛最大轮
	m_nArenaDailyChipsRank = 0,			-- 筹码赛阶段的排名
}
--------------------------------)
KGC_ARENA_FACTORY_TYPE = class("KGC_ARENA_FACTORY_TYPE", CLASS_BASE_TYPE, TB_STRUCT_ARENA_FACTORY)
--------------------------------
--function
--------------------------------

function KGC_ARENA_FACTORY_TYPE:ctor()	
	
end
--------------------------------------------------------------
function KGC_ARENA_FACTORY_TYPE:Init(tbArg)
	--test
	self:UnpackDailyChipsFightInfo({});
	--test end
end

--@function: 单例
function KGC_ARENA_FACTORY_TYPE:getInstance()
	if not self.m_Instance then
		self.m_Instance = KGC_ARENA_FACTORY_TYPE.new();
		self.m_Instance:Init();
	end
	return self.m_Instance;
end

--@function: 数据解包
function KGC_ARENA_FACTORY_TYPE:UnpackData(tbNormal, tbDaily, tbWeekly)
	self:UnpackNormalData(tbNormal);
	self:UnpackDailyData(tbNormal, tbDaily);
	self:UnpackWeeklyData(tbNormal, tbWeekly);
end

--@function: 日竞技赛数据解包
function KGC_ARENA_FACTORY_TYPE:UnpackNormalData(tbData)
	if not tbData then
		cclog("[Waning]没有日竞技赛数据解包!");
		return;
	end

	-- 标记
	local nStartMark = tonumber(tbData.startMark);
	self:SetArenaNormalSignup(nStartMark == 1);		-- 1表示已经报名
	
	-- 宝箱领取标记
	local nIsGet1 = tonumber(tbData.box1);
	local nIsGet2 = tonumber(tbData.box2);
	local nIsGet3 = tonumber(tbData.box3);
	self:SetArenaNormalRewardFlag(nIsGet1, nIsGet2, nIsGet3);
	
	-- 战斗次数
	local nFightCount = tonumber(tbData.fightCount);
	self:SetArenaNormalFightCount(nFightCount);
	
	-- 对战玩家(机器人)数据
	local tbFightInfo = tbData.fightInfoListDay;
end

--@function: 日锦标赛数据解包
function KGC_ARENA_FACTORY_TYPE:UnpackDailyData(tbNormalData, tbDailyData)
	if not tbNormalData and not tbDailyData then
		cclog("[Waning]没有日锦标赛数据解包!");
		return;
	end
	
	-- 报名标志
	local nMark = tbNormalData.dayMark;
	self:SetDailySignup(nMark == 1);				-- 1表示已经报名
end

--@function: 周锦标赛数据解包
function KGC_ARENA_FACTORY_TYPE:UnpackWeeklyData(tbData)
	
end

--@function: pvpinfo数据解包
function KGC_ARENA_FACTORY_TYPE:UnpackNormalFightInfo(tbData)
	if not tbData then
		return;
	end
	self.m_tbNormalFightInfo = {};
	
	-- test 
	local tbData = self:TestCreateFightInfo();
	-- test end
	local nWinCount = 0;
	for _, data in pairs(tbData or {}) do
		local playerData = data.enemy;
		local player = KGC_PLAYER_FACTORY_TYPE:getInstance():CreatePlayer(playerData);
		local nResult = data.result;
		local nMasterScore = data.ticketDay;
		table.insert(self.m_tbNormalFightInfo, {player, nResult, nMasterScore});
		
		-- 统计已经打印了几场
		if nResult == 1 then
			nWinCount = nWinCount + 1;
		end
	end
	
	self:SetArenaNormalWinCount(nWinCount);
end

--@function: 日赛胜场
function KGC_ARENA_FACTORY_TYPE:SetArenaNormalWinCount(nCount)
	self.m_nArenaNormalWinCount = nCount or 0;
end

function KGC_ARENA_FACTORY_TYPE:GetArenaNormalWinCount()
	--test
	self.m_nArenaNormalWinCount = math.random(3);
	--test end
	return self.m_nArenaNormalWinCount;
end

--@function: 战斗次数
function KGC_ARENA_FACTORY_TYPE:SetArenaNormalFightCount(nCount)
	self.m_nArenaNormalFightCount = nCount or 0;
end

function KGC_ARENA_FACTORY_TYPE:GetArenaNormalFightCount()
	--test
	self.m_nArenaNormalFightCount = math.random(50);
	--test end
	return self.m_nArenaNormalFightCount;
end

--@function: 是否已经报名
function KGC_ARENA_FACTORY_TYPE:IsArenaNormalSignup()
	return self.m_bArenaNormalSignup;
end

function KGC_ARENA_FACTORY_TYPE:SetArenaNormalSignup(bSignup)
	self.m_bArenaNormalSignup = bSignup or false;
end

--@function: 是否已经报名
function KGC_ARENA_FACTORY_TYPE:GetArenaNormalRewardFlag()
	if not self.m_tbRewardFlag then
		self.m_tbRewardFlag = {};
	end
	return self.m_tbRewardFlag;
end

--@function: 宝箱领取标记
function KGC_ARENA_FACTORY_TYPE:SetArenaNormalRewardFlag(nIsGet1, nIsGet2, nIsGet3)
	if not self.m_tbRewardFlag then
		self.m_tbRewardFlag = {};
	end
	
	self.m_tbRewardFlag[1] = nIsGet1;
	self.m_tbRewardFlag[2] = nIsGet2;
	self.m_tbRewardFlag[3] = nIsGet3;
end

function KGC_ARENA_FACTORY_TYPE:GetNormalFightInfo()
	--test
	self:UnpackNormalFightInfo({});
	--test end
	return self.m_tbNormalFightInfo;
end

--------------------
-- 日锦标赛
--@function: 日锦标赛是否已经报名
function KGC_ARENA_FACTORY_TYPE:SetDailySignup(bSignup)
	self.m_bDailySignup = bSignup or false;
end

function KGC_ARENA_FACTORY_TYPE:IsDailySignup()
	return self.m_bDailySignup;
end

--@function: 打了多少轮
function KGC_ARENA_FACTORY_TYPE:SetArenaDailyTurn(nTurn, nMaxTurn)
	self.m_nArenaDailyChipsTurn = nTurn or 0;
	self.m_nArenaDailyChipsMaxTurn = nMaxTurn or 0;
end

function KGC_ARENA_FACTORY_TYPE:GetArenaDailyTurn()
	return self.m_nArenaDailyChipsTurn, self.m_nArenaDailyChipsMaxTurn;
end

--@function: 设置筹码赛时候的排名
function KGC_ARENA_FACTORY_TYPE:SetDailyChipsRank(nRank)
	self.m_nArenaDailyChipsRank = nRank or 0;
end

function KGC_ARENA_FACTORY_TYPE:GetDailyChipsRank()
	return self.m_nArenaDailyChipsRank;
end

--@function: pvpinfo数据解包：筹码赛
function KGC_ARENA_FACTORY_TYPE:UnpackDailyChipsFightInfo(tbData, nMaxTurn)
	if not tbData then
		return;
	end
	self.m_tbDailyChipsFightInfo = {};
	
	-- test 
	local _, tbData = self:TestCreateFightInfo();
	local nMaxTurn = math.random(10);
	-- test end

	local nTurn = 0;
	for _, data in pairs(tbData or {}) do
		local playerData1 = data.player1;
		local player1 = KGC_PLAYER_FACTORY_TYPE:getInstance():CreatePlayer(playerData1);
		local playerData2 = data.player2;
		local player2 = KGC_PLAYER_FACTORY_TYPE:getInstance():CreatePlayer(playerData2);
		local nWinner = data.winner;
		local nSeed = data.seed;
		local tbReward = data.fightReward;
		table.insert(self.m_tbDailyChipsFightInfo, {player1, player2, nSeed, nWinner});
		nTurn = nTurn + 1;
	end
	--test
	if nTurn >= nMaxTurn then
		nTurn = nMaxTurn;
	end
	--test end
	self:SetArenaDailyTurn(nTurn, nMaxTurn);
end

--@function: pvpinfo数据解包: 八强赛
function KGC_ARENA_FACTORY_TYPE:UnpackDailyEightFightInfo(tbData, nRank)
	-- 筹码赛时候的排名
	self:SetDailyChipsRank(nRank);
	
	if not tbData then
		return;
	end
	self.m_tbDailyEightFightInfo = {};
	self.m_tbDailyEightFightInfo.m_tbSelfData = {};
	
	-- test 
	local _, _ = self:TestCreateFightInfo();
	local nRank = math.random(20);
	-- test end

	local fnUnpack = function(data)
		local playerData1 = data.player1;
		local player1 = KGC_PLAYER_FACTORY_TYPE:getInstance():CreatePlayer(playerData1);
		local playerData2 = data.player2;
		local player2 = KGC_PLAYER_FACTORY_TYPE:getInstance():CreatePlayer(playerData2);
		local nWinner = data.winner;
		local nSeed = data.seed;
		local tbReward = data.fightReward;
		
		local tbRet = {player1, player2, nSeed, nWinner};
		-- 是不是自己
		if player1:GetAccount() == me:GetAccount() or player2:GetAccount() == me:GetAccount() then
			table.insert(self.m_tbDailyEightFightInfo.m_tbSelfData, tbRet);
		end
		
		return tbRet;
	end
	-- 第1轮
	self.m_tbDailyEightFightInfo[1] = {};
	for _, data in pairs(tbData.fightList8) do
		local tbFightInfo = fnUnpack(data);
		table.insert(self.m_tbDailyEightFightInfo[1], tbFightInfo);
	end
	
	-- 第2轮
	self.m_tbDailyEightFightInfo[2] = {};
	for _, data in pairs(tbData.fightList4) do
		local tbFightInfo = fnUnpack(data);
		table.insert(self.m_tbDailyEightFightInfo[2], tbFightInfo);
	end
	
	-- 第3轮
	self.m_tbDailyEightFightInfo[3] = {};
	for _, data in pairs(tbData.fightList2) do
		local tbFightInfo = fnUnpack(data);
		table.insert(self.m_tbDailyEightFightInfo[3], tbFightInfo);
	end
	
	-- 第4轮
	self.m_tbDailyEightFightInfo[4] = {};
	for _, data in pairs(tbData.fightList1) do
		local tbFightInfo = fnUnpack(data);
		table.insert(self.m_tbDailyEightFightInfo[4], tbFightInfo);
	end

end

function KGC_ARENA_FACTORY_TYPE:GetDailyFightInfo()
	return self.m_tbDailyChipsFightInfo;
end

--@function: 当前是哪一个阶段，阶段的哪一步
function KGC_ARENA_FACTORY_TYPE:GetCurrentStage()
	local tbTime = {
		hour = 17,
		min = 27,
		sec = 0,
	}
	
	local nInterval = 30;	--(s)
	local nWait = 30;		--(s)
	local nDiff = tf_DiffWithTime(tbTime)
	-- 5分钟一个阶段
	
	local nChipsTurn, nChipsMaxTurn = self:GetArenaDailyTurn();
	local nChipsTime = nChipsMaxTurn * nInterval + nWait;
	
	local nStage = 0;
	local nStep = 0;
	if nDiff > 0 and nDiff < nChipsTime then		-- 筹码赛阶段
		nStage = 1;
		nStep = math.floor(nDiff/(1*nInterval)) + 1;
	elseif nDiff >= nChipsTime then					-- 八强赛阶段
		nStage = 2;
		nStep = math.floor((nDiff-nChipsTime)/(1*nInterval)) + 1;
	end
	--test
	-- local tbDailyFightInfo = self:GetDailyFightInfo();
	-- nStage = math.random(#(tbDailyFightInfo or {}));
	-- print("GetCurrentStage: ", nStage);
	--test
	
	return nStage, nStep;
end

--@function: 是否在战斗阶段
function KGC_ARENA_FACTORY_TYPE:IsFightState()
	local bIsSignup = self:IsDailySignup();
	--test
	bIsSignup = true;
	--test
	local nStage, nStep = self:GetCurrentStage();
	local nTurn, nMaxTurn = self:GetArenaDailyTurn();
	print("IsFightState: ", bIsSignup, nStage, nTurn);
	-- 筹码赛阶段
	if nStage == 1 and bIsSignup and nStage <= nTurn and nStage >= 1 then
		return true;
	end
	
	-- 八强赛阶段
	if false then
		return true;
	end
	
	return false;
end
------------------------------------------------------
--test

function KGC_ARENA_FACTORY_TYPE:TestCreateFightInfo()
local tbPlayerInfo = {
	 ["level"] = 50,
	 ["uuid"] = "test023",
	 ["teamList"] = {
		 ["10013"] = {
			 ["level"] = 50,
			 ["star"] = 1,
			 ["skillSlotList"] = {
				 ["4"] = {
					 ["level"] = 1,
				 },
				 ["1"] = {
					 ["level"] = 2,
				 },
				 ["5"] = {
					 ["level"] = 1,
				 },
				 ["2"] = {
					 ["level"] = 2,
				 },
				 ["6"] = {
					 ["level"] = 1,
				 },
				 ["3"] = {
					 ["level"] = 1,
				 },
			 },
			 ["suitId2"] = 63,
			 ["heroId"] = 10013,
			 ["suitId1"] = 61,
			 ["pos"] = 4,
			 ["suitId3"] = 64,
			 ["quality"] = 0,
			 ["suitId4"] = 64,
			 ["curExp"] = 5358,
			 ["suitId5"] = 64,
		 },
		 ["10004"] = {
			 ["level"] = 28,
			 ["star"] = 1,
			 ["skillSlotList"] = {
				 ["4"] = {
					 ["level"] = 1,
				 },
				 ["1"] = {
					 ["level"] = 1,
				 },
				 ["5"] = {
					 ["level"] = 1,
				 },
				 ["2"] = {
					 ["level"] = 1,
				 },
				 ["6"] = {
					 ["level"] = 1,
				 },
				 ["3"] = {
					 ["level"] = 1,
				 },
			 },
			 ["suitId2"] = 17,
			 ["heroId"] = 10004,
			 ["suitId1"] = 17,
			 ["pos"] = 6,
			 ["suitId3"] = 20,
			 ["quality"] = 0,
			 ["suitId4"] = 18,
			 ["curExp"] = 3375,
			 ["suitId5"] = 17,
		 },
		 ["10003"] = {
			 ["level"] = 50,
			 ["star"] = 1,
			 ["skillSlotList"] = {
				 ["4"] = {
					 ["level"] = 1,
				 },
				 ["1"] = {
					 ["level"] = 1,
				 },
				 ["5"] = {
					 ["level"] = 1,
				 },
				 ["2"] = {
					 ["level"] = 1,
				 },
				 ["6"] = {
					 ["level"] = 1,
				 },
				 ["3"] = {
					 ["level"] = 1,
				 },
			 },
			 ["suitId2"] = 13,
			 ["heroId"] = "10003",
			 ["suitId1"] = 12,
			 ["pos"] = 5,
			 ["suitId3"] = 14,
			 ["quality"] = 1,
			 ["suitId4"] = 15,
			 ["curExp"] = 6443,
			 ["suitId5"] = 14,
		 },
	 },
	 ["equipList"] = {
		 ["2"] = {
			 ["14474831229752800"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110103,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
			 ["14474870914212300"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110104,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
			 ["14476450424007100"] = {
				 ["star"] = 0,
				 ["n2"] = 10,
				 ["id"] = 10128,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = 3,
				 ["a2"] = 2,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = 0,
				 ["a3"] = 0,
				 ["n1"] = 999,
			 },
			 ["14476450066282900"] = {
				 ["star"] = 0,
				 ["n2"] = 10,
				 ["id"] = 10104,
				 ["n3"] = 99,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = 3,
				 ["a2"] = 2,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = 0,
				 ["a3"] = 1,
				 ["n1"] = 999,
			 },
		 },
		 ["1"] = {
			 ["14484188353335000"] = {
				 ["star"] = 0,
				 ["n2"] = 25,
				 ["id"] = 10103,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = 5,
				 ["a2"] = 6,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = 0,
				 ["a3"] = 0,
				 ["n1"] = 70,
			 },
			 ["14484188353345700"] = {
				 ["star"] = 0,
				 ["n2"] = 234,
				 ["id"] = 10109,
				 ["n3"] = 111,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = 1,
				 ["a2"] = 4,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = 0,
				 ["a3"] = 3,
				 ["n1"] = 11,
			 },
			 ["14474830623462000"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110103,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
			 ["14484188353356000"] = {
				 ["star"] = 0,
				 ["n2"] = 999,
				 ["id"] = 10155,
				 ["n3"] = 22,
				 ["n4"] = 11,
				 ["sn"] = 0,
				 ["a1"] = 1,
				 ["a2"] = 3,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = 2,
				 ["a3"] = 4,
				 ["n1"] = 11,
			 },
		 },
		 ["3"] = {
			 ["14474871468835000"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110101,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
			 ["14478470416077400"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110102,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
			 ["14474864469226600"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110103,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
			 ["14478470727050300"] = {
				 ["star"] = 0,
				 ["n2"] = 0,
				 ["id"] = 110106,
				 ["n3"] = 0,
				 ["n4"] = 0,
				 ["sn"] = 0,
				 ["a1"] = -1,
				 ["a2"] = -1,
				 ["num"] = 1,
				 ["sa"] = 0,
				 ["ss"] = 0,
				 ["a4"] = -1,
				 ["a3"] = -1,
				 ["n1"] = 0,
			 },
		 },
	 },
	 ["userName"] = "test023",
 }
 
 -- 日赛
	local tbFightInfo = {};
	local nMax = math.random(6);
	print("随机玩家个数 ... nMax: ", nMax);
	for i = 1, nMax do
		local tbData = {};
		tbData.enemy = tbPlayerInfo;
		tbData.result = 2;
		tbData.ticketDay = 100;
		table.insert(tbFightInfo, tbData);
	end
	
	-- 日锦标赛
	local tbDailyFightInfo = {};
	local nMax = math.random(10);
	print("随机筹码赛场数 ... nMax: ", nMax);
	for i = 1, nMax do
		local tbData = {};
		tbData.player1 = tbPlayerInfo;
		tbData.player2 = tbPlayerInfo;
		tbData.seed = 2;
		tbData.winner = math.random(2);
		table.insert(tbDailyFightInfo, tbData);
	end
	return tbFightInfo, tbDailyFightInfo;
end