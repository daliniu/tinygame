--[[
使用lpack实现的数据缓冲
]]

require("script/lib/basefunctions")
require("script/ui/tipsview/tipsviewlogic")
local protocol = require("script/core/network/proto")

require("lpack.core")
local cjson = require("cjson.core")
local zlib = require("zlib.core")

local Exbuffer = {}

--[[
package bit struct
2 bytes LEN(Big endian) + 2 bytes msgid(Big endian) + body
]]
Exbuffer.PACKAGE_LEN = 2
Exbuffer.MSGID_LEN = 2
Exbuffer.STATUS_LEN = 2
Exbuffer.PACKET_MAX_LEN = 65535

function readUShort(buf, pos)
	local status, _, value = pcall(string.unpack, table.concat(buf, "", pos + 1, pos + 2), '>H')
	if status then
		return value, pos + 2
	end
	return nil
end

function readInt(buf, pos)
	local status, _, value = pcall(string.unpack, table.concat(buf, "", pos + 1, pos + 4), '>i')
	if status then
		return value, pos + 4
	end
	return nil
end

function readString(buf, pos)
	local status, _, len = pcall(string.unpack, table.concat(buf, "", pos + 1, pos + 2), '>H')
	if status then
		local ret, _, value = pcall(string.unpack, table.concat(buf, "", pos + 3, pos + 2 + len), 'A'..len)
		if ret then
			return value, pos + len + 2
		end
	end
	return nil
end


function Exbuffer:packMsg(msgid, data)
	if not(msgid) or not(protocol[msgid]) then
		print("packMsg：msgid错误")
		return nil
	end
	local types = protocol[msgid]["types"]
	local keys = protocol[msgid]["keys"]
	local fmt = { '>H' }
	local buffer = {}
	for pos, typemark in ipairs(types) do
		if not (data[keys[pos]]) then
			print("packMsg: no this type data")
			return nil
		end
		if typemark == 's' then
			fmt[#fmt + 1] = 'HA'
			buffer[#buffer + 1] = string.len(data[keys[pos]])
		elseif typemark == 'i' then
			fmt[#fmt + 1] = '>i'
		end
		buffer[#buffer + 1] = data[keys[pos]]
	end
	local status, content = pcall(string.pack, table.concat(fmt, ""), msgid, unpack(buffer))
	if status then
		return content
	end
	return nil
end

function Exbuffer:parseMsg(tbBytes)
	local buf = {}
	-- copy bytes to buffer
	for i = 1, #tbBytes do
		buf[#buf + 1] = string.char(tbBytes[i])
	end

	local msgid = readUShort(buf, 0)
	if not(msgid) then
		print("解析msgid错误")
		return nil
	end
	local status = readUShort(buf, self.MSGID_LEN)
	if status ~= 0 then
		print("status = ", status)
		-- 弹出提示框
		TipsViewLogic:getInstance():addMessageTips(status)
		return nil
	end
	local msg = {}
	msg.id = msgid
	msg.data = self:unpackMsg(buf, msgid)
	return msg
end

function Exbuffer:unpackMsg(buf, msgid)
	local data = {}
	if not(msgid) or not(protocol[msgid]) then
		print("unpackMsg：msgid错误", msgid)
	else
		local types = protocol[msgid]["types"]
		local keys = protocol[msgid]["keys"]
		local offset = self.MSGID_LEN + self.STATUS_LEN
		for pos, typemark in ipairs(types) do
			if typemark == 's' then
				data[keys[pos]], offset = readString(buf, offset)
				if not(data[keys[pos]]) then
					print('unpackMsg：解析错误', keys[pos])
					return {}
				end
			elseif typemark == 'i' then
				data[keys[pos]], offset = readInt(buf, offset)
				if not(data[keys[pos]]) then
					print('unpackMsg：解析错误', keys[pos])
					return {}
				end
			end
		end
	end
	return data
end

function Exbuffer:pack(data)
	return cjson.encode(data)
end

function Exbuffer:unpack(tbBytes)
	local buf = {}
	for i = 1, #tbBytes do
		buf[#buf + 1] = string.char(tbBytes[i])
	end
	local buffer = table.concat(buf)
	local data = cjson.decode(buffer)
	if type(data) == "table" then
		return data
	end
	return nil
end

return Exbuffer

