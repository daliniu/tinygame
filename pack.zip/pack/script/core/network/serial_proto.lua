local _p = {
["TestAddItem"] = {
    [1] = {
        ["value"] = "itemid",
        ["type"] = "string",
    },
},
["UnlockBagReq"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
},
["PvpDayRankList"] = {
    [1] = {
        ["value"] = "dayRankList",
        ["type"] = "vector",
        ["type2"] = "PvpRankInfo",
    },
},
["GetBoxRewardReq"] = {
    [1] = {
        ["value"] = "boxCount",
        ["type"] = "string",
    },
},
["EnrollPvpDayRsp"] = {
    [1] = {
        ["value"] = "pvpDay",
        ["type"] = "struct",
        ["type1"] = "PvpDay",
    },
},
["TestAddValue"] = {
    [1] = {
        ["value"] = "type",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "value",
        ["type"] = "string",
    },
},
["WashHeroRsp"] = {
    [1] = {
        ["value"] = "heroInfo",
        ["type"] = "struct",
        ["type1"] = "HeroInfo",
    },
},
["UpgradeLevelRsp"] = {
    [1] = {
        ["value"] = "playerInfo",
        ["type"] = "struct",
        ["type1"] = "PlayerInfo",
    },
    [2] = {
        ["value"] = "heroInfo",
        ["type"] = "struct",
        ["type1"] = "HeroInfo",
    },
},
["ShopHeroRsp"] = {
    [1] = {
        ["value"] = "bagItem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
},
["EquipResult"] = {
    [1] = {
        ["value"] = "index",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "star",
        ["type"] = "string",
    },
},
["UpgradeHeroQualityReq"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
},
["SendMsgReq"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "type",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "msg",
        ["type"] = "string",
    },
},
["UpgradeEquipRsp"] = {
    [1] = {
        ["value"] = "equip",
        ["type"] = "struct",
        ["type1"] = "EquipResult",
    },
},
["RollHeroReq"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
},
["RvMeltingReq"] = {
    [1] = {
        ["value"] = "equipId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "diamond",
        ["type"] = "string",
    },
},
["RvMeltingRsp"] = {
    [1] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "EquipListValue",
    },
},
["MakeEquipReq"] = {
    [1] = {
        ["value"] = "scrollList",
        ["type"] = "vector",
        ["type2"] = "string",
    },
},
["UseItemRsp"] = {
    [1] = {
        ["value"] = "baseInfo",
        ["type"] = "struct",
        ["type1"] = "BaseInfo",
    },
    [2] = {
        ["value"] = "bagItem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
    [3] = {
        ["value"] = "heroInfoList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "HeroInfo",
    },
},
["ItemListValue"] = {
    [1] = {
        ["value"] = "num",
        ["type"] = "string",
    },
},
["BaseInfo"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "userName",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "level",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "curExp",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "action",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [8] = {
        ["value"] = "vip",
        ["type"] = "string",
    },
    [9] = {
        ["value"] = "diamond",
        ["type"] = "string",
    },
    [10] = {
        ["value"] = "posList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "PosListValue",
    },
    [11] = {
        ["value"] = "teamList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "HeroInfo",
    },
},
["FightReward"] = {
    [1] = {
        ["value"] = "diamand",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "ticketDay",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "ticketWeek",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "bagItem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
},
["MakeHeroLineupRsp"] = {
    [1] = {
        ["value"] = "isOk",
        ["type"] = "string",
    },
},
["UpgradeSlotRsp"] = {
    [1] = {
        ["value"] = "heroInfo",
        ["type"] = "struct",
        ["type1"] = "HeroInfo",
    },
},
["OnlineProfitRsp"] = {
    [1] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "exp",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "action",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "bagitem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
    [5] = {
        ["value"] = "playerInfo",
        ["type"] = "struct",
        ["type1"] = "BaseInfo",
    },
},
["RecvMsgRsp"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "type",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "msg",
        ["type"] = "string",
    },
},
["HeartBeatInfo"] = {
    [1] = {
        ["value"] = "time",
        ["type"] = "string",
    },
},
["AvgLoadNumsRsp"] = {
    [1] = {
        ["value"] = "host",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "port",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "loadNums",
        ["type"] = "string",
    },
},
["LoginGameRsp"] = {
    [1] = {
        ["value"] = "loginState",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "playerInfo",
        ["type"] = "struct",
        ["type1"] = "PlayerInfo",
    },
},
["GetPvpMainListRsp"] = {
    [1] = {
        ["value"] = "pvpInfo",
        ["type"] = "struct",
        ["type1"] = "PvpInfo",
    },
    [2] = {
        ["value"] = "pvpDay",
        ["type"] = "struct",
        ["type1"] = "PvpDay",
    },
    [3] = {
        ["value"] = "pvpWeek",
        ["type"] = "struct",
        ["type1"] = "PvpWeek",
    },
},
["RefreshHeroShopReq"] = {
    [1] = {
        ["value"] = "isRefresh",
        ["type"] = "string",
    },
},
["FightInfo"] = {
    [1] = {
        ["value"] = "player1",
        ["type"] = "struct",
        ["type1"] = "PlayerInfo",
    },
    [2] = {
        ["value"] = "player2",
        ["type"] = "struct",
        ["type1"] = "PlayerInfo",
    },
    [3] = {
        ["value"] = "seed",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "winner",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "fightReward",
        ["type"] = "struct",
        ["type1"] = "FightReward",
    },
},
["interface"] = {
    ["38325136"] = {
        ["getAvgConnServerLoadNums"] = {
            ["funcName"] = "getAvgConnServerLoadNums",
            ["outArgs"] = "AvgLoadNumsRsp",
            ["seq"] = "3836510533824645451836495336491146323513524450",
            ["inArgs"] = "AvgLoadNumsReq",
        },
        ["serverName"] = "gate",
        ["seq"] = "38325136",
        ["3836510533824645451836495336491146323513524450"] = {
            ["funcName"] = "getAvgConnServerLoadNums",
            ["outArgs"] = "AvgLoadNumsRsp",
            ["seq"] = "3836510533824645451836495336491146323513524450",
            ["inArgs"] = "AvgLoadNumsReq",
        },
    },
    ["34393251"] = {
        ["sendMsgToServer"] = {
            ["funcName"] = "sendMsgToServer",
            ["outArgs"] = "SendMsgRsp",
            ["seq"] = "503645351250381946183649533649",
            ["inArgs"] = "SendMsgReq",
        },
        ["serverName"] = "chat",
        ["seq"] = "34393251",
        ["503645351250381946183649533649"] = {
            ["funcName"] = "sendMsgToServer",
            ["outArgs"] = "SendMsgRsp",
            ["seq"] = "503645351250381946183649533649",
            ["inArgs"] = "SendMsgReq",
        },
    },
    ["chat"] = {
        ["sendMsgToServer"] = {
            ["funcName"] = "sendMsgToServer",
            ["outArgs"] = "SendMsgRsp",
            ["seq"] = "503645351250381946183649533649",
            ["inArgs"] = "SendMsgReq",
        },
        ["serverName"] = "chat",
        ["seq"] = "34393251",
        ["503645351250381946183649533649"] = {
            ["funcName"] = "sendMsgToServer",
            ["outArgs"] = "SendMsgRsp",
            ["seq"] = "503645351250381946183649533649",
            ["inArgs"] = "SendMsgReq",
        },
    },
    ["34464545"] = {
        ["43463840456324436"] = {
            ["funcName"] = "loginGame",
            ["outArgs"] = "LoginGameRsp",
            ["seq"] = "43463840456324436",
            ["inArgs"] = "LoginGameReq",
        },
        ["39363249511363251"] = {
            ["funcName"] = "heartBeat",
            ["outArgs"] = "HeartBeatInfo",
            ["seq"] = "39363249511363251",
            ["inArgs"] = "HeartBeatInfo",
        },
        ["365540516324436"] = {
            ["funcName"] = "exitGame",
            ["outArgs"] = "ExitGameRsp",
            ["seq"] = "365540516324436",
        },
        ["heartBeat"] = {
            ["funcName"] = "heartBeat",
            ["outArgs"] = "HeartBeatInfo",
            ["seq"] = "39363249511363251",
            ["inArgs"] = "HeartBeatInfo",
        },
        ["exitGame"] = {
            ["funcName"] = "exitGame",
            ["outArgs"] = "ExitGameRsp",
            ["seq"] = "365540516324436",
        },
        ["loginGame"] = {
            ["funcName"] = "loginGame",
            ["outArgs"] = "LoginGameRsp",
            ["seq"] = "43463840456324436",
            ["inArgs"] = "LoginGameReq",
        },
        ["seq"] = "34464545",
        ["serverName"] = "conn",
    },
    ["434634"] = {
        ["5047434051448524047"] = {
            ["funcName"] = "splitEquip",
            ["outArgs"] = "SplitEquipRsp",
            ["seq"] = "5047434051448524047",
            ["inArgs"] = "SplitEquipReq",
        },
        ["getPvpMainList"] = {
            ["funcName"] = "getPvpMainList",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "3836511553471232404511405051",
        },
        ["rvmeltingEquip"] = {
            ["funcName"] = "rvmeltingEquip",
            ["outArgs"] = "RvMeltingRsp",
            ["seq"] = "495344364351404538448524047",
            ["inArgs"] = "RvMeltingReq",
        },
        ["38365115534722363642173650524351"] = {
            ["funcName"] = "getPvpWeekResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534722363642173650524351",
        },
        ["52454346344213238"] = {
            ["funcName"] = "unlockBag",
            ["outArgs"] = "UnlockBagRsp",
            ["seq"] = "52454346344213238",
            ["inArgs"] = "UnlockBagReq",
        },
        ["getHeroInfoList"] = {
            ["funcName"] = "getHeroInfoList",
            ["outArgs"] = "HeroListRsp",
            ["seq"] = "3836517364946845374611405051",
        },
        ["setMaxPower"] = {
            ["funcName"] = "setMaxPower",
            ["outArgs"] = "MaxPowerRsp",
            ["seq"] = "5036511232551546543649",
            ["inArgs"] = "MaxPowerReq",
        },
        ["shopHero"] = {
            ["funcName"] = "shopHero",
            ["outArgs"] = "ShopHeroRsp",
            ["seq"] = "503946477364946",
            ["inArgs"] = "ShopHeroReq",
        },
        ["upgradeHeroLevel"] = {
            ["funcName"] = "upgradeHeroLevel",
            ["outArgs"] = "UpgradeLevelRsp",
            ["seq"] = "5247384932353673649461136533643",
            ["inArgs"] = "UpgradeLevelReq",
        },
        ["getPvpDayResult"] = {
            ["funcName"] = "getPvpDayResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534733256173650524351",
        },
        ["splitEquip"] = {
            ["funcName"] = "splitEquip",
            ["outArgs"] = "SplitEquipRsp",
            ["seq"] = "5047434051448524047",
            ["inArgs"] = "SplitEquipReq",
        },
        ["getMapBaseInfo"] = {
            ["funcName"] = "getMapBaseInfo",
            ["outArgs"] = "MapBaseInfo",
            ["seq"] = "38365112324713250368453746",
        },
        ["383651155347223636421732454211405051"] = {
            ["funcName"] = "getPvpWeekRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347223636421732454211405051",
        },
        ["unlockBag"] = {
            ["funcName"] = "unlockBag",
            ["outArgs"] = "UnlockBagRsp",
            ["seq"] = "52454346344213238",
            ["inArgs"] = "UnlockBagReq",
        },
        ["upgradeHeroQuality"] = {
            ["funcName"] = "upgradeHeroQuality",
            ["outArgs"] = "UpgradeHeroQualityRsp",
            ["seq"] = "52473849323536736494616523243405156",
            ["inArgs"] = "UpgradeHeroQualityReq",
        },
        ["upgradeEquipStar"] = {
            ["funcName"] = "upgradeEquipStar",
            ["outArgs"] = "UpgradeEquipRsp",
            ["seq"] = "5247384932353644852404718513249",
            ["inArgs"] = "UpgradeEquipReq",
        },
        ["changeEquip"] = {
            ["funcName"] = "changeEquip",
            ["outArgs"] = "ChangeEquipRsp",
            ["seq"] = "343932453836448524047",
            ["inArgs"] = "ChangeEquipReq",
        },
        ["52473849323536184240434318434651"] = {
            ["funcName"] = "upgradeSkillSlot",
            ["outArgs"] = "UpgradeSlotRsp",
            ["seq"] = "52473849323536184240434318434651",
            ["inArgs"] = "UpgradeSlotReq",
        },
        ["getPresent"] = {
            ["funcName"] = "getPresent",
            ["outArgs"] = "GetPresentRsp",
            ["seq"] = "38365115493650364551",
        },
        ["443242367364946114045365247"] = {
            ["funcName"] = "makeHeroLineup",
            ["outArgs"] = "MakeHeroLineupRsp",
            ["seq"] = "443242367364946114045365247",
            ["inArgs"] = "MakeHeroLineupReq",
        },
        ["3836511553471232404511405051"] = {
            ["funcName"] = "getPvpMainList",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "3836511553471232404511405051",
        },
        ["38365115534733256173650524351"] = {
            ["funcName"] = "getPvpDayResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534733256173650524351",
        },
        ["3836511232404305151323439"] = {
            ["funcName"] = "getMailAttach",
            ["outArgs"] = "MailAttachRsp",
            ["seq"] = "3836511232404305151323439",
            ["inArgs"] = "MailAttachReq",
        },
        ["rollHero"] = {
            ["funcName"] = "rollHero",
            ["outArgs"] = "RollHeroRsp",
            ["seq"] = "494643437364946",
            ["inArgs"] = "RollHeroReq",
        },
        ["494643437364946"] = {
            ["funcName"] = "rollHero",
            ["outArgs"] = "RollHeroRsp",
            ["seq"] = "494643437364946",
            ["inArgs"] = "RollHeroReq",
        },
        ["5247384932353644852404718513249"] = {
            ["funcName"] = "upgradeEquipStar",
            ["outArgs"] = "UpgradeEquipRsp",
            ["seq"] = "5247384932353644852404718513249",
            ["inArgs"] = "UpgradeEquipReq",
        },
        ["5247384932353673649461136533643"] = {
            ["funcName"] = "upgradeHeroLevel",
            ["outArgs"] = "UpgradeLevelRsp",
            ["seq"] = "5247384932353673649461136533643",
            ["inArgs"] = "UpgradeLevelReq",
        },
        ["44364351404538448524047"] = {
            ["funcName"] = "meltingEquip",
            ["outArgs"] = "MeltingEquipRsp",
            ["seq"] = "44364351404538448524047",
            ["inArgs"] = "MeltingEquipReq",
        },
        ["3836517364946845374611405051"] = {
            ["funcName"] = "getHeroInfoList",
            ["outArgs"] = "HeroListRsp",
            ["seq"] = "3836517364946845374611405051",
        },
        ["getPvpDayF8Result"] = {
            ["funcName"] = "getPvpDayF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347332565-9173650524351",
        },
        ["543250397364946"] = {
            ["funcName"] = "washHero",
            ["outArgs"] = "WashHeroRsp",
            ["seq"] = "543250397364946",
            ["inArgs"] = "WashHeroReq",
        },
        ["getSngBoxReward"] = {
            ["funcName"] = "getSngBoxReward",
            ["outArgs"] = "GetBoxRewardRsp",
            ["seq"] = "38365118453814655173654324935",
            ["inArgs"] = "GetBoxRewardReq",
        },
        ["getPvpWeekF8Result"] = {
            ["funcName"] = "getPvpWeekF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347223636425-9173650524351",
        },
        ["383651155347332565-9173650524351"] = {
            ["funcName"] = "getPvpDayF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347332565-9173650524351",
        },
        ["3836511232404319365551"] = {
            ["funcName"] = "getMailText",
            ["outArgs"] = "MailTextBody",
            ["seq"] = "3836511232404319365551",
            ["inArgs"] = "MailTextReq",
        },
        ["383651155347332561732454211405051"] = {
            ["funcName"] = "getPvpDayRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347332561732454211405051",
        },
        ["1736343640533612324043"] = {
            ["funcName"] = "ReceiveMail",
            ["outArgs"] = "MailListRsp",
            ["seq"] = "1736343640533612324043",
        },
        ["getSngReward"] = {
            ["funcName"] = "getSngReward",
            ["outArgs"] = "GetSngRewardRsp",
            ["seq"] = "383651184538173654324935",
            ["inArgs"] = "GetSngRewardReq",
        },
        ["49363749365039736494618394647"] = {
            ["funcName"] = "refreshHeroShop",
            ["outArgs"] = "RefreshHeroShopRsp",
            ["seq"] = "49363749365039736494618394647",
            ["inArgs"] = "RefreshHeroShopReq",
        },
        ["upgradeHeroStar"] = {
            ["funcName"] = "upgradeHeroStar",
            ["outArgs"] = "UpgradeHeroStarRsp",
            ["seq"] = "52473849323536736494618513249",
            ["inArgs"] = "UpgradeHeroStarReq",
        },
        ["upgradeSkillSlot"] = {
            ["funcName"] = "upgradeSkillSlot",
            ["outArgs"] = "UpgradeSlotRsp",
            ["seq"] = "52473849323536184240434318434651",
            ["inArgs"] = "UpgradeSlotReq",
        },
        ["getMailText"] = {
            ["funcName"] = "getMailText",
            ["outArgs"] = "MailTextBody",
            ["seq"] = "3836511232404319365551",
            ["inArgs"] = "MailTextReq",
        },
        ["refreshHeroShop"] = {
            ["funcName"] = "refreshHeroShop",
            ["outArgs"] = "RefreshHeroShopRsp",
            ["seq"] = "49363749365039736494618394647",
            ["inArgs"] = "RefreshHeroShopReq",
        },
        ["getRewardTime"] = {
            ["funcName"] = "getRewardTime",
            ["outArgs"] = "GetRewardTimeRsp",
            ["seq"] = "38365117365432493519404436",
        },
        ["ReceiveMail"] = {
            ["funcName"] = "ReceiveMail",
            ["outArgs"] = "MailListRsp",
            ["seq"] = "1736343640533612324043",
        },
        ["38365117365432493519404436"] = {
            ["funcName"] = "getRewardTime",
            ["outArgs"] = "GetRewardTimeRsp",
            ["seq"] = "38365117365432493519404436",
        },
        ["383651155347223636425-9173650524351"] = {
            ["funcName"] = "getPvpWeekF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347223636425-9173650524351",
        },
        ["38365115493650364551"] = {
            ["funcName"] = "getPresent",
            ["outArgs"] = "GetPresentRsp",
            ["seq"] = "38365115493650364551",
        },
        ["seq"] = "434634",
        ["46373743404536154946374051"] = {
            ["funcName"] = "offlineProfit",
            ["outArgs"] = "OfflineProfitRsp",
            ["seq"] = "46373743404536154946374051",
        },
        ["364549464343155347184538"] = {
            ["funcName"] = "enrollPvpSng",
            ["outArgs"] = "EnrollPvpSngRsp",
            ["seq"] = "364549464343155347184538",
        },
        ["offlineProfit"] = {
            ["funcName"] = "offlineProfit",
            ["outArgs"] = "OfflineProfitRsp",
            ["seq"] = "46373743404536154946374051",
        },
        ["464543404536154946374051"] = {
            ["funcName"] = "onlineProfit",
            ["outArgs"] = "OnlineProfitRsp",
            ["seq"] = "464543404536154946374051",
            ["inArgs"] = "OnlineProfitReq",
        },
        ["getPvpDayRankList"] = {
            ["funcName"] = "getPvpDayRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347332561732454211405051",
        },
        ["5036511232551546543649"] = {
            ["funcName"] = "setMaxPower",
            ["outArgs"] = "MaxPowerRsp",
            ["seq"] = "5036511232551546543649",
            ["inArgs"] = "MaxPowerReq",
        },
        ["getPvpWeekRankList"] = {
            ["funcName"] = "getPvpWeekRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347223636421732454211405051",
        },
        ["washHero"] = {
            ["funcName"] = "washHero",
            ["outArgs"] = "WashHeroRsp",
            ["seq"] = "543250397364946",
            ["inArgs"] = "WashHeroReq",
        },
        ["38365118453814655173654324935"] = {
            ["funcName"] = "getSngBoxReward",
            ["outArgs"] = "GetBoxRewardRsp",
            ["seq"] = "38365118453814655173654324935",
            ["inArgs"] = "GetBoxRewardReq",
        },
        ["getPvpWeekResult"] = {
            ["funcName"] = "getPvpWeekResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534722363642173650524351",
        },
        ["52473849323536736494618513249"] = {
            ["funcName"] = "upgradeHeroStar",
            ["outArgs"] = "UpgradeHeroStarRsp",
            ["seq"] = "52473849323536736494618513249",
            ["inArgs"] = "UpgradeHeroStarReq",
        },
        ["enrollPvpWeek"] = {
            ["funcName"] = "enrollPvpWeek",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "36454946434315534722363642",
        },
        ["onlineProfit"] = {
            ["funcName"] = "onlineProfit",
            ["outArgs"] = "OnlineProfitRsp",
            ["seq"] = "464543404536154946374051",
            ["inArgs"] = "OnlineProfitReq",
        },
        ["503946477364946"] = {
            ["funcName"] = "shopHero",
            ["outArgs"] = "ShopHeroRsp",
            ["seq"] = "503946477364946",
            ["inArgs"] = "ShopHeroReq",
        },
        ["495344364351404538448524047"] = {
            ["funcName"] = "rvmeltingEquip",
            ["outArgs"] = "RvMeltingRsp",
            ["seq"] = "495344364351404538448524047",
            ["inArgs"] = "RvMeltingReq",
        },
        ["makeHeroLineup"] = {
            ["funcName"] = "makeHeroLineup",
            ["outArgs"] = "MakeHeroLineupRsp",
            ["seq"] = "443242367364946114045365247",
            ["inArgs"] = "MakeHeroLineupReq",
        },
        ["383651184538173654324935"] = {
            ["funcName"] = "getSngReward",
            ["outArgs"] = "GetSngRewardRsp",
            ["seq"] = "383651184538173654324935",
            ["inArgs"] = "GetSngRewardReq",
        },
        ["36454946434315534722363642"] = {
            ["funcName"] = "enrollPvpWeek",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "36454946434315534722363642",
        },
        ["343932453836448524047"] = {
            ["funcName"] = "changeEquip",
            ["outArgs"] = "ChangeEquipRsp",
            ["seq"] = "343932453836448524047",
            ["inArgs"] = "ChangeEquipReq",
        },
        ["5250368513644"] = {
            ["funcName"] = "useItem",
            ["outArgs"] = "UseItemRsp",
            ["seq"] = "5250368513644",
            ["inArgs"] = "UseItemReq",
        },
        ["enrollPvpDay"] = {
            ["funcName"] = "enrollPvpDay",
            ["outArgs"] = "EnrollPvpDayRsp",
            ["seq"] = "36454946434315534733256",
        },
        ["36454946434315534733256"] = {
            ["funcName"] = "enrollPvpDay",
            ["outArgs"] = "EnrollPvpDayRsp",
            ["seq"] = "36454946434315534733256",
        },
        ["52473849323536736494616523243405156"] = {
            ["funcName"] = "upgradeHeroQuality",
            ["outArgs"] = "UpgradeHeroQualityRsp",
            ["seq"] = "52473849323536736494616523243405156",
            ["inArgs"] = "UpgradeHeroQualityReq",
        },
        ["exitPvpSng"] = {
            ["funcName"] = "exitPvpSng",
            ["outArgs"] = "ExitPvpSngRsp",
            ["seq"] = "36554051155347184538",
        },
        ["36554051155347184538"] = {
            ["funcName"] = "exitPvpSng",
            ["outArgs"] = "ExitPvpSngRsp",
            ["seq"] = "36554051155347184538",
        },
        ["makeEquip"] = {
            ["funcName"] = "makeEquip",
            ["outArgs"] = "MakeEquipRsp",
            ["seq"] = "44324236448524047",
            ["inArgs"] = "MakeEquipReq",
        },
        ["useItem"] = {
            ["funcName"] = "useItem",
            ["outArgs"] = "UseItemRsp",
            ["seq"] = "5250368513644",
            ["inArgs"] = "UseItemReq",
        },
        ["enrollPvpSng"] = {
            ["funcName"] = "enrollPvpSng",
            ["outArgs"] = "EnrollPvpSngRsp",
            ["seq"] = "364549464343155347184538",
        },
        ["38365112324713250368453746"] = {
            ["funcName"] = "getMapBaseInfo",
            ["outArgs"] = "MapBaseInfo",
            ["seq"] = "38365112324713250368453746",
        },
        ["meltingEquip"] = {
            ["funcName"] = "meltingEquip",
            ["outArgs"] = "MeltingEquipRsp",
            ["seq"] = "44364351404538448524047",
            ["inArgs"] = "MeltingEquipReq",
        },
        ["serverName"] = "loc",
        ["getMailAttach"] = {
            ["funcName"] = "getMailAttach",
            ["outArgs"] = "MailAttachRsp",
            ["seq"] = "3836511232404305151323439",
            ["inArgs"] = "MailAttachReq",
        },
        ["44324236448524047"] = {
            ["funcName"] = "makeEquip",
            ["outArgs"] = "MakeEquipRsp",
            ["seq"] = "44324236448524047",
            ["inArgs"] = "MakeEquipReq",
        },
    },
    ["gate"] = {
        ["getAvgConnServerLoadNums"] = {
            ["funcName"] = "getAvgConnServerLoadNums",
            ["outArgs"] = "AvgLoadNumsRsp",
            ["seq"] = "3836510533824645451836495336491146323513524450",
            ["inArgs"] = "AvgLoadNumsReq",
        },
        ["serverName"] = "gate",
        ["seq"] = "38325136",
        ["3836510533824645451836495336491146323513524450"] = {
            ["funcName"] = "getAvgConnServerLoadNums",
            ["outArgs"] = "AvgLoadNumsRsp",
            ["seq"] = "3836510533824645451836495336491146323513524450",
            ["inArgs"] = "AvgLoadNumsReq",
        },
    },
    ["loc"] = {
        ["5047434051448524047"] = {
            ["funcName"] = "splitEquip",
            ["outArgs"] = "SplitEquipRsp",
            ["seq"] = "5047434051448524047",
            ["inArgs"] = "SplitEquipReq",
        },
        ["getPvpMainList"] = {
            ["funcName"] = "getPvpMainList",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "3836511553471232404511405051",
        },
        ["rvmeltingEquip"] = {
            ["funcName"] = "rvmeltingEquip",
            ["outArgs"] = "RvMeltingRsp",
            ["seq"] = "495344364351404538448524047",
            ["inArgs"] = "RvMeltingReq",
        },
        ["38365115534722363642173650524351"] = {
            ["funcName"] = "getPvpWeekResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534722363642173650524351",
        },
        ["52454346344213238"] = {
            ["funcName"] = "unlockBag",
            ["outArgs"] = "UnlockBagRsp",
            ["seq"] = "52454346344213238",
            ["inArgs"] = "UnlockBagReq",
        },
        ["getHeroInfoList"] = {
            ["funcName"] = "getHeroInfoList",
            ["outArgs"] = "HeroListRsp",
            ["seq"] = "3836517364946845374611405051",
        },
        ["setMaxPower"] = {
            ["funcName"] = "setMaxPower",
            ["outArgs"] = "MaxPowerRsp",
            ["seq"] = "5036511232551546543649",
            ["inArgs"] = "MaxPowerReq",
        },
        ["shopHero"] = {
            ["funcName"] = "shopHero",
            ["outArgs"] = "ShopHeroRsp",
            ["seq"] = "503946477364946",
            ["inArgs"] = "ShopHeroReq",
        },
        ["upgradeHeroLevel"] = {
            ["funcName"] = "upgradeHeroLevel",
            ["outArgs"] = "UpgradeLevelRsp",
            ["seq"] = "5247384932353673649461136533643",
            ["inArgs"] = "UpgradeLevelReq",
        },
        ["getPvpDayResult"] = {
            ["funcName"] = "getPvpDayResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534733256173650524351",
        },
        ["splitEquip"] = {
            ["funcName"] = "splitEquip",
            ["outArgs"] = "SplitEquipRsp",
            ["seq"] = "5047434051448524047",
            ["inArgs"] = "SplitEquipReq",
        },
        ["getMapBaseInfo"] = {
            ["funcName"] = "getMapBaseInfo",
            ["outArgs"] = "MapBaseInfo",
            ["seq"] = "38365112324713250368453746",
        },
        ["383651155347223636421732454211405051"] = {
            ["funcName"] = "getPvpWeekRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347223636421732454211405051",
        },
        ["unlockBag"] = {
            ["funcName"] = "unlockBag",
            ["outArgs"] = "UnlockBagRsp",
            ["seq"] = "52454346344213238",
            ["inArgs"] = "UnlockBagReq",
        },
        ["upgradeHeroQuality"] = {
            ["funcName"] = "upgradeHeroQuality",
            ["outArgs"] = "UpgradeHeroQualityRsp",
            ["seq"] = "52473849323536736494616523243405156",
            ["inArgs"] = "UpgradeHeroQualityReq",
        },
        ["upgradeEquipStar"] = {
            ["funcName"] = "upgradeEquipStar",
            ["outArgs"] = "UpgradeEquipRsp",
            ["seq"] = "5247384932353644852404718513249",
            ["inArgs"] = "UpgradeEquipReq",
        },
        ["changeEquip"] = {
            ["funcName"] = "changeEquip",
            ["outArgs"] = "ChangeEquipRsp",
            ["seq"] = "343932453836448524047",
            ["inArgs"] = "ChangeEquipReq",
        },
        ["52473849323536184240434318434651"] = {
            ["funcName"] = "upgradeSkillSlot",
            ["outArgs"] = "UpgradeSlotRsp",
            ["seq"] = "52473849323536184240434318434651",
            ["inArgs"] = "UpgradeSlotReq",
        },
        ["getPresent"] = {
            ["funcName"] = "getPresent",
            ["outArgs"] = "GetPresentRsp",
            ["seq"] = "38365115493650364551",
        },
        ["443242367364946114045365247"] = {
            ["funcName"] = "makeHeroLineup",
            ["outArgs"] = "MakeHeroLineupRsp",
            ["seq"] = "443242367364946114045365247",
            ["inArgs"] = "MakeHeroLineupReq",
        },
        ["3836511553471232404511405051"] = {
            ["funcName"] = "getPvpMainList",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "3836511553471232404511405051",
        },
        ["38365115534733256173650524351"] = {
            ["funcName"] = "getPvpDayResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534733256173650524351",
        },
        ["3836511232404305151323439"] = {
            ["funcName"] = "getMailAttach",
            ["outArgs"] = "MailAttachRsp",
            ["seq"] = "3836511232404305151323439",
            ["inArgs"] = "MailAttachReq",
        },
        ["rollHero"] = {
            ["funcName"] = "rollHero",
            ["outArgs"] = "RollHeroRsp",
            ["seq"] = "494643437364946",
            ["inArgs"] = "RollHeroReq",
        },
        ["494643437364946"] = {
            ["funcName"] = "rollHero",
            ["outArgs"] = "RollHeroRsp",
            ["seq"] = "494643437364946",
            ["inArgs"] = "RollHeroReq",
        },
        ["5247384932353644852404718513249"] = {
            ["funcName"] = "upgradeEquipStar",
            ["outArgs"] = "UpgradeEquipRsp",
            ["seq"] = "5247384932353644852404718513249",
            ["inArgs"] = "UpgradeEquipReq",
        },
        ["5247384932353673649461136533643"] = {
            ["funcName"] = "upgradeHeroLevel",
            ["outArgs"] = "UpgradeLevelRsp",
            ["seq"] = "5247384932353673649461136533643",
            ["inArgs"] = "UpgradeLevelReq",
        },
        ["44364351404538448524047"] = {
            ["funcName"] = "meltingEquip",
            ["outArgs"] = "MeltingEquipRsp",
            ["seq"] = "44364351404538448524047",
            ["inArgs"] = "MeltingEquipReq",
        },
        ["3836517364946845374611405051"] = {
            ["funcName"] = "getHeroInfoList",
            ["outArgs"] = "HeroListRsp",
            ["seq"] = "3836517364946845374611405051",
        },
        ["getPvpDayF8Result"] = {
            ["funcName"] = "getPvpDayF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347332565-9173650524351",
        },
        ["543250397364946"] = {
            ["funcName"] = "washHero",
            ["outArgs"] = "WashHeroRsp",
            ["seq"] = "543250397364946",
            ["inArgs"] = "WashHeroReq",
        },
        ["getSngBoxReward"] = {
            ["funcName"] = "getSngBoxReward",
            ["outArgs"] = "GetBoxRewardRsp",
            ["seq"] = "38365118453814655173654324935",
            ["inArgs"] = "GetBoxRewardReq",
        },
        ["getPvpWeekF8Result"] = {
            ["funcName"] = "getPvpWeekF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347223636425-9173650524351",
        },
        ["383651155347332565-9173650524351"] = {
            ["funcName"] = "getPvpDayF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347332565-9173650524351",
        },
        ["3836511232404319365551"] = {
            ["funcName"] = "getMailText",
            ["outArgs"] = "MailTextBody",
            ["seq"] = "3836511232404319365551",
            ["inArgs"] = "MailTextReq",
        },
        ["383651155347332561732454211405051"] = {
            ["funcName"] = "getPvpDayRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347332561732454211405051",
        },
        ["1736343640533612324043"] = {
            ["funcName"] = "ReceiveMail",
            ["outArgs"] = "MailListRsp",
            ["seq"] = "1736343640533612324043",
        },
        ["getSngReward"] = {
            ["funcName"] = "getSngReward",
            ["outArgs"] = "GetSngRewardRsp",
            ["seq"] = "383651184538173654324935",
            ["inArgs"] = "GetSngRewardReq",
        },
        ["49363749365039736494618394647"] = {
            ["funcName"] = "refreshHeroShop",
            ["outArgs"] = "RefreshHeroShopRsp",
            ["seq"] = "49363749365039736494618394647",
            ["inArgs"] = "RefreshHeroShopReq",
        },
        ["upgradeHeroStar"] = {
            ["funcName"] = "upgradeHeroStar",
            ["outArgs"] = "UpgradeHeroStarRsp",
            ["seq"] = "52473849323536736494618513249",
            ["inArgs"] = "UpgradeHeroStarReq",
        },
        ["upgradeSkillSlot"] = {
            ["funcName"] = "upgradeSkillSlot",
            ["outArgs"] = "UpgradeSlotRsp",
            ["seq"] = "52473849323536184240434318434651",
            ["inArgs"] = "UpgradeSlotReq",
        },
        ["getMailText"] = {
            ["funcName"] = "getMailText",
            ["outArgs"] = "MailTextBody",
            ["seq"] = "3836511232404319365551",
            ["inArgs"] = "MailTextReq",
        },
        ["refreshHeroShop"] = {
            ["funcName"] = "refreshHeroShop",
            ["outArgs"] = "RefreshHeroShopRsp",
            ["seq"] = "49363749365039736494618394647",
            ["inArgs"] = "RefreshHeroShopReq",
        },
        ["getRewardTime"] = {
            ["funcName"] = "getRewardTime",
            ["outArgs"] = "GetRewardTimeRsp",
            ["seq"] = "38365117365432493519404436",
        },
        ["ReceiveMail"] = {
            ["funcName"] = "ReceiveMail",
            ["outArgs"] = "MailListRsp",
            ["seq"] = "1736343640533612324043",
        },
        ["38365117365432493519404436"] = {
            ["funcName"] = "getRewardTime",
            ["outArgs"] = "GetRewardTimeRsp",
            ["seq"] = "38365117365432493519404436",
        },
        ["383651155347223636425-9173650524351"] = {
            ["funcName"] = "getPvpWeekF8Result",
            ["outArgs"] = "PvpF8ResultRsp",
            ["seq"] = "383651155347223636425-9173650524351",
        },
        ["38365115493650364551"] = {
            ["funcName"] = "getPresent",
            ["outArgs"] = "GetPresentRsp",
            ["seq"] = "38365115493650364551",
        },
        ["seq"] = "434634",
        ["46373743404536154946374051"] = {
            ["funcName"] = "offlineProfit",
            ["outArgs"] = "OfflineProfitRsp",
            ["seq"] = "46373743404536154946374051",
        },
        ["364549464343155347184538"] = {
            ["funcName"] = "enrollPvpSng",
            ["outArgs"] = "EnrollPvpSngRsp",
            ["seq"] = "364549464343155347184538",
        },
        ["offlineProfit"] = {
            ["funcName"] = "offlineProfit",
            ["outArgs"] = "OfflineProfitRsp",
            ["seq"] = "46373743404536154946374051",
        },
        ["464543404536154946374051"] = {
            ["funcName"] = "onlineProfit",
            ["outArgs"] = "OnlineProfitRsp",
            ["seq"] = "464543404536154946374051",
            ["inArgs"] = "OnlineProfitReq",
        },
        ["getPvpDayRankList"] = {
            ["funcName"] = "getPvpDayRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347332561732454211405051",
        },
        ["5036511232551546543649"] = {
            ["funcName"] = "setMaxPower",
            ["outArgs"] = "MaxPowerRsp",
            ["seq"] = "5036511232551546543649",
            ["inArgs"] = "MaxPowerReq",
        },
        ["getPvpWeekRankList"] = {
            ["funcName"] = "getPvpWeekRankList",
            ["outArgs"] = "PvpRankListRsp",
            ["seq"] = "383651155347223636421732454211405051",
        },
        ["washHero"] = {
            ["funcName"] = "washHero",
            ["outArgs"] = "WashHeroRsp",
            ["seq"] = "543250397364946",
            ["inArgs"] = "WashHeroReq",
        },
        ["38365118453814655173654324935"] = {
            ["funcName"] = "getSngBoxReward",
            ["outArgs"] = "GetBoxRewardRsp",
            ["seq"] = "38365118453814655173654324935",
            ["inArgs"] = "GetBoxRewardReq",
        },
        ["getPvpWeekResult"] = {
            ["funcName"] = "getPvpWeekResult",
            ["outArgs"] = "PvpResultRsp",
            ["seq"] = "38365115534722363642173650524351",
        },
        ["52473849323536736494618513249"] = {
            ["funcName"] = "upgradeHeroStar",
            ["outArgs"] = "UpgradeHeroStarRsp",
            ["seq"] = "52473849323536736494618513249",
            ["inArgs"] = "UpgradeHeroStarReq",
        },
        ["enrollPvpWeek"] = {
            ["funcName"] = "enrollPvpWeek",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "36454946434315534722363642",
        },
        ["onlineProfit"] = {
            ["funcName"] = "onlineProfit",
            ["outArgs"] = "OnlineProfitRsp",
            ["seq"] = "464543404536154946374051",
            ["inArgs"] = "OnlineProfitReq",
        },
        ["503946477364946"] = {
            ["funcName"] = "shopHero",
            ["outArgs"] = "ShopHeroRsp",
            ["seq"] = "503946477364946",
            ["inArgs"] = "ShopHeroReq",
        },
        ["495344364351404538448524047"] = {
            ["funcName"] = "rvmeltingEquip",
            ["outArgs"] = "RvMeltingRsp",
            ["seq"] = "495344364351404538448524047",
            ["inArgs"] = "RvMeltingReq",
        },
        ["makeHeroLineup"] = {
            ["funcName"] = "makeHeroLineup",
            ["outArgs"] = "MakeHeroLineupRsp",
            ["seq"] = "443242367364946114045365247",
            ["inArgs"] = "MakeHeroLineupReq",
        },
        ["383651184538173654324935"] = {
            ["funcName"] = "getSngReward",
            ["outArgs"] = "GetSngRewardRsp",
            ["seq"] = "383651184538173654324935",
            ["inArgs"] = "GetSngRewardReq",
        },
        ["36454946434315534722363642"] = {
            ["funcName"] = "enrollPvpWeek",
            ["outArgs"] = "GetPvpMainListRsp",
            ["seq"] = "36454946434315534722363642",
        },
        ["343932453836448524047"] = {
            ["funcName"] = "changeEquip",
            ["outArgs"] = "ChangeEquipRsp",
            ["seq"] = "343932453836448524047",
            ["inArgs"] = "ChangeEquipReq",
        },
        ["5250368513644"] = {
            ["funcName"] = "useItem",
            ["outArgs"] = "UseItemRsp",
            ["seq"] = "5250368513644",
            ["inArgs"] = "UseItemReq",
        },
        ["enrollPvpDay"] = {
            ["funcName"] = "enrollPvpDay",
            ["outArgs"] = "EnrollPvpDayRsp",
            ["seq"] = "36454946434315534733256",
        },
        ["36454946434315534733256"] = {
            ["funcName"] = "enrollPvpDay",
            ["outArgs"] = "EnrollPvpDayRsp",
            ["seq"] = "36454946434315534733256",
        },
        ["52473849323536736494616523243405156"] = {
            ["funcName"] = "upgradeHeroQuality",
            ["outArgs"] = "UpgradeHeroQualityRsp",
            ["seq"] = "52473849323536736494616523243405156",
            ["inArgs"] = "UpgradeHeroQualityReq",
        },
        ["exitPvpSng"] = {
            ["funcName"] = "exitPvpSng",
            ["outArgs"] = "ExitPvpSngRsp",
            ["seq"] = "36554051155347184538",
        },
        ["36554051155347184538"] = {
            ["funcName"] = "exitPvpSng",
            ["outArgs"] = "ExitPvpSngRsp",
            ["seq"] = "36554051155347184538",
        },
        ["makeEquip"] = {
            ["funcName"] = "makeEquip",
            ["outArgs"] = "MakeEquipRsp",
            ["seq"] = "44324236448524047",
            ["inArgs"] = "MakeEquipReq",
        },
        ["useItem"] = {
            ["funcName"] = "useItem",
            ["outArgs"] = "UseItemRsp",
            ["seq"] = "5250368513644",
            ["inArgs"] = "UseItemReq",
        },
        ["enrollPvpSng"] = {
            ["funcName"] = "enrollPvpSng",
            ["outArgs"] = "EnrollPvpSngRsp",
            ["seq"] = "364549464343155347184538",
        },
        ["38365112324713250368453746"] = {
            ["funcName"] = "getMapBaseInfo",
            ["outArgs"] = "MapBaseInfo",
            ["seq"] = "38365112324713250368453746",
        },
        ["meltingEquip"] = {
            ["funcName"] = "meltingEquip",
            ["outArgs"] = "MeltingEquipRsp",
            ["seq"] = "44364351404538448524047",
            ["inArgs"] = "MeltingEquipReq",
        },
        ["serverName"] = "loc",
        ["getMailAttach"] = {
            ["funcName"] = "getMailAttach",
            ["outArgs"] = "MailAttachRsp",
            ["seq"] = "3836511232404305151323439",
            ["inArgs"] = "MailAttachReq",
        },
        ["44324236448524047"] = {
            ["funcName"] = "makeEquip",
            ["outArgs"] = "MakeEquipRsp",
            ["seq"] = "44324236448524047",
            ["inArgs"] = "MakeEquipReq",
        },
    },
    ["client"] = {
        ["383651444324043"] = {
            ["funcName"] = "getEmail",
            ["outArgs"] = "RecvMailInfoRsp",
            ["seq"] = "383651444324043",
        },
        ["493634531250385494644183649533649"] = {
            ["funcName"] = "recvMsgFromServer",
            ["outArgs"] = "RecvMsgRsp",
            ["seq"] = "493634531250385494644183649533649",
        },
        ["kickClientOffline"] = {
            ["funcName"] = "kickClientOffline",
            ["outArgs"] = "KickClientRsp",
            ["seq"] = "424034422434036455114373743404536",
        },
        ["serverName"] = "client",
        ["getEmail"] = {
            ["funcName"] = "getEmail",
            ["outArgs"] = "RecvMailInfoRsp",
            ["seq"] = "383651444324043",
        },
        ["recvMsgFromServer"] = {
            ["funcName"] = "recvMsgFromServer",
            ["outArgs"] = "RecvMsgRsp",
            ["seq"] = "493634531250385494644183649533649",
        },
        ["seq"] = "344340364551",
        ["424034422434036455114373743404536"] = {
            ["funcName"] = "kickClientOffline",
            ["outArgs"] = "KickClientRsp",
            ["seq"] = "424034422434036455114373743404536",
        },
    },
    ["conn"] = {
        ["43463840456324436"] = {
            ["funcName"] = "loginGame",
            ["outArgs"] = "LoginGameRsp",
            ["seq"] = "43463840456324436",
            ["inArgs"] = "LoginGameReq",
        },
        ["39363249511363251"] = {
            ["funcName"] = "heartBeat",
            ["outArgs"] = "HeartBeatInfo",
            ["seq"] = "39363249511363251",
            ["inArgs"] = "HeartBeatInfo",
        },
        ["365540516324436"] = {
            ["funcName"] = "exitGame",
            ["outArgs"] = "ExitGameRsp",
            ["seq"] = "365540516324436",
        },
        ["heartBeat"] = {
            ["funcName"] = "heartBeat",
            ["outArgs"] = "HeartBeatInfo",
            ["seq"] = "39363249511363251",
            ["inArgs"] = "HeartBeatInfo",
        },
        ["exitGame"] = {
            ["funcName"] = "exitGame",
            ["outArgs"] = "ExitGameRsp",
            ["seq"] = "365540516324436",
        },
        ["loginGame"] = {
            ["funcName"] = "loginGame",
            ["outArgs"] = "LoginGameRsp",
            ["seq"] = "43463840456324436",
            ["inArgs"] = "LoginGameReq",
        },
        ["seq"] = "34464545",
        ["serverName"] = "conn",
    },
    ["344340364551"] = {
        ["383651444324043"] = {
            ["funcName"] = "getEmail",
            ["outArgs"] = "RecvMailInfoRsp",
            ["seq"] = "383651444324043",
        },
        ["493634531250385494644183649533649"] = {
            ["funcName"] = "recvMsgFromServer",
            ["outArgs"] = "RecvMsgRsp",
            ["seq"] = "493634531250385494644183649533649",
        },
        ["kickClientOffline"] = {
            ["funcName"] = "kickClientOffline",
            ["outArgs"] = "KickClientRsp",
            ["seq"] = "424034422434036455114373743404536",
        },
        ["serverName"] = "client",
        ["getEmail"] = {
            ["funcName"] = "getEmail",
            ["outArgs"] = "RecvMailInfoRsp",
            ["seq"] = "383651444324043",
        },
        ["recvMsgFromServer"] = {
            ["funcName"] = "recvMsgFromServer",
            ["outArgs"] = "RecvMsgRsp",
            ["seq"] = "493634531250385494644183649533649",
        },
        ["seq"] = "344340364551",
        ["424034422434036455114373743404536"] = {
            ["funcName"] = "kickClientOffline",
            ["outArgs"] = "KickClientRsp",
            ["seq"] = "424034422434036455114373743404536",
        },
    },
},
["map<string, EquipListValue>"] = {
    [1] = {
        ["type2"] = "EquipListValue",
        ["type"] = "map",
        ["type1"] = "map2",
    },
},
["PvpDay"] = {
    [1] = {
        ["value"] = "uuids",
        ["type"] = "vector",
        ["type2"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "rewardPool",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "nums",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "updateTime",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "pvpF8Result",
        ["type"] = "struct",
        ["type1"] = "PvpF8Result",
    },
    [7] = {
        ["value"] = "finalSort",
        ["type"] = "vector",
        ["type2"] = "UserArea",
    },
},
["BuffInfo"] = {
    [1] = {
        ["value"] = "id",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "value",
        ["type"] = "string",
    },
},
["GetSngRewardRsp"] = {
    [1] = {
        ["value"] = "fightReward",
        ["type"] = "struct",
        ["type1"] = "FightReward",
    },
},
["UpgradeHeroStarReq"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
},
["BagList"] = {
    [1] = {
        ["value"] = "max",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "itemList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "ItemListValue",
    },
    [3] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "EquipListValue",
    },
},
["ExitGameRsp"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
},
["MailAttachReq"] = {
    [1] = {
        ["value"] = "mailID",
        ["type"] = "string",
    },
},
["UpgradeLevelReq"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "expPlayer",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "exp",
        ["type"] = "string",
    },
},
["MailTextBody"] = {
    [1] = {
        ["value"] = "text",
        ["type"] = "string",
    },
},
["OnlineProfitReq"] = {
    [1] = {
        ["value"] = "isWin",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "pointId",
        ["type"] = "string",
    },
},
["LoginGameReq"] = {
    [1] = {
        ["value"] = "authInfo",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "code",
        ["type"] = "string",
    },
},
["RecvMailInfoRsp"] = {
    [1] = {
        ["value"] = "sender",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "title",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "attach",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "string",
    },
    [4] = {
        ["value"] = "id",
        ["type"] = "string",
    },
},
["OfflineProfitRsp"] = {
    [1] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "exp",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "action",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "offTime",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "bagitem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
    [6] = {
        ["value"] = "playerInfo",
        ["type"] = "struct",
        ["type1"] = "BaseInfo",
    },
},
["EquipListValue"] = {
    [1] = {
        ["value"] = "id",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "star",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "num",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "a1",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "n1",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "a2",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "n2",
        ["type"] = "string",
    },
    [8] = {
        ["value"] = "a3",
        ["type"] = "string",
    },
    [9] = {
        ["value"] = "n3",
        ["type"] = "string",
    },
    [10] = {
        ["value"] = "a4",
        ["type"] = "string",
    },
    [11] = {
        ["value"] = "n4",
        ["type"] = "string",
    },
    [12] = {
        ["value"] = "sa",
        ["type"] = "string",
    },
    [13] = {
        ["value"] = "sn",
        ["type"] = "string",
    },
    [14] = {
        ["value"] = "ss",
        ["type"] = "string",
    },
},
["mailHead"] = {
    [1] = {
        ["value"] = "sender",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "title",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "attach",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "string",
    },
    [4] = {
        ["value"] = "id",
        ["type"] = "string",
    },
},
["GetPresentRsp"] = {
    [1] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "exp",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "action",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "bagitem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
    [5] = {
        ["value"] = "playerInfo",
        ["type"] = "struct",
        ["type1"] = "BaseInfo",
    },
    [6] = {
        ["value"] = "rewardCount",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "step",
        ["type"] = "string",
    },
},
["MaxPowerRsp"] = {
    [1] = {
        ["value"] = "maxPower",
        ["type"] = "string",
    },
},
["PvpSng"] = {
    [1] = {
        ["value"] = "id",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "keys",
        ["type"] = "vector",
        ["type2"] = "UserArea",
    },
},
["PvpRankListRsp"] = {
    [1] = {
        ["value"] = "rankList",
        ["type"] = "vector",
        ["type2"] = "PvpRankInfo",
    },
    [2] = {
        ["value"] = "myRank",
        ["type"] = "struct",
        ["type1"] = "PvpRankInfo",
    },
},
["UseItemReq"] = {
    [1] = {
        ["value"] = "item",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
},
["AfkBaseInfo"] = {
    [1] = {
        ["value"] = "mapid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "uid",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "guajiid",
        ["type"] = "string",
    },
},
["ChangeEquipReq"] = {
    [1] = {
        ["value"] = "sign",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "seq",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "id1",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "id2",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "id3",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "id4",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "id5",
        ["type"] = "string",
    },
    [8] = {
        ["value"] = "id6",
        ["type"] = "string",
    },
},
["PvpF8ResultRsp"] = {
    [1] = {
        ["value"] = "pos",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "pvpF8Result",
        ["type"] = "struct",
        ["type1"] = "PvpF8Result",
    },
    [3] = {
        ["value"] = "fightReward",
        ["type"] = "struct",
        ["type1"] = "FightReward",
    },
},
["PvpResultRsp"] = {
    [1] = {
        ["value"] = "fightInfoList",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
},
["ExitPvpSngRsp"] = {
    [1] = {
        ["value"] = "startMark",
        ["type"] = "string",
    },
},
["PvpWeekRankList"] = {
    [1] = {
        ["value"] = "weekRankList",
        ["type"] = "vector",
        ["type2"] = "PvpRankInfo",
    },
},
["SFightInfo"] = {
    [1] = {
        ["value"] = "enemy",
        ["type"] = "struct",
        ["type1"] = "PlayerInfo",
    },
    [2] = {
        ["value"] = "result",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "ticketDay",
        ["type"] = "string",
    },
},
["MaxPowerReq"] = {
    [1] = {
        ["value"] = "maxPower",
        ["type"] = "string",
    },
},
["GetSngRewardReq"] = {
    [1] = {
        ["value"] = "enemyType",
        ["type"] = "string",
    },
},
["PvpRankInfo"] = {
    [1] = {
        ["value"] = "pos",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
},
["GlobalInfo"] = {
    [1] = {
        ["value"] = "pvpDay",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "PvpDay",
    },
    [2] = {
        ["value"] = "pvpWeek",
        ["type"] = "struct",
        ["type1"] = "PvpWeek",
    },
},
["HeroListRsp"] = {
    [1] = {
        ["value"] = "heroInfoList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "HeroInfo",
    },
    [2] = {
        ["value"] = "heroBookInfo",
        ["type"] = "struct",
        ["type1"] = "HeroBookInfo",
    },
},
["PosListValue"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "pos",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "equipIdList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "string",
    },
},
["MapBaseInfo"] = {
    [1] = {
        ["value"] = "curMapId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "supply",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "buffList",
        ["type"] = "vector",
        ["type2"] = "BuffInfo",
    },
    [4] = {
        ["value"] = "curAfker",
        ["type"] = "struct",
        ["type1"] = "AfkBaseInfo",
    },
},
["MeltingEquipRsp"] = {
    [1] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "EquipListValue",
    },
    [3] = {
        ["value"] = "splitList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "ItemListValue",
    },
},
["MeltingEquipReq"] = {
    [1] = {
        ["value"] = "lequipId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "requipId",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "attr",
        ["type"] = "string",
    },
},
["HeroInfo"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "curExp",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "level",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "star",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "quality",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "pos",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "skillSlotList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "SkillSlotValue",
    },
    [8] = {
        ["value"] = "suitId1",
        ["type"] = "string",
    },
    [9] = {
        ["value"] = "suitId2",
        ["type"] = "string",
    },
    [10] = {
        ["value"] = "suitId3",
        ["type"] = "string",
    },
    [11] = {
        ["value"] = "suitId4",
        ["type"] = "string",
    },
    [12] = {
        ["value"] = "suitId5",
        ["type"] = "string",
    },
},
["EnrollPvpSngRsp"] = {
    [1] = {
        ["value"] = "pvpInfo",
        ["type"] = "struct",
        ["type1"] = "PvpInfo",
    },
},
["KickClientRsp"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
},
["BagItem"] = {
    [1] = {
        ["value"] = "itemList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "ItemListValue",
    },
    [2] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "EquipListValue",
    },
},
["MakeEquipRsp"] = {
    [1] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "EquipListValue",
    },
},
["SendMsgRsp"] = {
    [1] = {
        ["value"] = "state",
        ["type"] = "string",
    },
},
["UpgradeSlotReq"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "slotId",
        ["type"] = "string",
    },
},
["UpgradeHeroStarRsp"] = {
    [1] = {
        ["value"] = "heroInfo",
        ["type"] = "struct",
        ["type1"] = "HeroInfo",
    },
},
["SplitEquipRsp"] = {
    [1] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "splitList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "ItemListValue",
    },
},
["ChangeEquipRsp"] = {
    [1] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "map<string, EquipListValue>",
    },
},
["UserArea"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
},
["GetBoxRewardRsp"] = {
    [1] = {
        ["value"] = "ticketN",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "bagItem",
        ["type"] = "struct",
        ["type1"] = "BagItem",
    },
},
["UpgradeEquipReq"] = {
    [1] = {
        ["value"] = "equipId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "id1",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "id2",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "id3",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "id4",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "id5",
        ["type"] = "string",
    },
},
["MailListRsp"] = {
    [1] = {
        ["value"] = "mailList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "mailHead",
    },
},
["MailAttachRsp"] = {
    [1] = {
        ["value"] = "isOK",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "attach",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "string",
    },
},
["MailTextReq"] = {
    [1] = {
        ["value"] = "mailID",
        ["type"] = "string",
    },
},
["GetRewardTimeRsp"] = {
    [1] = {
        ["value"] = "rewardCount",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "step",
        ["type"] = "string",
    },
},
["TestAddItemOut"] = {
    [1] = {
        ["value"] = "item",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "string",
    },
},
["PlayerInfo"] = {
    [1] = {
        ["value"] = "uuid",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "area",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "userName",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "level",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "curExp",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "action",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "gold",
        ["type"] = "string",
    },
    [8] = {
        ["value"] = "vip",
        ["type"] = "string",
    },
    [9] = {
        ["value"] = "diamond",
        ["type"] = "string",
    },
    [10] = {
        ["value"] = "teamList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "HeroInfo",
    },
    [11] = {
        ["value"] = "equipList",
        ["type"] = "map",
        ["type1"] = "string",
        ["type2"] = "map<string, EquipListValue>",
    },
    [12] = {
        ["value"] = "bagList",
        ["type"] = "struct",
        ["type1"] = "BagList",
    },
},
["SplitEquipReq"] = {
    [1] = {
        ["value"] = "equipIdList",
        ["type"] = "vector",
        ["type2"] = "string",
    },
},
["WashHeroReq"] = {
    [1] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "lock1",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "lock2",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "lock3",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "lock4",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "lock5",
        ["type"] = "string",
    },
},
["UnlockBagRsp"] = {
    [1] = {
        ["value"] = "max",
        ["type"] = "string",
    },
},
["SkillSlotValue"] = {
    [1] = {
        ["value"] = "level",
        ["type"] = "string",
    },
},
["PvpWeek"] = {
    [1] = {
        ["value"] = "userArea",
        ["type"] = "vector",
        ["type2"] = "UserArea",
    },
    [2] = {
        ["value"] = "rewardPool",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "nums",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "pvpF8Result",
        ["type"] = "struct",
        ["type1"] = "PvpF8Result",
    },
    [5] = {
        ["value"] = "finalSort",
        ["type"] = "vector",
        ["type2"] = "UserArea",
    },
},
["PvpF8Result"] = {
    [1] = {
        ["value"] = "fightList8",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
    [2] = {
        ["value"] = "fightList4",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
    [3] = {
        ["value"] = "fightList2",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
    [4] = {
        ["value"] = "fightList1",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
},
["RollHeroRsp"] = {
    [1] = {
        ["value"] = "heroInfo",
        ["type"] = "struct",
        ["type1"] = "HeroInfo",
    },
    [2] = {
        ["value"] = "heroBookInfo",
        ["type"] = "struct",
        ["type1"] = "HeroBookInfo",
    },
},
["AvgLoadNumsReq"] = {
    [1] = {
        ["value"] = "chnlId",
        ["type"] = "string",
    },
},
["MakeHeroLineupReq"] = {
    [1] = {
        ["value"] = "posDst",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "heroId",
        ["type"] = "string",
    },
},
["ShopHeroReq"] = {
    [1] = {
        ["value"] = "shopId",
        ["type"] = "string",
    },
},
["UpgradeHeroQualityRsp"] = {
    [1] = {
        ["value"] = "heroInfo",
        ["type"] = "struct",
        ["type1"] = "HeroInfo",
    },
},
["RefreshHeroShopRsp"] = {
    [1] = {
        ["value"] = "shop1",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "shop2",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "shop3",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "shop4",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "shop5",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "refreshNums",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "time",
        ["type"] = "string",
    },
},
["PvpInfo"] = {
    [1] = {
        ["value"] = "ticketN",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "ticketDay",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "ticketWeek",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "fightCount",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "startMark",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "box1",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "box2",
        ["type"] = "string",
    },
    [8] = {
        ["value"] = "box3",
        ["type"] = "string",
    },
    [9] = {
        ["value"] = "myTime",
        ["type"] = "string",
    },
    [10] = {
        ["value"] = "dayMark",
        ["type"] = "string",
    },
    [11] = {
        ["value"] = "weekMark",
        ["type"] = "string",
    },
    [12] = {
        ["value"] = "fightInfoListSng",
        ["type"] = "vector",
        ["type2"] = "SFightInfo",
    },
    [13] = {
        ["value"] = "fightInfoListDay",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
    [14] = {
        ["value"] = "fightInfoListWeek",
        ["type"] = "vector",
        ["type2"] = "FightInfo",
    },
},
["HeroBookInfo"] = {
    [1] = {
        ["value"] = "heroId1",
        ["type"] = "string",
    },
    [2] = {
        ["value"] = "heroId2",
        ["type"] = "string",
    },
    [3] = {
        ["value"] = "heroId3",
        ["type"] = "string",
    },
    [4] = {
        ["value"] = "summomNums",
        ["type"] = "string",
    },
    [5] = {
        ["value"] = "shop1",
        ["type"] = "string",
    },
    [6] = {
        ["value"] = "shop2",
        ["type"] = "string",
    },
    [7] = {
        ["value"] = "shop3",
        ["type"] = "string",
    },
    [8] = {
        ["value"] = "shop4",
        ["type"] = "string",
    },
    [9] = {
        ["value"] = "shop5",
        ["type"] = "string",
    },
    [10] = {
        ["value"] = "refreshNums",
        ["type"] = "string",
    },
    [11] = {
        ["value"] = "time",
        ["type"] = "string",
    },
},
}
 return _p
