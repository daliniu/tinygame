
local EMAIL_INFO_TB={
	
}

KGC_EMAIL_INFO_CLASS = class("KGC_EMAIL_INFO_CLASS",nil,EMAIL_INFO_TB);


function KGC_EMAIL_INFO_CLASS:create()
	self = KGC_EMAIL_INFO_CLASS.new();
	return self;
end


function KGC_EMAIL_INFO_CLASS:initDate(tbDatas)


end