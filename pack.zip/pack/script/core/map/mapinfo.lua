
--[[
	afkObj:{mapid,uid,guajiid}
	buffList:[{},{}]
	ap:200
]]--

--地图有一份特殊的背包数据
--[[


]]--


local TB_STRUCT_MAP_INFO={

	-- curMapID,		--当前地图id
	afkObj,				--当前挂机点
	-- lastAfkTime,		--上一次挂机时间
	-- afkList,			--挂机点列表
	buffList,			--buffer
	ap,					--团队体力
}

KGC_MAP_INFO_CLASS = class("KGC_MAP_INFO_CLASS",nil,TB_STRUCT_MAP_INFO);



function KGC_MAP_INFO_CLASS:create()
	self = KGC_MAP_INFO_CLASS.new();
	return self;
end


function KGC_MAP_INFO_CLASS:InitDate()

    local funCall = function(tbArg)
    	local curMapId 		= tbArg.curMapId;
    	local supply 		= tbArg.supply;
    	local bufferList 	= tbArg.buffList;
    	local curAfker 		= tbArg.curAfker;

    	self.ap=100;												--团队体力
    	if tbArg.curMapId~=nil then
    		if tbArg.curMapId == 0 then 
    			MapViewLogic:getInstance().currentMapID =1;
    		else
    			MapViewLogic:getInstance().currentMapID = tbArg.curMapId;	--所在地图id
    		end
    	end
 		self.afkObj			= curAfker;								--当前挂机点数据
 		self.buffList		= bufferList;							--buffer
    end

    g_Core.communicator.loc.getMapBaseInfo(funCall);	

end



-- --@function: 获取挂机点ID
function KGC_MAP_INFO_CLASS:GetMapID()
	return self.afkObj.mapid;
end

function KGC_MAP_INFO_CLASS:SetMapID(nID)
	self.afkObj.mapid = nID or 0;
end

--@function：获取挂机点ID
function KGC_MAP_INFO_CLASS:GetFightPointID()
	return self.afkObj.guajiid;
end

function KGC_MAP_INFO_CLASS:SetFightPointID(nID)
	self.afkObj.guajiid = nID or 0;
end

--uid
function KGC_MAP_INFO_CLASS:GetFightPointUID()
	return self.afkObj.uid;
end

function KGC_MAP_INFO_CLASS:SetFightPointUID(nID)
	self.afkObj.uid = nID or 0;
end

--获取当前挂机点所有信息
function KGC_MAP_INFO_CLASS:GetCurAfker()
	return self.afkObj;
end


-- function KGC_MAP_INFO_CLASS:GetAfkList()
-- 	return self.afkList;
-- end

function KGC_MAP_INFO_CLASS:GetBufferList()
	return self.buffList;
end

function KGC_MAP_INFO_CLASS:InitBuffDate(tbDate)
	self.buffList = tbDate;
end


function KGC_MAP_INFO_CLASS:GetTeamHp()
	return self.ap
end

function KGC_MAP_INFO_CLASS:SetTeamHp(fValue)
	self.ap = fValue;
end

-- function KGC_MAP_INFO_CLASS:GetLastAfkTime()
-- 	return self.lastAfkTime;
-- end
