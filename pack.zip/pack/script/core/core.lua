----------------------------------------------------------
-- file:	core.lua
-- Author:	page
-- Time:	2015/01/27 15:36
-- Desc:	全局的core对象
--
----------------------------------------------------------
require "script/lib/definefunctions"			
require "script/lib/actionfunctions"
require "script/lib/basefunctions"
require "script/lib/debugfunctions"
require "script/lib/stringfunctions"
require "script/lib/testfunctions"
require "script/lib/timefunctions"
require "script/core/player/playerfactory"
require "script/core/fight/fight"
TClient = require('script/core/network/tclient')
require('script/core/network/init')
require "script/core/npc/herofactory"				-- KGC_HERO_FACTORY_TYPE:getInstance()
----------------------------------------------------------
local l_tbUIUpdateType = def_GetUIUpdateTypeData();
local cjson = require("cjson.core")

--data
local TB_CORE_DATA = {
	communicator = nil,			-- 协议对象
	authInfo = "",              -- sdk 验证信息
	gateIP = "10.20.68.102",      -- IP
	gatePort = 4000,              -- 端口
	myIP = nil,                    -- IP
	myPort = nil,                   -- 端口
}

KGC_CORE_TYPE= class("KGC_CORE_TYPE", CLASS_BASE_TYPE, TB_CORE_DATA)

--function
function KGC_CORE_TYPE:ctor()

end

--初始化网络连接
function KGC_CORE_TYPE:initNetwork(host, port, callback)
	if self.client ~= nil then
		self.client:close()
	end
	self.client = nil
	--self.client = TClient.new(host, port, '')
	self.client = TClient.new(host, port, callback)
end

function KGC_CORE_TYPE:initCommunicator(callback)
	local initCallback = function()
		-- 获取IP和port
		self:initGateCommunicator(callback)
	end
	-- 连接网关
	self.communicator = initCommunicator(g_Core.gateIP, g_Core.gatePort, initCallback)
end

function KGC_CORE_TYPE:initGateCommunicator(callback)
	-- 获取connIP和port回调
	local avgCallback = function(outArgs)
		if self.client then
			self.client:close();
		end
		self.client = nil
		-- 根据服务端传回IP和端口初始化网络接口
		print("getAvgConnServerLoadNums", outArgs.host, outArgs.port, outArgs.loadNums)
		-- 保存IP和port
		g_Core.myIP = outArgs.host
		g_Core.myPort = outArgs.port
		--初始化网络连接
		self:initNetCommunicator(callback)
	end
	self.communicator.gate.getAvgConnServerLoadNums({chnlId = "mi"}, avgCallback)
end

function KGC_CORE_TYPE:initNetCommunicator(callback)
	local initCallback = function()
		if callback ~= nil then
			callback()
		end
	end
	if g_Core.myIP == nil or g_Core.myPort == nil then
		self:initCommunicator()
	else
		self.communicator = initCommunicator(g_Core.myIP, g_Core.myPort, initCallback)
	end
end

function KGC_CORE_TYPE:closeNetwork()
	if self.client then
		self.client:close();
	end
	self.client = nil
end

--发送数据
function KGC_CORE_TYPE:send(msgId, data, isLoadUi)
	if self.client then
		self.client:send(msgId, data, isLoadUi)
		--test
		local szLog = string.format("[发送数据]协议(%d), msg = {", msgId);
		local szMsg = ""
		for k, v in pairs(data) do
			local szTemp = tostring(k) .. " : " .. tostring(v) .. ", " .. tostring(type(v)) .. ";"
			szMsg = szMsg .. szTemp;
		end
		szLog = szLog .. szMsg .. "}"
		print(szLog);
		--test
		return true;
	end
	return false
end

function KGC_CORE_TYPE:sendEx(data, isLoadUi)
	if self.client then
		self.client:sendEx(data, isLoadUi)
		return true;
	end
	return false
end

function KGC_CORE_TYPE:init(tbData)
	-- test
	-- require "script/cfg/tool/configcheck"
	-- local bRet = check();
	-- assert(bRet)
	
	tst_open_log_file();
	-- test end

	print("core init ...")

	--玩家数据
	me:init(tbData);
	assert(me);
	-- 初始化挂机数据
	me:InitAfkStatistics();

	--背包
	print("[]core init end.")
	--
	
	-- 注册接受消息的回调函数
	self:RegisterMessageCallBack();
end

function KGC_CORE_TYPE:UnInit()
	-- 对象置空
	me = KGC_PLAYER_TYPE.new();
	
	-- 界面都关掉
	GameSceneManager:getInstance():UnInit();
end

--@function: Request的回调函数
function KGC_CORE_TYPE:ReceiveMessage(nID, tbData)
	local cjson = require("cjson.core")
	print("[接受数据]协议：", nID)
	local szLog = string.format("[接受数据]协议(%d)", nID);
	--登录返回
	if nID == 3007 then
		szLog = szLog .. "登录返回"
		local state = tbData.loginState
		if state == 1 then
			local data = cjson.decode(tbData.playerInfo)
			if data then
				--登录成功
				self:OnLogin(true, data)
				return;
			end
		end
		--false
		self:OnLogin(false, "登录失败！")
		return;
	elseif nID == 6009 then										--#地图初始化
		local tbMapInfo = cjson.decode(tbData.mapinfo)
		me:InitMap(tbMapInfo);
	elseif nID == 6001 then										--#进入地图应答
		MapViewLogic:getInstance():rspOpenView(tbData);
	elseif nID == 6003 then 									--#地图行走应答
		MapViewLogic:getInstance():rspMove(tbData);
	elseif nID == 6005 then 									--地图元素功能通用接口
		MapViewLogic:getInstance():rspElementFunction(tbData);
	elseif nID == 6007 then 									--请求购买功能建筑内的物品
		MapViewLogic:getInstance():rspBuyItem(tbData);
	elseif nID == 8001 then 									--请求出售物品
		KGC_BagViewLogic:getInstance():rspSell(tbData);
	elseif nID == 8003 then 									--合成物品返回
		ItemComLogic:getInstance():rspCom(tbData);
	elseif nID == 8005 then										--请求使用道具
		KGC_BagViewLogic:getInstance():rspUseItem(tbData)
	elseif nID == 7012 then 									--请求合成返回
		ForgingLogic:getInstance():rspForging(tbData);
	elseif nID == 2003 then 									--GM工具
		GMLogic:getInstance():rspGMItem(tbData);
	elseif nID == 2005 then 									--GM工具
		GMLogic:getInstance():rspGMBaseInfo(tbData);			
	elseif nID == 7016 then										--背包扩容
		KGC_BagViewLogic:getInstance():rspExtendBag(tbData)
	elseif nID == 5002 then		--获取英雄列表
		local data = cjson.decode(tbData.heroInfoList)
		KGC_MainViewLogic:getInstance():RspHeroList(data);
	elseif nID == 5006 then		--服务器返回：增加经验
		local tbPlayer = cjson.decode(tbData.playerInfo)
		local tbHero = cjson.decode(tbData.heroInfo)
		cclog("[经验]5006服务器返回, player当前经验(%s), 等级(%s)", tostring(tbPlayer.curExp), tostring(tbPlayer.level))
		me:OnAddExp(tbPlayer, tbHero);
		
		GameSceneManager:getInstance():updateLayer(l_tbUIUpdateType.EU_MONEY);
		GameSceneManager:getInstance():updateLayer(l_tbUIUpdateType.EU_BAG);
	-- elseif nID == 5008 then 
		-- HeroInfoLogic:getInstance():rspUpdateSkillSlot(tbData);
	-------------------------------------------------------
	--装备相关
	-- elseif nID == 7002 then		--服务器返回：更换装备返回
		-- local tbEquips = cjson.decode(tbData.equipList);
		-- KGC_EQUIP_LOGIC_TYPE:getInstance():OnRspChangeEquicpCallBack(tbEquips);
	elseif nID == 7004 then		--服务器返回：装备升星
		local tbEquip = cjson.decode(tbData.equip);
		local nIndex = tbEquip.id
		local nStar = tbEquip.star
		KGC_EQUIP_LOGIC_TYPE:getInstance():OnRspEquicpStar(nIndex, nStar);
	elseif nID == 7006 then		--服务器返回：装备拆分
		local tbItems = cjson.decode(tbData.splitList)
		local nGold = tbData.gold
		KGC_BagViewLogic:getInstance():OnRspSplit(tbItems, nGold)
	elseif nID == 7008 then		--服务器返回：装备淬炼
		local tbItems = cjson.decode(tbData.splitList)
		local nGold = tbData.gold
		local tbEquip = cjson.decode(tbData.equip)
		KGC_EQUIP_LOGIC_TYPE:getInstance():OnRspAttrPick(tbEquip, tbItems, nGold)
	elseif nID == 7010 then		--服务器返回：还原装备淬炼
		local equip = cjson.decode(tbData.equip)
		KGC_EQUIP_LOGIC_TYPE:getInstance():OnRspPickRecover(equip)
	-------------------------------------------------------
	-- 挂机相关
	elseif nID == 11003 then	-- 服务器返回：在线奖励
		local tbItems = cjson.decode(tbData.bagitem);
		local tbPlayer = cjson.decode(tbData.playerInfo);

		local nGoldAdd = tbData.gold
		local nExpAdd = tbData.exp
		szLog = szLog .. ", msg = {gold = " .. nGoldAdd .. ", exp = " .. nExpAdd .. ", items = }"
		
		FightViewLogic:getInstance():OnRepFightReward(nGoldAdd, nExpAdd, tbPlayer, tbItems)
	elseif nID == 11005 then	-- 服务器返回：离线奖励
		local tbItems = cjson.decode(tbData.bagitem);
		local tbPlayer = cjson.decode(tbData.playerInfo);
		
		local nTime = tbData.time;
		local nGoldAdd = tbData.gold
		local nExpAdd = tbData.exp
		szLog = szLog .. ", msg = {addgold = " .. nGoldAdd .. ", addexp = " .. nExpAdd .. ", items = }"
		KGC_AFK_STATISTICS_LOGIC_TYPE:getInstance():OnRspAfkStatistics(nGoldAdd, nExpAdd, tbPlayer, tbItems, nTime)
	-------------------------------------------------------
	end
	
	print(szLog);
end

--@function: 注册接受消息的回调函数(服务器主动发送类消息)
function KGC_CORE_TYPE:RegisterMessageCallBack()
	-- 接受聊天信息
	KGC_CHAT_VIEW_LOGIC_TYPE:getInstance():RegisterMessageCallBack();
	-- 邮件
	EmailLogic:getInstance():RegisterMessageCallBack();
	-- 登录
	LoginViewLogic:getInstance():RegisterMessageCallBack()
end

function KGC_CORE_TYPE:OnLogin(bRet, data)
	bRet = bRet or false;
	data = data or ""
	LoginViewLogic:getInstance():onLogin(bRet, data)
end

function KGC_CORE_TYPE:Notify(msg)
	-- login

	-- if g_uiLogin then
		-- g_uiLogin:onLogin(msg)
	-- end
	LoginViewLogic:getInstance():onLogin(msg)
end

function KGC_CORE_TYPE:Fight(tbMineShip, tbEnemyShip)
	--FightMgr
	fightHall = g_FightMgr:CreateFightHall()
	return fightHall:Fight(tbMineShip, tbEnemyShip)
end

-- 从core获取数据
function KGC_CORE_TYPE:getData(nID)
	--
end

function KGC_CORE_TYPE:GetModule(szModuleName)
	return self[szModuleName];
end

--relization
g_Core = KGC_CORE_TYPE.new()

