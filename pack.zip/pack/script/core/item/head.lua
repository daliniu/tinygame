----------------------------------------------------------
-- file:	item/head.lua
-- Author:	page
-- Time:	2015/06/24	11:34
-- Desc:	item interface for outer
----------------------------------------------------------
--[[
relationship:
head.lua
|--itemmanager.lua
	|--equip.lua
		|--itembase.lua	
|--equipfactory.lua
]]
require "script/core/item/itemmanager"
require "script/core/item/equipfactory"