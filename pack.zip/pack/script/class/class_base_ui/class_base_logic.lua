
--逻辑基类
local TB_STRUCT_UI_BASE_LOGIC = {
	m_pLogic = nil,
	m_pLayer = nil,
}

KGC_UI_BASE_LOGIC = class("KGC_UI_BASE_LOGIC", CLASS_BASE_TYPE, TB_STRUCT_UI_BASE_LOGIC)


function KGC_UI_BASE_LOGIC:create()
    return KGC_UI_BASE_LOGIC:new()
end

function KGC_UI_BASE_LOGIC:initLayer(parent,id)

end

function KGC_UI_BASE_LOGIC:closeLayer()

end

function KGC_UI_BASE_LOGIC:updateLayer(iType, tbArg)
	self:OnUpdateLayer(iType, tbArg)
end

function KGC_UI_BASE_LOGIC:updateTips(iType)

end

function KGC_UI_BASE_LOGIC:OnUpdateLayer(iType)

end

function KGC_UI_BASE_LOGIC:UpdateData(nID)

end

--@function: 退出初始化
function KGC_UI_BASE_LOGIC:UnInit()
	self.m_pLogic = nil;
	self.m_pLayer = nil;
end