----------------------------------------------------------
-- file:	class_data_base.lua
-- Author:	page
-- Time:	2015/02/09
-- Desc:	data ����
----------------------------------------------------------
require "script/class/class_base"

KGC_DATA_BASE_TYPE = class("KGC_DATA_BASE_TYPE", CLASS_BASE_TYPE)

