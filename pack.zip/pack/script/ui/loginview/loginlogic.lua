require("script/ui/loginview/loginview")
require("script/class/class_base_ui/class_base_logic")

LoginViewLogic=class("LoginViewLogic",function()
    return KGC_UI_BASE_LOGIC:create()
end)

LoginViewLogic.pLogic    =nil
LoginViewLogic.pLayer    =nil

LoginViewLogic.test01=1

function LoginViewLogic:getInstance()
	if LoginViewLogic.pLogic==nil then
        LoginViewLogic.pLogic=LoginViewLogic:create()
		GameSceneManager:getInstance():insertLogic(LoginViewLogic.pLogic)
	end
	return LoginViewLogic.pLogic
end

function LoginViewLogic:create()
    local _logic = LoginViewLogic:new()
    return _logic
end

function LoginViewLogic:initLayer(parent,id)
    if self.pLayer then
    	return;
    end
	self:ReadConfigFromJson("settings/server_list.json")
		
    self.pLayer=KG_UILogin.new()
	self.pLayer:init();
	
    self.pLayer.id=id
    parent:addChild(self.pLayer)
end

function LoginViewLogic:closeLayer()
	if self.pLayer then
		GameSceneManager:getInstance():removeLayer(self.pLayer.id);
		self.pLayer = nil
	end
end

function LoginViewLogic:updateLayer(iType)

end

function LoginViewLogic:onLogin(bRet, data)
	--登录成功
	if bRet then
		local function fnCallBack()
			cclog("[Log]登录成功!账户: %s", tostring(data.uuid))
			-- test
			tst_print_lua_table(data);
			-- test end
			g_Core:init(data);
			
			me:SetAccount(data.uuid)

    		UserGuideLogic:getInstance():initUserGuide(GameSceneManager:getInstance().userGuideNode)  --用户指导层			

			self:closeLayer()
			GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_MAIN,0)
			
			-- 请求离线奖励
			FightViewLogic:getInstance():ReqFightRewardOffLine();
			
			-- 获取地图信息@峰猴
			tbArg = {}
			tbArg.ok = 1;
			g_Core:send(6008, tbArg);

			--请求邮件列表
			EmailLogic:getInstance():reqEmailList();

			--地图信息
			me:InitMap();

		end
		-- 异步加载资源(11为预加载资源总数)
		-- GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_PROGRESS, {5, fnCallBack});
		self.pLayer:RegisterProgressEvent(22, fnCallBack);
		local fnLoad = function()
			local fnLoad3 = function()
				self:LoadSpine();
			end
			
			local fnLoad2 = function()
				self:LoadImages(fnLoad3);
			end
			
			local fnLoad1 = function()
				self:LoadEffect(fnLoad2);
			end
			
			fnLoad1();
		end

		fnLoad();
	else
		print("[Log]登录失败")
		local szErr = tostring(data);
		if self.pLayer then
			self.pLayer:LoginFailed(szErr)
		end
	end
end

function LoginViewLogic:ReadConfigFromJson(szFile)
	if not szFile then
		return;
	end
	local cjson = require("cjson.core")
	
	local fileUtils = cc.FileUtils:getInstance()
	local szData = fileUtils:getStringFromFile(szFile);
	
	local data = cjson.decode(szData)
	self.m_tbAreas = data;

end

function LoginViewLogic:GetAreasData()
	return self.m_tbAreas or {};
end

--@function: 预加载图片资源
function LoginViewLogic:LoadImages(fnCallBack)
	print("LoadImages ................. ")
	
	local tbImages = {
		[1] = "res/ui/05_mainUI/05_bg_mainbg_01.png",
		[2] = "res/ui/01_battleselectcha/battlescene/01_bg_waterland_01a.png",
	}
	
	local nCount = 0;
	local function imgLoaded(texture)
		print("texturename:", texture:getName())
		if self.pLayer then
			self.pLayer:UpdateProgress();
		end
		
		nCount = nCount + 1;
		if nCount >= #tbImages and fnCallBack then
			fnCallBack();
		end
	end
	
	for _, szImage in pairs(tbImages) do
		cc.Director:getInstance():getTextureCache():addImageAsync(szImage, imgLoaded)
	end
end

--@function: 预加载spine骨骼动画
function LoginViewLogic:LoadSpine()
	print("LoadSpine ... ");
	local tbSpines = {
		[1] = 1001,
		[2] = 1002,
		[3] = 1003,
		[4] = 1012,
		[5] = 1014,
		[6] = 1016,
		[7] = 2007,
	};
	local scheduler = cc.Director:getInstance():getScheduler()
	local nCount = 0;
	local schedulerSpine = nil;
	local fnLoadSpine = function()
		nCount = nCount + 1;
		local nModelID = tbSpines[nCount];
		KGC_MODEL_MANAGER_TYPE:getInstance():CreateNpc(nModelID);
		if self.pLayer then
			self.pLayer:UpdateProgress();
		end
		if nCount >= #tbSpines and schedulerSpine then
			scheduler:unscheduleScriptEntry(schedulerSpine);
		end
	end
	
	schedulerSpine = scheduler:scheduleScriptFunc(fnLoadSpine, 0.03, false);
	print("LoadSpine end. ");
end

--@function：预加载特效
function LoginViewLogic:LoadEffect(fnCallBack)
	print("LoadEffect ... start");
	local l_tbEffectConfig = require("script/cfg/client/effect")
	-- percent范围 = [0, 1]
	local fnEffectLoaded = function(percent)
		print("fnCallBack", percent);
		if self.pLayer then
			self.pLayer:UpdateProgress();
		end
		if percent >= 1 and fnCallBack then
			fnCallBack();
		end
	end
	-- # 13
	local tbEffectID = {60004, 10015, 10020, 10021, 10016, 20009, 20028,
		20011, 20014, 20012, 10013, 20016, 10003,
	};
	-- local tbEffectID = {60004, 60040, 60041, 10015, 10020, 10021, 10016, 20009, 20028,
		-- 20011, 20014, 20012, 10013, 20016, 10003,
	-- };
	for _, nEffID in pairs(tbEffectID) do
		print("LoadEffect", nEffID);
		local tbInfo = l_tbEffectConfig[nEffID];
		if tbInfo then
			local szFileName = tbInfo.effectpath;
			ccs.ArmatureDataManager:getInstance():addArmatureFileInfoAsync(szFileName, fnEffectLoaded)
		end
	end
	print("LoadEffect end.");
end

--@function: 登出
function LoginViewLogic:LoginOut()
	g_Core:UnInit();
	
	-- 回到登录界面
	GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_LOGIN)
end


--@function: 注册
function LoginViewLogic:RegisterMessageCallBack()
	-- 初始化接受消息协议
	local fnCallBack = function(tbArg)
		print("被踢下线...")
		g_Core:closeNetwork()
		NetworkLogic:getInstance():kickNetwork()
	end
	g_Core.communicator.client.kickClientOffline(fnCallBack);
end
