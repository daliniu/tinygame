--打造界面装备提示信息
require("script/class/class_base_ui/class_base_sub_layer")


local TB_STRUCT_SHIP={};

ForgingItemTips = class("ForgingItemTips",function()
	return KGC_UI_BASE_SUB_LAYER:create()
end)

function ForgingItemTips:create(id)
	self = ForgingItemTips.new();
	return self;
end

function ForgingItemTips:ctor()
	self.pWidget=ccs.GUIReader:getInstance():widgetFromJsonFile("res/forgingitemtips.json")
    self:addChild(self.pWidget)	



    local function fun_close(sender,eventType)
        if eventType==ccui.TouchEventType.ended then
            self:closeLayer();
        end
    end    

    local btn_close = self.pWidget:addTouchEventListener(fun_close)
end