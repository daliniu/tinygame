--战斗指令解析器(单例全局)

require ("script/lib/definefunctions")
require ("script/core/skill/define")
require ("script/core/fight/define")
local l_tbSkillConfig = require("script/cfg/skills")
local l_tbSummonsConfig = require("script/cfg/summons")
local l_tbCamp = def_GetFightCampData()
local TB_ENUM_SKILL_TYPE_DEF, TB_ENUM_SKILL_TYPE_NAME_DEF = def_GetSkillTypeData()

local TB_FIGHT_PARSER_STRUCT = 
{

}

FightParser = class("FightParser", CLASS_BASE_TYPE, TB_FIGHT_PARSER_STRUCT)

function FightParser:ctor()
	
end

--战斗数据解析成指令
--[[
tFightData = {
	--一轮的总操作table
	[1] = {
		--本轮操作子table
		[1] = {
			camp = 	1 or 2, --操作方阵营（1=己方，2=敌方）
			activeid = 1,	--主动方怪物or英雄id
			passiveid = {2},	--被动方怪物or英雄id
			skillid = 1,	--技能id
			bmiss = true,	--是否闪避
			bcrit = true,	--是否暴击
			value = 1,		--作用效果值（伤害值、加费数等，无则为nil）
			cost = 1,		--消耗费用			
			tcombo = {1,2,...},		--合击角色id(没有直接为nil，只须触发方携带该信息)
			tbind = {1,2,...},	--连携角色id(没有直接为nil，只须触发方携带该信息)
			tmultiple = {1,2,...},	--多重角色id(没有直接为nil，只须触发方携带该信息)
			removebuff = {1,2},		--移除buff，参数1：角色id，参数2：buff id
		},		
		...
		--回合状态清楚（用于回合制buff的清楚，无则nil）
		troundclear = {
			removebuff = {1,2},		--移除buff，参数1：角色id，参数2：buff id
		},
	}, 
	...
}
]]
function FightParser:Parse(tFightData)
	local tCommand = {}
	local tCost = {[l_tbCamp.MINE] = 0, [l_tbCamp.ENEMY] = 0}		--缓存每轮消耗
	local tTotalCost = {[l_tbCamp.MINE] = 0, [l_tbCamp.ENEMY] = 0}	--缓存每轮最大费用值
	local tHp = {}
	--战斗开始指令
	table.insert(tFightData, {processfunc = KG_UIFight.FightStart})
	--重置费用指令
	self:PackCostCommand(tCommand, 0, 0, 0, 0, 0, l_tbCamp.MINE)
	self:PackCostCommand(tCommand, 0, 0, 0, 0, 0, l_tbCamp.ENEMY)
	for i, tRoundData in ipairs(tFightData) do		
		--该轮开始指令
		table.insert(tCommand, {processfunc = KG_UIFight.RoundStart, tArg = {round = i}})		
		--buff清除指令
		if tRoundData.tStartBuff then
			self:PackBuffCommand(tCommand, tRoundData.tStartBuff)
		end
		--费用更新指令
		for _, v in ipairs(tRoundData.tCost) do
			self:PackCostCommand(tCommand, tCost[v.nCamp], 1, 0, i, v.nCost, v.nCamp)
			tTotalCost[v.nCamp] = v.nCost
		end
		--设置回复费用后清空本轮费用记录
		tCost = {[l_tbCamp.MINE] = 0, [l_tbCamp.ENEMY] = 0}
		for _, tData in ipairs(tRoundData.tOperation) do
			--费用消耗
			if tData.nCost and tData.nCost ~= 0 then
				tCost[tData.nCamp] = tCost[tData.nCamp] + tData.nCost
				self:PackCostCommand(tCommand, tCost[tData.nCamp], 0, tData.nCost, i, tTotalCost[tData.nCamp], tData.nCamp)
			end
			--获取技能信息
			local tSkillInfo = l_tbSkillConfig[tData.skillid]
			--技能释放前特效显示：选择英雄等
			table.insert(tCommand, 
				{processfunc = KG_UIFight.NormalAttackEffect, 
				 tArg = {
				 	nCamp = tData.nCamp, 
				 	nSkillId = tData.nSkillId, 
				 	nHeroId = tData.tActive.nHero, 
				 	nPos = tData.tActive.nPos
				 	}
				})
			--攻击
			--判断是否是召唤物，是否是攻击
			if tData.tActive.nPos >= 1 and tData.tActive.nPos <= 3 and tData.nSkillRet == SKILL_EFFECT.ATTACK then
				--移动
				table.insert(tCommand, 
					{processfunc = KG_UIFight.SummonAttackMove, 
					 tArg = {
					 	nHeroId = tData.tActive.nHero, 
					 	nSkillId = tData.nSkillId, 
					 	nCamp = tData.nCamp, 
					 	nPos = tData.tActive.nPos, 
					 	nDePos = tPassive[1].nPos
					 	}
					})
				--攻击
				table.insert(tCommand, 
					{processfunc = KG_UIFight.CharacterAttack, 
					 tArg = {
					 	nHeroId = tData.tActive.nHero, 
					 	nPos = tData.tActive.nPos, 
					 	nSkillId = tData.nSkillId, 
					 	nCamp = tData.nCamp, 
					 	tmultiple = tData.tMultiple, 
					 	tcombo = tData.tCombo
					 	}
					})			
			else
				--英雄or怪物攻击
				table.insert(tCommand, 
					{processfunc = KG_UIFight.CharacterAttack, 
					 tArg = {
					 	nHeroId = tData.tActive.nHero, 
					 	nPos = tData.tActive.nPos, 
					 	nSkillId = tData.nSkillId, 
					 	nCamp = tData.nCamp, 
					 	tmultiple = tData.tMultiple, 
					 	tcombo = tData.tCombo
					 	}
					})						
			end
			--攻击产生buff
			if tData.tBuff then
				for _, tBuff in ipairs(tData.tBuff) do
					tBuff.nCamp = tData.nCamp
					tBuff.nPos = tData.tActive.nPos					
				end
				self:PackBuffCommand(tData.tBuff)
			end
			--更新文字
			table.insert(tCommand, 
				{processfunc = KG_UIFight.UpdateFightRecord, 
				 tArg = {
				 	nCamp = tData.nCamp, 
				 	nHeroId = tData.tActive.nHero, 
				 	nPos = tData.tActive.nPos, 
				 	nSkillId = tData.nSkillId, 
				 	nDeHeroId = tData.tPassive[1].nHero, 
				 	nValue = tData.tPassive[1].nValue
				 	}
				 })
			--防御		
			if tData.nSkillRet == SKILL_EFFECT.ADD then
				--添加水晶
				tTotalCost[tData.nCamp] = tTotalCost[tData.nCamp] + 1
				self:PackCostCommand(tCommand, tCost[tData.nCamp], 1, 0, i, tTotalCost[tData.nCamp], tData.nCamp)
			elseif tData.nSkillRet == SKILL_EFFECT.CALL then
				local tCallPos = {}
				for _, tCall in ipairs(tData.tPassive) do
					table.insert(tCallPos, tCall.nPos)
				end
				table.insert(tCommand, 
					{processfunc = KG_UIFight.Summon, 
					 tArg = {
					 	nCamp = tData.nCamp, 
					 	tPos = tCallPos, 
					 	nHeroId = tData.tActive.nHero, 
					 	nSkillId = tData.nSkillId, 
					 	nHeroPos = tData.tActive.nPos
					 	}
					})
			elseif tData.nSkillRet == SKILL_EFFECT.COPY then
			elseif tData.nSkillRet == SKILL_EFFECT.STATUS then
			elseif tData.nSkillRet == SKILL_EFFECT.CURL then
				for _, tCurl in ipairs(tData.tPassive) do
					table.insert(tCommand, 
						{processfunc = KG_UIFight.CurlEffect, 
						 tArg = {
						 	nCamp = tData.nCamp, 
						 	nPos = tData.tActive.nPos, 
						 	nSkillId = tData.nSkillId, 
						 	nValue = tCurl.nValue, 
						 	nDePos = tCurl.nPos
						 }
						})
				end				
			else
				--普通防御
				table.insert(tCommand, 
					{processfunc = KG_UIFight.CharacterDefense, 
					 tArg = {
					 	tDeHeroList = tData.tPassive, 
					 	nSkillId = tData.nSkillId, 
					 	nCamp = tData.nCamp
					 }
					})
				
				for _, tHurt in ipairs(tData.tPassive) do
					local nDeCamp = l_tbCamp.MINE
					if tData.nCamp == l_tbCamp.MINE then
						nDeCamp = l_tbCamp.ENEMY
					end
					--更新血量
					if nValue ~= 0 then
						table.insert(tCommand, 
							{processfunc = KG_UIFight.UpdateHP, 
							 tArg = {
							 	nCamp = nDeCamp, 
							 	nPos = tHurt.nPos, 
							 	nCurHP = tHurt.nHp, 
							 	nMaxHP = tHurt.nMaxHp}})
					end
					--被击buff触发
					if tData.tPassive.tBuff then						
						for _, tBuff in ipairs(tData.tPassive.tBuff) do
							tBuff.nCamp = nDeCamp
							tBuff.nPos = tHurt.nPos			
						end
						self:PackBuffCommand(tData.tPassive.tBuff)
					end
				end				
				--判断是否是怪物，怪物则攻击完需要返回
				if tData.tActive.nPos >= 1 and tData.tActive.nPos <= 3 then
					table.insert(tCommand, 
						{processfunc = KG_UIFight.SummonAttackMoveBack, 
						 tArg = {
						 	nCamp = tData.nCamp, 
						 	nPos = tData.tActive.nPos
						 	}
						})
				end
			end												
			--播放连携特效
			if tData.tBind then
				table.insert(tCommand, 
					{processfunc = KG_UIFight.BindAttackEffect, 
					 tArg = {
					 	nCamp = tData.nCamp, 
					 	tBind = tData.tBind, 
					 	}
					})
			end

			--播放多重特效
			if tData.tMultiple then
				table.insert(tCommand, {processfunc = KG_UIFight.MultiAttackEffect, tArg = {}})
			end

			--若非连携，多重等效果则延迟1秒再执行下一步攻击
			if not tData.tBind and not tData.tMultiple then
				table.insert(tCommand, {processfunc = KG_UIFight.DelayBackToProcess, tArg = 1})
			end
		end
		--该轮结束指令
		table.insert(tCommand, {processfunc = KG_UIFight.RoundEnd, tArg = {round = i}})
		--结束buff状态结算
		if tRoundData.tEndBuff then
			self:PackBuffCommand(tCommand, tRoundData.tEndBuff)
		end
	end
	--战斗结束指令
	table.insert(tCommand, {processfunc = KG_UIFight.FightEnd})

	return tCommand
end

--打包更新费用指令
--recovery恢复费用数，add增加费用数，sub减少费用数，round回合数
function FightParser:PackCostCommand(tCommandList, recovery, add, sub, round, total, camp)
	if round > MAX_COST then
		add = 0
	end
	local tCommand = {}
	tCommand.processfunc = KG_UIFight.UpdateCost
	tCommand.tArg = {}
	tCommand.tArg.nCur = total - recovery
	tCommand.tArg.nMax = total
	tCommand.tArg.nBefore = total - recovery + sub - add
	tCommand.tArg.nChange = add
	tCommand.tArg.nCamp = camp
	table.insert(tCommandList, tCommand)
end

function FightParser:PackBuffCommand(tCommand, tBuffList)
	for i, tBuff in ipairs(tBuffList) do
		if tBuff.nRet == STATUS_TYPE.ADD then	--增加属性
			table.insert(tCommand, {processfunc = KG_UIFight.AddBuff, tArg = {nCamp = tBuff.nCamp, nPos = tBuff.nPos, nBuffId = tBuff.nBuffId}})
		elseif tBuff.nRet == STATUS_TYPE.SUSTAIN then	--持续伤害
			table.insert(tCommand, {processfunc = KG_UIFight.BuffSustain, tArg = {nCamp = tBuff.nCamp, nPos = tBuff.nPos, nBuffId = tBuff.nBuffId, nValue = tBuff.nValue}})
			table.insert(tCommand, {processfunc = KG_UIFight.UpdateHP, tArg = {nCamp = tBuff.nCamp, nPos = tBuff.nPos, nCurHP = tBuff.nHp, nMaxHP = tBuff.nMaxHp}})
		elseif tBuff.nRet == STATUS_TYPE.REDUCE then	--减少属性
			table.insert(tCommand, {processfunc = KG_UIFight.RemoveBuff, tArg = {nCamp = tBuff.nCamp, nPos = tBuff.nPos, nBuffId = tBuff.nBuffId}})
		end
	end		
end

gFightParser = FightParser.new()