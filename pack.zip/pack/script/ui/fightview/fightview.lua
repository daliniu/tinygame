----------------------------------------------------------
-- file:	uifight.lua
-- Author:	page
-- Time:	2015/01/26
-- Desc:	All ui operation about fight
----------------------------------------------------------
require "script/lib/basefunctions"
require "script/lib/debugfunctions"
require "script/lib/definefunctions"
require "script/core/core"
require "script/ui/resource"
require "script/ui/visiblerect"
require "script/core/reward/rewardmanager";
require "script/core/npc/modelmanager"
require "script/class/class_base_ui/class_base_layer"
require "script/ui/fightview/fightcagelayer"

local l_tbZOrder = require("script/cfg/client/view/localzorder")
local l_tbLocalZOrder, l_tbGlobalZOrder = l_tbZOrder.tbLocal, l_tbZOrder.tbGlobal
local l_tbNpcModels = require("script/cfg/client/model")
local l_tbString = require "script/cfg/string";
local l_tbEffectDecoration = require("script/cfg/client/decorationeffect")
local l_tbFightTextConfig = require("script/cfg/client/action/fighttext");
local l_tbBroadCast = require("script/cfg/client/broadcast");
local l_tbAfkConfig = require("script/cfg/afkreward")
local l_tbMapInfo = require("script/cfg/exploration/common/mapinfo");
local l_tbBgImageConfig = require("script/cfg/other/picgroup");
local l_tbHeroBox = require("script/cfg/client/herobox");
local l_tbFightSetting = require("script/cfg/client/ui/fightsetting")
----------------------------------------------------------
local l_tbCamp = def_GetFightCampData();
local l_tbCondID, l_tbCondName = def_GetConditionData();
local l_tbPos = def_GetPosData();
local l_tbSkillCastRet = def_GetSkillCastRetData();
local l_tbUIUpdateType = def_GetUIUpdateTypeData();
local l_tbEffect = def_GetEffectType();

--data struct
local TB_UI_FIGHT = {
	--config
	m_szHeroHP = "bar_hp",					--字段：角色血条
	m_szHeroCost = "list_cost",				--字段：费用条
	m_szCostItem = "cost",					--字段：单个费用
	m_szPnlModel = "pnl_npc_armature",		--字段：角色panel
	
	m_bUpdate = true;
	------------------------------------------------------------
	--界面
	m_Layout = false,					--保存界面结构root
	m_svText = nil,						-- 战斗播报界面
	m_pnlSearch = nil,					-- 探索界面
	m_pnlStatistics = nil,				-- 统计界面
	m_pnlEffect = nil,					-- 特效层
	
	--奖励界面									
	m_pnlRound = nil,					--回合开始的面板
	m_bmpRound = nil,					--每回合要显示的回合数
	
	m_SchedulerFight = false,			--战斗播放动画定时器
	m_nAnimationTurn = 0,				--动画播放到第几轮,从0开始
	m_tbArms = {},						--动画
	m_tbWidgetMarks = {					--标记的image控件
		tbWidgets = {},						--所有的控件(按照camp和pos区分)
		tbCounters = {},					--key为widget的计数器
	},				
	m_tbHeros = {},						--角色表
	m_FightHall = nil,					--战斗系统
	m_nRound = 0,						--当前回合
	m_tbBullts = {},					--子弹集合
	btn_double = nil,					--加速按钮
	m_bPaused = false,					--暂停按钮状态
	m_layerUp = nil,					--最上层界面(要调整位置)
	m_layerDown = nil,					--最下层界面(要调整界面)
	m_pnlState = nil,					--状态控件
	m_tbNode2Npc = {},					--保存节点对应npc
	m_widgetCostItem = nil,				--费用的item
	m_nItemDistance = 0,				--费用之间的距离(移动特效用)
	--
	m_nCurrentSpeed = 1,                    --当前播放速度
	
	m_tbPnlNpcs = {						-- NPC对应的role_ui控件
		--[[
			[camp][pos] = {},
		]]
	},
	m_bCustomFight = false,				-- 是否主动触发战斗的(用来回调回去)
	m_tbHeroPanel = {					-- role_ui对应的panel
		-- [camp][pos] = {},
	},
	
	m_nHeroBoxID = nil,					-- 英雄盒子ID
	m_bOneTime = false,					-- 战斗一次借结束

	m_canGetReward = false,				-- 是否可以获取奖励

	m_setting = nil,					-- 设置按钮

	m_BmpStep = nil,					--步数
	
	m_BmpGold = nil,					--金币数
	
	m_BmpDiamond = nil,					--砖石数
	
	m_BmpLevel = nil,					--玩家等级
	m_BarExp = nil,						--经验条
	m_BmpExp = nil,						--经验
	
	m_BmpFightPoint = nil,				--战力
	m_BmpVIP = nil,						--vip等级
	m_btnLayer = nil,					--按钮层
}

KG_UIFight = class("KG_UIFight", KGC_UI_BASE_LAYER, TB_UI_FIGHT)
----------------------------------------
--function
----------------------------------------
function KG_UIFight:ctor(tbArg)
	print("KG_UIFight ctor ... ", tbArg)
	if tbArg then
		self.m_bDebug = tbArg.bDebug
	end
	
	-- self:LoadScheme();
	self:LoadScheme();
end

--init
function KG_UIFight:Init(tbMine, tbEnemy)
	self.m_FightHall = KGC_FightHall:getInstance()

	--每一场战斗都有一个全局UI条件触发器(和逻辑上的全局条件触发器一样)
	g_UICondTrigger = KGC_SUB_CONDITION_BASE_TYPE.new()
	
	-- 清空数据
	self:ClearData();
	
	self.m_FightHall:Init(tbMine or me, tbEnemy);
	self:UpdateView({l_tbCamp.MINE})
	
	-- 开始搜索
	if not self.m_bDebug then
		local nBoxID = me:RandomMonsterBoxID();
		self:SearchAndFight(os.time(), nBoxID);
	end

	self:playBackgroundMusic();

	-- 请求当前挂机点的进度
	FightViewLogic:getInstance():ReqRewardMoreCount();
end

-- 背景音乐
function KG_UIFight:playBackgroundMusic()
	AudioManager:getInstance():setBackgroundMusicVolume(0.5)	
	AudioManager:getInstance():playBackground("res/audio/background/audio_bg_fight_01");
end

--@function: 初始化数据
-- function KG_UIFight:InitData(tbMine, tbEnemy)
	-- self.m_FightHall:Init(tbMine or me, tbEnemy);
	-- self:UpdateView({l_tbCamp.MINE})
	
	-- -- 开始搜索
	-- if not self.m_bDebug then
		-- local nBoxID = me:RandomMonsterBoxID();
		-- self:SearchAndFight(os.time(), nBoxID);
	-- end
-- end

--@function: 更新数据: 
--@tbData: 索引(1,2)-->表示要更新阵营数量; tbData-->表示要更新数据或者置空
--[[
	{
		[1] = {nCamp1, tbData},
		[2] = {nCamp2, tbData},
	}
]]
function KG_UIFight:UpdateData(tbData)
	local tbData = tbData or {};
	print("[Log]UpdateData", tbData[1], tbData[2])
	-- self.m_FightHall:Init(tbMine or me, tbEnemy)
	for _, tbCampData in pairs(tbData) do
		local nCamp, tbData = unpack(tbCampData or {});
		self.m_FightHall:AddData(nCamp, tbData);
	end
	
	return true;
end

--@function: 更新界面
function KG_UIFight:UpdateView(tbCamp)
	local tbCamp = tbCamp or {l_tbCamp.MINE, l_tbCamp.ENEMY};
	print("[Log]UpdateView start ... ", #(tbCamp or {}))
	-- 英雄角色更新
	local tbShips = self.m_FightHall:GetShips();
	for _, nCamp in pairs(tbCamp) do
		local ship = tbShips[nCamp];
		print("2222222222222222222222222222222", nCamp, ship);
		if ship then
			ship:ForEachProcessHeros(self, self.UpdateHero, nCamp)
		end
	end
	
	--初始化费用
	local tbCost = {
		[l_tbCamp.MINE] = {0, 0, 0, 0}, 
		[l_tbCamp.ENEMY] = {0, 0, 0, 0},
	}
	self:UpdateCost(tbCost)
	print("[Log]UpdateView end ... ")
end

function KG_UIFight:ClearData()
	print("[Log]清空数据 .......................................... ")
	self.m_FightHall:Clear();
	self:ClearAllHero();
	local tbData = {
		{l_tbCamp.MINE, me},
		{l_tbCamp.ENEMY, nil},
	};
	self:UpdateData(tbData);
	self:UpdateView({l_tbCamp.MINE, l_tbCamp.ENEMY});
end

function KG_UIFight:ClearEnemy()
	local tbHeros = self.m_tbHeros[l_tbCamp.ENEMY]
	for pos, hero in pairs(tbHeros) do
		local node = self:GetHeroPanelByPos(l_tbCamp.ENEMY, pos)
		if node then
			node:setVisible(false);
			self:SetArmature(l_tbCamp.ENEMY, pos, nil);
		end
		hero:UnInit();
	end
	
	-- 清空英雄数据
	self.m_tbHeros[l_tbCamp.ENEMY] = {}
	self.m_FightHall:ClearEnemy();
	self:UpdateView({l_tbCamp.MINE, l_tbCamp.ENEMY});
end

--@function: 播放奖励动画
function KG_UIFight:PlayRewardAnimation(fnCallBack)
	local sprite = cc.Sprite:create("res/ui/05_mainUI/05_ico_main_btn_02.png");
	sprite:setPosition(cc.p(400, 1000));
	self:addChild(sprite);
	local moveBy = cc.MoveBy:create(1, cc.p(500, 100));
	local scaleBy = cc.ScaleTo:create(1, 0.3);
	local spawn = cc.Spawn:create(moveBy, scaleBy);
	local fnCall = function()
		sprite:removeFromParent();
		if fnCallBack then
			fnCallBack();
		end
	end
	local action = cc.Sequence:create(spawn, cc.CallFunc:create(fnCall));
	sprite:runAction(action);
end

function KG_UIFight:LoadScheme()
	self.m_Layout = ccs.GUIReader:getInstance():widgetFromJsonFile(CUI_JSON_FIGHT_PATH)
	self:addChild(self.m_Layout)

	local btnFight = ccui.Helper:seekWidgetByName(self.m_Layout, "Btn_Fight");
	
	local function touchEvent(sender,eventType)
        if eventType == ccui.TouchEventType.ended then
			self:ProcessEndedEvent(sender,eventType)
        end
    end
	if btnFight then
		btnFight:addTouchEventListener(touchEvent);
	end
	
	local pnlControl = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_control")
	self.m_pnlSearch = pnlControl;
	self.m_pnlSearch:setVisible(false);
	
	-- 回合开始显示
	self.m_pnlRound = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_round")
	self.m_pnlRound:setLocalZOrder(l_tbLocalZOrder.PNL_SHIP_ROUND)
	self.m_pnlRound:setVisible(false)
	self.m_bmpRound =self.m_pnlRound:getChildByName("bmp_turn");

	-- 上下血条
	self.m_layerUp = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_ui_2");
	self.m_layerDown = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_ui_1");
	self.m_layerUp:setLocalZOrder(l_tbLocalZOrder.PNL_SHIP_HP)
	self.m_layerDown:setLocalZOrder(l_tbLocalZOrder.PNL_SHIP_HP)
	
	-- 特效层panel
	self.m_pnlEffect = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_effect");
	self.m_pnlEffect:setLocalZOrder(l_tbLocalZOrder.PNL_EFFECT);
	self.m_pnlCombo = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_unite");
	self.m_pnlCombo:setVisible(false);

	
	--debug
	self.m_pnlTest = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_test");
	if dbf_GetFlag() then
		self.m_pnlTest:setVisible(true)
	else
		self.m_pnlTest:setVisible(false)
	end

	--基本信息
	local pnlPlayerInfo = self.m_Layout:getChildByName("pnl_playerinfo")
	local btnStep = pnlPlayerInfo:getChildByName("btn_move")
	self.m_BmpStep = btnStep:getChildByName("bmp_movenum")
	
	local btnGold = pnlPlayerInfo:getChildByName("btn_money")
	self.m_BmpGold = btnGold:getChildByName("bmp_moneynum")
	
	local btnGold = pnlPlayerInfo:getChildByName("btn_diamond")
	self.m_BmpDiamond = btnGold:getChildByName("bmp_diamondnum")
	
	local imgLevel = pnlPlayerInfo:getChildByName("img_playerlevel");
	self.m_BmpLevel = imgLevel:getChildByName("bmp_playerlevel");
	self.m_BarExp = imgLevel:getChildByName("bar_exp")
	self.m_BmpExp = imgLevel:getChildByName("bmp_expnum")
	
	self.m_BmpFightPoint = ccui.Helper:seekWidgetByName(pnlPlayerInfo, "bmp_playerbattlescore");
	self.m_BmpVIP = ccui.Helper:seekWidgetByName(pnlPlayerInfo, "bmp_viplevel");	

	--加速
	-- self.btn_double = ccui.Helper:seekWidgetByName(self.m_Layout, "double");
	-- self.btn_double:addTouchEventListener(touchEvent)
	-- self.btn_double:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_BUTTON_SPEED)
	-- local img_icon = self.btn_double:getChildByName("doubleicon")
	-- img_icon:loadTexture(CUI_PATH_SPEED_1)

	--test
	--暂停
	local fnCall = function (sender)
		print("fnCall")
		if not self.m_bPaused then
			print("暂停 ... ")
			self.m_bPaused = true;
			-- self:pause()
			-- for k, v in pairs(self:getChildren()) do
				-- v:pause()
			-- end
			cc.Director:getInstance():pause();
			-- self:onExit();
		else
			print("重新开始 ... ")
			self.m_bPaused = false;
			-- self:resume();
			-- for k, v in pairs(self:getChildren()) do
				-- v:resume()
			-- end
			cc.Director:getInstance():resume();
			-- self:onEnter();
		end
	end
	local pauseBtnItem = cc.MenuItemImage:create(CUI_PATH_PAUSE,CUI_PATH_PAUSE);
	pauseBtnItem:registerScriptTapHandler(fnCall)
	local  menu = cc.Menu:create()
	menu:setVisible(false);
	local point = VisibleRect:top()
	menu:setPosition(VisibleRect:left())
	menu:addChild(pauseBtnItem)
	self:addChild(menu)
	
	local onKeyPressed = function(keyCode, event)
		print("event", event, keyCode, cc.KeyCodeKey[138], cc.KeyCode.KEY_R)
		if keyCode == 138 then		-- 'r'
			for i = 1, 2 do			--camp
				for j = 1, 6 do		--pos
					local node = self:GetStillNode(i, j)
					local n = node:getBackGroundColorOpacity()
					local btnState = ccui.Helper:seekWidgetByName(node, "btn_state")
					if n > 0 then
						menu:setVisible(false);
						node:setBackGroundColorOpacity(0)
						if btnState then
							btnState:setOpacity(0)
						end
					else
						menu:setVisible(true);
						node:setBackGroundColorOpacity(50)
						if btnState then
							btnState:setOpacity(50)
						end
					end
				end
			end
		end
		if keyCode == cc.KeyCode.KEY_E then		-- 'e'
			for i = 1, 2 do			--camp
				local szName = "pnl_ship_effect_" .. i;
				local pnlShip = self.m_pnlEffect:getChildByName(szName);
				
				local n = pnlShip:getBackGroundColorOpacity()
				if n > 0 then
					pnlShip:setBackGroundColorOpacity(0)
				else
					pnlShip:setBackGroundColorOpacity(50)
				end
			end
		end
	end
	local listener = cc.EventListenerKeyboard:create();
	listener:registerScriptHandler(onKeyPressed, cc.Handler.EVENT_KEYBOARD_PRESSED)
	local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
	--test end
	
	--cost
	self.m_widgetCostItem = ccui.Helper:seekWidgetByName(self.m_Layout, self.m_szCostItem);
	self.m_widgetCostItem:setVisible(false);
	
	-- 新增战斗文字播报
	local pnlFightText = self.m_Layout:getChildByName("pnl_fight_text")
	self.m_svText = pnlFightText:getChildByName("sv_text")
	self.m_svText:scrollToBottom(0, false)
	self.m_lblNpcName = self.m_svText:getChildByName("lbl_npc_name")
	local pnlTurn = self.m_svText:getChildByName("pnl_turn")
	pnlTurn:setVisible(false);
	
	-- 按钮：首页
	local btn2Main = self.m_layerDown:getChildByName("btn_main")
	btn2Main:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_BUTTON_SPEED)
	local fn2Main = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			print("btn main ... ");
			if self.m_bOneTime then
				self:runAction(cc.RemoveSelf:create());
			else
				FightViewLogic:getInstance():closeLayer();
			end
		end
	end
	btn2Main:addTouchEventListener(fn2Main);

	--下拉菜单
	self.m_setting = self.m_Layout:getChildByName("btn_setting")
	self.m_btnList = ccui.Helper:seekWidgetByName(self.m_setting, "pnl_btnlist")
	local settingEvent = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then		
			self.m_setting:setTouchEnabled(false)
			local tAction = {}
			if self.m_btnList:getPositionY() == l_tbFightSetting.nOriY then
				table.insert(tAction, cc.MoveTo:create(l_tbFightSetting.nTime, cc.p(self.m_btnList:getPositionX(), l_tbFightSetting.nY)))
			else
				table.insert(tAction, cc.MoveTo:create(l_tbFightSetting.nTime, cc.p(self.m_btnList:getPositionX(), l_tbFightSetting.nOriY)))
			end
			table.insert(tAction, cc.CallFunc:create(function()
				self.m_setting:setTouchEnabled(true)
			end))
			self.m_btnList:runAction(cc.Sequence:create(tAction))
		end
	end
	self.m_setting:addTouchEventListener(settingEvent)

	-- 按钮：战斗统计
	local btnStatistics = self.m_btnList:getChildByName("btn_mail")
	btnStatistics:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_BUTTON_SPEED);
	local fnStatistics = function(sender, eventType) 
		if eventType == ccui.TouchEventType.ended then
			local nGold, nExp, nAP, tbItems, tbEquips = me:GetAfkStatistics();
			KGC_AFK_STATISTICS_LOGIC_TYPE:getInstance():UpdateData(nGold, nExp, nAP, tbItems, tbEquips);
		end
	end
	btnStatistics:addTouchEventListener(fnStatistics)
	
	-- 按钮：地图探索
	local btnMap = pnlFightText:getChildByName("btn_map")
	local fn2Map = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			print("btn map ... ");
			MapViewLogic:getInstance():openMap(MapViewLogic:getInstance().currentMapID);
		end
	end
	btnMap:addTouchEventListener(fn2Map)
	
	-- 按钮：快速战斗
	local btnSpeed = pnlFightText:getChildByName("btn_speed")
	local fnSpeed = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			self:StartSpeed();
		end
	end
	btnSpeed:addTouchEventListener(fnSpeed)
	
	-- 按钮：世界聊天
	local btnChat = self.m_Layout:getChildByName("btn_chat")
	local fnChat = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			self:OpenChat();
		end
	end
	btnChat:addTouchEventListener(fnChat)
	
	-- 按钮：世界聊天
	local btnAfk = pnlFightText:getChildByName("btn_afk")
	local fnAfk = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			self:OpenAfkPoint();
		end
	end
	btnAfk:addTouchEventListener(fnAfk)
	
	-- 增加奖励进度@2015/11/11
	local pnlRewardMore = self.m_Layout:getChildByName("pnl_reward_more");
	-- pnlRewardMore:setTouchEnabled(false);
	pnlRewardMore:setLocalZOrder(l_tbLocalZOrder.PNL_REWARD_MORE);
	local fnGetReward = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			-- self:GetRewardMore();
			if self.m_canGetReward then
				--获取奖励
				self:GetRewardMore();	
			else
				--弹出奖励tips
				self:setStateCheckZOrder(true)
				self:AddSubLayer(FightCageLayer.new(me:GetCurrentAfkPoint()))				
			end	
		end
	end
	pnlRewardMore:addTouchEventListener(fnGetReward);
	
	-- 第一次加载
	self:LoadHeroPanel(l_tbCamp.MINE);
	self:LoadHeroPanel(l_tbCamp.ENEMY);

	--主按钮加载
	self.m_btnLayer = MainButtonLayer:create(false, true)
	self:AddSubLayer(self.m_btnLayer)
	
	return self;
end

--设置英雄点击zorder
function KG_UIFight:setStateCheckZOrder(bReset)		
	if self.m_tbNode2Npc then
		local pnlState = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_state")
		for btnNode, _ in pairs(self.m_tbNode2Npc) do
			if bReset then
				btnNode:setGlobalZOrder(0)
				pnlState:setGlobalZOrder(0)
			else
				btnNode:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_BUTTON_NPC)
				pnlState:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_BUTTON_NPC)
			end
		end
	end
end

function KG_UIFight:SetPlayerInfoVisible(bVisble)
	self.m_Layout:getChildByName("pnl_playerinfo"):setVisible(bVisble)
end

function KG_UIFight:UpdateMoneyData()
	local nAP = me:GetAP();
	local nGold = me:GetGold();
	local nDiamond = me:GetDiamond();
	local nLevel = me:GetLevel();
	local nVIP = me:GetVIP();
	local nExp = me:GetExp()
	local nLevelUpExp = me:GetLevelUpExp();
	local szExp = nExp .. "/" .. nLevelUpExp;
	local nPercent = nExp / nLevelUpExp * 100;
	local nFightPoint = me:GetFightPoint();

	if nPercent < 0 then
		nPercent = 0;
	elseif nPercent > 100 then
		nPercent = 100;
	end
	
	if nPercent ~= self.m_BarExp:getPercent() then 
		local EffectNode1 = af_GetEffectByID(60044);
		self.m_BarExp:addChild(EffectNode1);
	end

	if nGold ~= tonumber(self.m_BmpGold:getString()) then 
		local EffectNode1 = af_GetEffectByID(60042);
		EffectNode1:setPositionY(25)
		EffectNode1:setPositionX(0)
		self.m_BmpGold:addChild(EffectNode1);
	end
	
	self.m_BmpStep:setString(tostring(nAP))
	self.m_BmpLevel:setString(tostring(nLevel))
	self.m_BmpVIP:setString(tostring(nVIP))
	self.m_BmpDiamond:setString(tostring(nDiamond));
	self.m_BmpExp:setString(szExp)
	self.m_BarExp:setPercent(nPercent);
	self.m_BmpFightPoint:setString(nFightPoint);

	lableNumAnimation(self.m_BmpGold,nil,nGold,1);
end

function KG_UIFight:ProcessEndedEvent(sender,eventType)
	local widgetName = sender:getName()
	if widgetName == "Btn_Fight" then
		sender:setVisible(false)
	elseif widgetName == "btn_over" then
		FightViewLogic:getInstance():closeLayer();
	elseif widgetName == "double" then
		self:setPlaySpeed()
	end	
end

--@function: 把角色UI先加载进来
--@注意：studio的控件引用计数是2, 最后没有释放掉内存
function KG_UIFight:LoadHeroPanel(nCamp)	
	local szPanel = "pnl_ship_" .. nCamp
	local pnlShip = ccui.Helper:seekWidgetByName(self.m_Layout, szPanel)
	if not pnlShip then
		cclog("[Error]没有找到pnl_ship_(%s)控件@LoadHeroPanel", szPanel)
		return;
	end
	
	local tbPanels = self:GetHeroPanelByCamp(nCamp)
	for _, nPos in pairs(l_tbPos) do
		local szPnlHero = "pnl_hero_" .. nPos
		local pnlNode = pnlShip:getChildByName(szPnlHero)
		pnlHero = pnlNode:getChildByName("anipnl")
		
		if pnlHero then
			pnlHero:setVisible(true);
		end
		
		-- 添加英雄UI
		local node = ccs.GUIReader:getInstance():widgetFromJsonFile(CUI_JSON_ROLE_TEMPLATE_PATH)
		node:setName(self.m_szPnlModel)
		pnlHero:addChild(node);
		-- 界面操作
		local pnlNpc = node:getChildByName("pnl_npc")
		local pnlHP = pnlNpc:getChildByName("pnl_hp")
		pnlHP:setVisible(false);
		-- 保存本地
		tbPanels[nPos] = node;
		
		--战斗界面角色面板比例调整
		local nodeSize = node:getContentSize();
		local pnlHeroSize = pnlHero:getContentSize();
		local scale = pnlHeroSize.width/nodeSize.width;
		node:setScale(scale)
	end
end

function KG_UIFight:GetHeroPanel()
	if not self.m_tbHeroPanel then
		self.m_tbHeroPanel = {};
	end
	return self.m_tbHeroPanel;
end

function KG_UIFight:GetHeroPanelByCamp(nCamp)
	local tbPanels = self:GetHeroPanel();
	if not self:IsValidCamp(nCamp) then
		return;
	end
	
	if not tbPanels[nCamp] then
		tbPanels[nCamp] = {};
	end
	return tbPanels[nCamp]
end

function KG_UIFight:GetHeroPanelByPos(nCamp, nPos)
	print("GetHeroPanelByPos", nCamp, nPos);
	local tbPanels = self:GetHeroPanelByCamp(nCamp);
	tst_print_lua_table(self.m_tbHeroPanel);
	return tbPanels[nPos]
end

--@function: 获取战斗面板上某个位置挂载的英雄面板(role_ui.json对应的)
--@nCamp和nPos: 阵营和位置决定了唯一的位置
--@使用：和GetWidgetHero比较
function KG_UIFight:GetWidgetHero(nCamp, nPos)
	if self:IsValidCamp(nCamp) then
		local pnlNode = self:GetNode(nCamp, nPos)
		local pnlHero = ccui.Helper:seekWidgetByName(pnlNode, self.m_szPnlModel)
		return pnlHero;
	else
		cclog("[Error]camp(%d) is not valid!@GetWidgetHero!", nCamp or 0)
	end
end

--@function: 获取战斗面板某个位置的panel
--@nCamp和nPos: 两个值决定了唯一的位置
--@使用：和GetWidgetHero比较
function KG_UIFight:GetNode(nCamp, nPos)
	nPos = nPos or 0
	if self:IsValidCamp(nCamp) then
		local szPanel = "pnl_ship_" .. nCamp
		local pnlShip = ccui.Helper:seekWidgetByName(self.m_Layout, szPanel)
		if pnlShip then
			local szPnlHero = "pnl_hero_" .. nPos
			local pnlHero = ccui.Helper:seekWidgetByName(pnlShip, szPnlHero)
			if pnlHero then
				local nodeHero = ccui.Helper:seekWidgetByName(pnlHero, "anipnl")
				return nodeHero;
			end
			return pnlHero;
		end
	end
end

function KG_UIFight:GetShipPanel(nCamp)
	if self:IsValidCamp(nCamp) then
		local szPanel = "pnl_ship_" .. nCamp
		local pnlShip = ccui.Helper:seekWidgetByName(self.m_Layout, szPanel)
		return pnlShip;
	end
end

function KG_UIFight:ChangePanelOrder(nCamp)
	local nCamp = nCamp or l_tbCamp.MINE;
	local pnlShip = self:GetShipPanel(nCamp)
	local pnlShip2 = self:GetShipPanel( 3 - nCamp)
	if pnlShip and pnlShip2 then
		pnlShip:setLocalZOrder(l_tbLocalZOrder.PNL_SHIP_HIGHER)
		pnlShip2:setLocalZOrder(l_tbLocalZOrder.DEFAULT)
	end
end

--@function: 不动的那个panel, 用于静止坐标点的获取
function KG_UIFight:GetStillNode(nCamp, nPos)
	nPos = nPos or 0
	if self:IsValidCamp(nCamp) then
		local szPanel = "pnl_ship_" .. nCamp
		local pnlShip = ccui.Helper:seekWidgetByName(self.m_Layout, szPanel)
		if pnlShip then
			local szPnlHero = "pnl_hero_" .. nPos
			local pnlHero = ccui.Helper:seekWidgetByName(pnlShip, szPnlHero)
			return pnlHero;
		end
	end
end

function KG_UIFight:GetWidgetHP(nPos)
	local pnlNpc = self:GetWidgetHero(nPos)
	local wHP = ccui.Helper:seekWidgetByName(pnlNpc, "bar_hp")
end

function KG_UIFight:IsValidCamp(nCamp)
	if nCamp == l_tbCamp.MINE or nCamp == l_tbCamp.ENEMY then
		return true;
	end
	
	cclog("[Error]camp(%d) is not valid!@IsValidCamp!", nCamp or 0)
	return false;
end

function KG_UIFight:LoadHero(hero, pnlHero)
	local nPos = hero:GetPos()
	local nCamp = hero:GetFightShip():GetCamp();

	local armature = nil; 
	local node = self:GetHeroPanelByPos(nCamp, nPos)
	node:setVisible(true)
	if not node then
		return;
	end
	if pnlHero then
		local pnlNpc = ccui.Helper:seekWidgetByName(node, "pnl_armature")
		armature = self:CreateHero(hero, pnlNpc)
		-- local imgHero = nil;
		-- if hero:GetHeroObj():IsHero() then
			-- local img_shadow = ccui.Helper:seekWidgetByName(pnlNpc, "img_shadow")
			-- img_shadow:setVisible(true);
			-- imgHero = ccui.Helper:seekWidgetByName(pnlNpc, "img_hero")
		-- else
			-- imgHero = ccui.Helper:seekWidgetByName(pnlNpc, "img_monster")
		-- end

		local sizePnlNpc = pnlNpc:getContentSize();
		local x, y = sizePnlNpc.width/2, 0;
		armature:setPosition(cc.p(x, y));

		-- 播放出场动画
		local bIsAppear, nEffectID = KGC_MODEL_MANAGER_TYPE:getInstance():IsAppear(hero:GetHeroObj():GetModelID());
		print("[log]是否播放出场动画", bIsAppear, nEffectID);
		if bIsAppear then
			local szAnimation = "appear";
			local fnStand = function(event)
				if event.animation == szAnimation then
					armature:setAnimation(0, 'standby', true)
				end
			end
			armature:registerSpineEventHandler(fnStand, sp.EventType.ANIMATION_COMPLETE)
			armature:setAnimation(0, szAnimation, false);
			local nLayerID = self:GetLayerID();		-- for 特效
			local effect = af_BindEffect2Node(pnlHero, nEffectID, nil, nil, nil, {nil, nil, nLayerID})
		else
			armature:setAnimation(0, 'standby', true);
		end
		
		--设置每个npc个人血条
		local barHP = ccui.Helper:seekWidgetByName(node, "pnl_hp")
		barHP:setVisible(true)
		if barHP and  hero:GetHeroObj():IsBloodShare() then
			barHP:setVisible(false)
		end
		
		if barHP then
			local barMineHP = barHP:getChildByName("bar_hp");
			local barEnemyHP = barHP:getChildByName("bar_enemyhp");
			if barMineHP and barEnemyHP then
				if nCamp == l_tbCamp.ENEMY then
					barMineHP:setVisible(false);
					barEnemyHP:setVisible(true);
				end
			end
		end
		
		--状态队列初始化
		local listview_state = ccui.Helper:seekWidgetByName(node, "listview_state")
		local listview_elem = ccui.Helper:seekWidgetByName(node, "img_state")
		local pnlState = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_state");
		local svState = pnlState:getChildByName("scrollview_stateinfo")
		local imgStateBg = pnlState:getChildByName("img_statebg")
		local pnlCoverState = pnlState:getChildByName("pnl_cover_state");
		hero:UIInitStateQueue(pnlState, self)
		pnlState:setVisible(true);
		imgStateBg:setVisible(false);
		svState:setVisible(false);
		pnlCoverState:setVisible(false);
		
		local btnNode =  ccui.Helper:seekWidgetByName(node, "btn_state")
		self.m_tbNode2Npc[btnNode] = hero;
		btnNode:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_BUTTON_NPC);
		
		local fnTouchEvent = function(sender,eventType)
			if eventType == ccui.TouchEventType.began then
				print("touch hero ... ");
				--选中的最后处理
				local target = nil;
				for camp, tbHeros in pairs(self.m_tbHeros) do
					for pos, npc in pairs(tbHeros) do
						if npc == self.m_tbNode2Npc[sender] then
							target = npc;
						else
							npc:SetStateVisible(false)
						end
					end
					
				end
				if target then
					local bVisble = target:GetStateVisible();
					target:SetStateVisible(not bVisble);
					pnlCoverState:setVisible(not bVisble);
					if bVisble then
						pnlState:setLocalZOrder(l_tbLocalZOrder.PNL_SHIP_STATE);
						pnlState:setGlobalZOrder(l_tbGlobalZOrder.TOUCH_PNL_STATE);
					end
				else
					pnlCoverState:setVisible(false);
				end
			end
		end

		if btnNode then
			btnNode:addTouchEventListener(fnTouchEvent);
		end
		
		--点击空白处状态界面消失
		if pnlCoverState then
			pnlCoverState:addTouchEventListener(fnTouchEvent)
		end
	end
	
	--契约生物队列
	local contractQueue = ccui.Helper:seekWidgetByName(node, "scv_monsterview")
	for i=1, 3 do
		local szName = "pnl_showmonster" .. i
		local pnlMonster = ccui.Helper:seekWidgetByName(contractQueue, szName)
		local imgNon = pnlMonster:getChildByName("img_nomonstericon")
		local imgMonster = pnlMonster:getChildByName("img_simplemonstericon")
		imgNon:setVisible(true);
		imgMonster:setVisible(false);
	end
	if hero:GetHeroObj():IsBloodShare() then
		contractQueue:setVisible(false)
	end
	
	--触发技能标记
	local szNormaMark = "img_statemark";
	local widget = ccui.Helper:seekWidgetByName(node, szNormaMark)
	self:AddMarkWidget(nCamp, nPos, szNormaMark, widget)
	print("[log]加载触发技能：", hero:GetHeroObj():GetName(), hero:GetHeroObj():HasTriggerSkills())
	if hero:GetHeroObj():HasTriggerSkills() then
		self:AddMark(widget, szNormaMark)
	end
	print("[Log]Loadhero 结束", hero:GetName(), armature)

	return armature, node;
end

function KG_UIFight:CreateHero(hero, pnlHero)
	print("KG_UIFight:CreateHero ")
	local nModelID = hero:GetHeroObj():GetModelID();
	local armature = KGC_MODEL_MANAGER_TYPE:getInstance():CreateNpc(nModelID);
	if pnlHero and armature then
		pnlHero:addChild(armature, 1)
	end
	
	return armature;
end

--@function: 更新触发类标记
function KG_UIFight:UpdateMark(widget, szMark)
	local szMark = szMark or "img_statemark";

	local tbCounters = self:GetMarkCounters()
	local nCount = tbCounters[widget]
	if nCount and widget then
		if nCount > 0 then
			widget:setVisible(true);
		else
			widget:setVisible(false);
		end
	end
end

--@function: 触发标记-增加触发标记个数
function KG_UIFight:AddMark(widget, szMark)
	local szMark = szMark or "img_statemark";
	local tbCounters = self:GetMarkCounters();
	if tbCounters[widget] then
		tbCounters[widget] = tbCounters[widget] + 1;
		self:UpdateMark(widget, szMark);
	end
end

--@function: 触发标记-减少触发标记个数
function KG_UIFight:RemoveMark(widget, szMark)
	local szMark = szMark or "img_statemark";
	local tbCounters = self:GetMarkCounters();
	if tbCounters[widget] then
		tbCounters[widget] = tbCounters[widget] - 1;
		self:UpdateMark(szMark);
	end
end

--@function: 触发标记-初始化设置触发标记的控件信息，减少之后使用的查找时间
function KG_UIFight:AddMarkWidget(nCamp, nPos, szMark, widget)
	local szMark = szMark or "img_statemark";
	local tbMarks = self:GetMarks(nCamp, nPos);
	--新的widget会替换旧的
	tbMarks[szMark] = widget;
	
	--计数器
	local tbCounters = self:GetMarkCounters();
	tbCounters[widget] = 0;
end

function KG_UIFight:GetWidgetMarks()
	if not self.m_tbWidgetMarks then
		self.m_tbWidgetMarks = {}
	end
	
	if not self.m_tbWidgetMarks.tbWidgets then
		self.m_tbWidgetMarks.tbWidgets = {}
	end
	
	if not self.m_tbWidgetMarks.tbCounters then
		self.m_tbWidgetMarks.tbCounters = {}
	end
	
	return self.m_tbWidgetMarks;
end

function KG_UIFight:GetMarks(nCamp, nPos)
	local tbMarkWidgets = self:GetWidgetMarks().tbWidgets;
	
	if not tbMarkWidgets[nCamp] then
		tbMarkWidgets[nCamp] = {};
	end
	
	if not tbMarkWidgets[nCamp][nPos] then
		tbMarkWidgets[nCamp][nPos] = {}
	end

	return tbMarkWidgets[nCamp][nPos];
end

function KG_UIFight:GetMarkCounters()
	return self:GetWidgetMarks().tbCounters
end

--@function: 获取触发技能Mark的表示的widget(默认选择"img_statemark"的image)
function KG_UIFight:GetMarkWidget(nCamp, nPos)
	local tbMarks = self:GetMarks(nCamp, nPos)
	
	local widget = tbMarks["img_statemark"];
	if widget then
		return widget;
	end
end
	
function KG_UIFight:UpdateHero(hero, ... )
	local nPos = hero:GetPos()
	local tbArg = {...}
	
	local nCamp = hero:GetFightShip():GetCamp()
	local szPanel = "pnl_ship_" .. nCamp
	local pnlShip = ccui.Helper:seekWidgetByName(self.m_Layout, szPanel)
	if pnlShip then
		local szPnlHero = "pnl_hero_" .. nPos
		local pnlNode = ccui.Helper:seekWidgetByName(pnlShip, szPnlHero)
		pnlHero = ccui.Helper:seekWidgetByName(pnlNode, "anipnl")
		local arm, node = self:LoadHero(hero, pnlHero)
		self:SetArmature(nCamp, nPos, arm)
		
		if pnlHero then
			pnlHero:setVisible(true);
		end

		if self:AddHero(nCamp, nPos, hero) then

		end
	end
end

function KG_UIFight:AddHero(nCamp, nPos, hero)
	local bRet = false;
	if not self:IsValidCamp(nCamp) then
		return false;
	end
	if not self.m_tbHeros[nCamp] then
		self.m_tbHeros[nCamp] = {};
	end
	if gf_IsValidPos(nPos) then
		self.m_tbHeros[nCamp][nPos] = hero;
		bRet = true;
	end

	-- 更新血条
	-- local nMaxHP = hero:GetHP();
	local nMaxHP = hero:GetHeroObj():GetHP();
	print("[Log]AddHero, nMaxHP", nMaxHP, nCamp, nPos, hero:GetHeroObj():GetHP())
	self:UpdateHP(nCamp, nPos, nMaxHP, nMaxHP);

	return bRet;
end

function KG_UIFight:RemoveHero(nCamp, nPos)
	if not self:IsValidCamp(nCamp) then
		return false;
	end

	if not self.m_tbHeros or not gf_IsValidPos(nPos) then
		return false;
	end
	
	-- 英雄处理
	local tbHeros = self.m_tbHeros[nCamp];
	local hero = tbHeros[nPos];
	if hero then
		hero:UnInit();
		tbHeros[nPos] = nil;
	end
	local node = self:GetHeroPanelByPos(nCamp, nPos)
	if node then
		node:setVisible(false);
	end
	
	-- 置空Armature
	self:SetArmature(nCamp, nPos, nil)
	
	-- 标记清空
	local widget = self:GetMarkWidget(nCamp, nPos);
	self:RemoveMark(widget);

	return false;
end

function KG_UIFight:BeforePlayAnimaition()
	self.m_nAnimationTurn = 1;
	self.m_nRound = 0;
	--一些准备内容
end

function KG_UIFight:StartAnimation()
	self.m_pnlSearch:setVisible(false);
	cclog(".........................................");
	cclog("Test: 开始播放动画...")
	self:BeforePlayAnimaition();
	--正式播放
	self:PlayAnimation();
end

function KG_UIFight:UIDeath(nCamp, nPos, nTurn, fnCallBack)
	-- local pnlHero = self:GetWidgetHero(nCamp, nPos)
	local pnlHero = self:GetHeroPanelByPos(nCamp, nPos)
	if pnlHero then
		pnlHero:setVisible(false);
		local fnCall = function()
			-- 删除骨骼
			self:SetArmature(nCamp, nPos, nil)
			self:RemoveHero(nCamp, nPos)
			pnlHero:pause();
			local fight = KGC_FightHall:getInstance();
			local products = fight:GetProducts()
			local tbRet = products:GetRetState(nTurn)
			cclog("[Log] 英雄(位置：%d)死亡'条件'触发, #tbRet(%d), 当前轮数(%d- %d)", nPos, #(tbRet or {}), self.m_nAnimationTurn - 1, nTurn)
			g_CondTrigger:NotifyUI(tbRet, self, l_tbCondID.DEAD)
			print("[Log]删除节点，通知死亡条件触发结束...")
			if type(fnCallBack) == "function" then
				fnCallBack();
			end
		end
		
		local arm = self:GetArmature(nCamp, nPos)
		local szAnimation = "death"
		cclog("[Log]生物死亡界面更新, arm(%s)", tostring(arm))
		if arm then
			local function fnSpineAnimationEvent(event)
				if event.animation == szAnimation then
					-- arm:unregisterSpineEventHandler(sp.EventType.ANIMATION_COMPLETE)
					fnCall();
				end
			end

			print("[registerSpineEventHandler] fightview 1", szAnimation)
			arm:registerSpineEventHandler(fnSpineAnimationEvent, sp.EventType.ANIMATION_COMPLETE)

			arm:setAnimation(0, szAnimation, false)
		else
			fnCall();
		end
	else	
		if type(fnCallBack) == "function" then
			fnCallBack();
		end
	end
end

function KG_UIFight:UpdateHP(nCamp, nPos, nCurHP, nMaxHP, nDamage, nTurn, fnCallBack)
	local pnlHero = self:GetWidgetHero(nCamp, nPos)
	-- fnCallBack要调用一次
	local bFlag = false;
	if pnlHero then
		local proHP, proHP2 = nil, nil
		local hero = self:GetHeroByPos(nCamp, nPos)
		if not hero then
			return;
		end
		if not hero:GetHeroObj():IsBloodShare() then
			if nCamp == l_tbCamp.MINE then
				proHP = ccui.Helper:seekWidgetByName(pnlHero, self.m_szHeroHP)
			else
				proHP = ccui.Helper:seekWidgetByName(pnlHero, "bar_enemyhp")
			end
		else
			local parent = pnlHero:getParent():getParent()
			proHP = ccui.Helper:seekWidgetByName(parent, "health_full")
			proHP2 = ccui.Helper:seekWidgetByName(parent, "health_empty")
			
			if nCamp == l_tbCamp.MINE then
				proHP = ccui.Helper:seekWidgetByName(self.m_layerDown, "health_full")
				proHP2 = ccui.Helper:seekWidgetByName(self.m_layerDown, "health_empty")
			else
				proHP = ccui.Helper:seekWidgetByName(self.m_layerUp, "health_full")
				proHP2 = ccui.Helper:seekWidgetByName(self.m_layerUp, "health_empty")
			end
			print("proHP", proHP, proHP2, self.m_layerUp, self.m_layerDown)
		end

		local nPercent = nCurHP / nMaxHP * 100;
		cclog("界面血量更新(伤害：%s): 阵营(%d)-当前血量/总血量(%d/%d)-->%d/%%", tostring(nDamage), nCamp, nCurHP, nMaxHP, nPercent)
		if nPercent < 0 then
			nPercent = 0;
		elseif nPercent > 100 then
			nPercent = 100;
		end
		if proHP then
			proHP:setPercent(nPercent)
			if proHP2 then
				proHP2:setPercent(nPercent);
			end
		end
		
		--notify:下面处理放在最后面, 因为Death中会删掉前面的角色, 控件无效了
		print(111, nCurHP, hero:GetHeroObj():IsBloodShare(), hero:GetName(), hero:GetPos(), nTurn)
		if nCurHP <= 0 and not hero:GetHeroObj():IsBloodShare() then
			if nTurn then
				self:UIDeath(nCamp, nPos, nTurn, fnCallBack)
				bFlag = true;
			end
			cclog("Test: 生物死亡(%s)，删掉位置(%s)的panel", hero:GetName(), hero:GetPos())
		end

	end
	
	if not bFlag then
		if type(fnCallBack) == "function" then
			fnCallBack();
		end
	end
end

--@function: 水晶更新
--@tbCost参数说明
--[[
--@nCur:		当前的可以用的费用
--@nMax:		当前的最大费用
--@nBefore:		之前的可以使用的费用
--@nChange:		最大费用的变化量，费用扣除不需要这个变量
]]
function KG_UIFight:UpdateCost(tbCost)
	if type(tbCost) ~= "table" then
		return;
	end
	local nLayerID = self:GetLayerID();		-- for 特效
	for nCamp, tbCost in pairs(tbCost) do
		local nCur, nMax, nBefore, nChange = unpack(tbCost);
		cclog("[log]Updatecost: nCur(%s), nMax(%s), nBefore(%s), nChange(%s)", tostring(nCur), tostring(nMax), tostring(nBefore), tostring(nChange))
			local tbModelName = {
				[l_tbCamp.MINE] = "listview_cost_2",
				[l_tbCamp.ENEMY] = "listview_cost_1",
			}
			local listCost = ccui.Helper:seekWidgetByName(self.m_Layout, tbModelName[nCamp]);
			if listCost and nCur ~= nBefore then	-- 水晶发生变化了
				local items = listCost:getItems()
				if nCur < nMax then					
					if nChange == 0 then	-- 费用扣除表现
						for i = nCur+1, nMax do
							local item = listCost:getItem(i-1)
							if item then
								local widgetCost = ccui.Helper:seekWidgetByName(item, "cost_full")
								if widgetCost then
									widgetCost:setVisible(false)
									
									local wtCostEmpty = ccui.Helper:seekWidgetByName(item, "cost_empty")
									self:AddEffectByID(wtCostEmpty, 60002)
								end
							end
						end
					else								-- 增加水晶上限
						--逻辑上先补充完整
						local item = self.m_widgetCostItem;
						item:setVisible(true)
						listCost:setItemModel(item)
						local widgetCostEmpty = ccui.Helper:seekWidgetByName(item, "cost_empty")
						local widgetCostFull = ccui.Helper:seekWidgetByName(item, "cost_full")
						widgetCostEmpty:setVisible(true);
						widgetCostFull:setVisible(false);
						for i=1, nChange do
							listCost:pushBackDefaultItem();
						end
					end
				else								-- 增加水晶表现
					--逻辑上先补充完整
					local item = self.m_widgetCostItem;
					item:setVisible(false)
					listCost:setItemModel(item)
					for i=1, nChange do
						listCost:pushBackDefaultItem();
					end
					item:setVisible(false)
					
					local call = function ()
						--移动回来设置前面要增加的为不可见
						for i=1, nMax do
							local item = listCost:getItem(i-1);
							if not item then
								return;
							end
							if i <= nChange then
								item:setVisible(false)
							else
								item:setVisible(true);
							end
						end

						--增加特效
						for i=1, nChange do
							local item = listCost:getItem(i-1);
							if item then
								item:setVisible(true)
								local widgetCostEmpty = ccui.Helper:seekWidgetByName(item, "cost_empty")
								local widgetCostFull = ccui.Helper:seekWidgetByName(item, "cost_full")
								if widgetCostEmpty and widgetCostFull then
									widgetCostEmpty:setVisible(false)
									widgetCostFull:setVisible(false)
								end
								
								--增加特效播放完之后再设置可见
								local node = cc.Node:create();
								node:setPosition(widgetCostEmpty:getPosition())
								item:addChild(node, 1);
								
								local fnShow = function()
									node:removeFromParent(true)
									item:setVisible(true)
									widgetCostEmpty:setVisible(true)
									widgetCostFull:setVisible(true)
								end
								
								af_BindEffect2Node(node, 60001, nil, widgetCostFull:getScaleX(), fnShow, {nil, nil, nLayerID})
							end
						end
					end
					--填满之后移动
					local items = listCost:getItems()
					local fnMove = function ()
						local nMove = nMax - nChange 
						if nMove > 0 then
							for i=1, nMove do
								local item = listCost:getItem(i-1);
								if not item then
									return;
								end
								-- local itemRight = listCost:getItem(i);
								local posX, posY = item:getPosition();
								local action1 = cc.MoveBy:create(0.5, cc.p(self.m_nItemDistance * nChange, 0));
								-- local fnCall = function()
									-- item:setVisible(false)
									-- itemRight:setVisible(true);
								-- end
								local action2 = cc.Place:create(cc.p(posX, posY))
								local action = cc.Sequence:create(action1, action2)
								if i == 1 then
									action = cc.Sequence:create(action1, action2, cc.CallFunc:create(call));
								end
								item:runAction(action)
							end
						else
							call();
						end
					end
					--先填满
					local nFull = nCur - nChange;
					if nBefore < nFull then
						for i = nBefore, nFull-1 do
							local item = listCost:getItem(i)		--注意索引是从0开始的
							if not item then
								return;
							end
							item:setVisible(true)
							local wtCostEmpty = ccui.Helper:seekWidgetByName(item, "cost_empty")
							local wtCostFull = ccui.Helper:seekWidgetByName(item, "cost_full")

							-- 移动用这种方式只触发一次
							if i == nBefore then
								local fnCall = function()
									if wtCostFull then wtCostFull:setVisible(true) end
									if fnMove then
										fnMove();
									end
								end
								af_BindEffect2Node(wtCostEmpty, 60003, nil, 1, fnCall, {nil, nil, nLayerID})
							else
								local fnCall = function()
									if wtCostFull then wtCostFull:setVisible(true) end
								end
								af_BindEffect2Node(wtCostEmpty, 60003, nil, 1, fnCall, {nil, nil, nLayerID})
							end
						end
					else
						fnMove();
					end
				end
			else
				if listCost then
					--第一次清空
					if nMax == 0 then
						--保存两个水晶之间的距离
						local item0 = listCost:getItem(0)
						local item1 = listCost:getItem(1)
						if item0 and item1 then
							local x0, y0 = item0:getPosition();
							local x1, y1 = item1:getPosition();
							self.m_nItemDistance =  x1 - x0;
							-- print("两个item之间的距离为,", x1, y1, x0, y0, x1 - x0)
						else
							local size = self.m_widgetCostItem:getContentSize();
							self.m_nItemDistance = size.width;
						end
						listCost:removeAllItems()
					end
				end
			end
			
			--数字标签
			local widgetHP = nil;
			if nCamp == l_tbCamp.MINE then
				widgetHP = self.m_layerDown
			else
				widgetHP = self.m_layerUp;
			end
			

			if widgetHP then
				local textCost = ccui.Helper:seekWidgetByName(widgetHP, "text_crystal");
				if textCost then
					textCost:setString(nCur .. "/" .. nMax)
				end
			end
	end
end

function KG_UIFight:AddEffectByID(node, nID, fnCallBack, nScale)
	if not node then return false; end
	local effect = af_GetEffectByID(nID, fnCallBack);
	if effect then
		local size = node:getContentSize();

		if nScale then
			nScaleEffct = nScale;
			if nScaleEffct == 0 then
				nScaleEffct = 1;
			end

			effect:setScale(nScaleEffct)
		end

		effect:setPosition(cc.p(size.width/2, size.height/2));
		node:addChild(effect)
	else
		if fnCallBack then
			fnCallBack();
		end
	end
end

--@function: 战斗结束
--@bFoceOver: 是否是强制结束
function KG_UIFight:Over(bForceOver)
	self:ShowCover();
	
	-- 关闭动画
	self:stopAllActions();
	
	local fight = KGC_FightHall:getInstance();
	local nWinner = fight:GetWinner()
	
	--主界面更新
	-- GameSceneManager:getInstance():updateLayer(l_tbUIUpdateType.EU_MONEY);
	
	if self.m_bOneTime then
		self:ClearEnemy();
	else
		-- 先盖住
		self.m_pnlSearch:setVisible(true);
		-- 清空这一场的数据
		self:ClearData();
	end
	
	-- 回调给logic，显示奖励
	if self.m_bCustomFight then
		FightViewLogic:getInstance():OnFightCallBack();
		self.m_bCustomFight = false;
	else
		-- 挂机战斗才向服务器请求奖励(注：如果是被中断的不发送请求)
		if not bForceOver then
			FightViewLogic:getInstance():ReqFightRewardOnLine(nWinner == l_tbCamp.MINE, self.m_nHeroBoxID);
		end
	end
	
	-- 需要再动画播放完毕之后再做的事情
	local fnCallBack = function()
		if self.m_bOneTime then
			if self.m_nHeroBoxID then
				FightViewLogic:getInstance():SetFightGuideStage(self.m_nHeroBoxID);
			end
		end
	end

	if self.m_bOneTime then
		self:PlayRewardAnimation(fnCallBack);
	end
	
	self:ProcessButtonState();

	if not self.m_bOneTime and not self.m_bCustomFight then
		-- 请求当前挂机点的进度
		FightViewLogic:getInstance():ReqRewardMoreCount();
	end
    -- cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames();
    -- cc.Director:getInstance():getTextureCache():removeUnusedTextures();
end

--@nRound: 逻辑上的每一回合
function KG_UIFight.UpdateRound(sender, tbArg)
	local nRound, self = unpack(tbArg)
	if self.m_nRound ~= nRound then
		local products = KGC_FightHall:getInstance():GetProducts()
		cclog("Test: UI回合结束'开始'触发")
		local tbRet = products:GetRetStateByRound(nRound)
		g_CondTrigger:NotifyUI(tbRet, self, l_tbCondID.ROUND_START)
		
		self.m_nRound = nRound or 0;
		print("/********************************第" .. nRound .. "轮 ********************************/")
		--page@2015/11/20 先关掉
		self.m_pnlRound:setVisible(false)
		
		self.m_bmpRound:setString(nRound)
		local fnCall = function()
			self.m_pnlRound:setVisible(false);
		end
		
		-- if DEBUG_MEMORY_LEAK then
		if false then
			fnCall();
		else
			-- ccs.ActionManagerEx:getInstance():playActionByName("fight.json", "roundstart", cc.CallFunc:create(fnCall))
			local action = cc.Sequence:create(cc.DelayTime:create(1), cc.CallFunc:create(fnCall));
			self:runAction(action);
		end
		
		self:UpdateCost(products:GetCost(nRound));
		
		-- 插入播报中
		local pnlTurn = self.m_svText:getChildByName("pnl_turn")
		local tbTexts = {}
		local panel = pnlTurn:clone();
		local bmlRound = panel:getChildByName("bml_round_2")
		bmlRound:setString(nRound)
		panel:setVisible(true);
		local item = self:ConstructText(3, {255, 255, 255}, 255, panel)
		table.insert(tbTexts, item);
		self:InsertText(nil, tbTexts, 3, true)
	end
end

function KG_UIFight.RoundEnd(sender, tbArg)
	local nRound, nNextRound, self = unpack(tbArg)
	print("nRound, self.m_nRound, nNextRound", nRound, self.m_nRound, nNextRound)
	-- if self.m_nRound ~= nRound then
		local fight = KGC_FightHall:getInstance();
		local products = fight:GetProducts()
		local tbRet = products:GetRetState(self.m_nAnimationTurn - 1)
		cclog("Test: 回合结束'条件'触发")
		g_CondTrigger:NotifyUI(tbRet, self, l_tbCondID.ROUND_END)
	-- end
	if self.m_nRound == nRound then
		cclog("Test: 新回合结束'条件'触发")
		local tbRet = products:GetRetStateByRound(nRound)
		g_CondTrigger:NotifyUI(tbRet, self, l_tbCondID.ROUND_END)
	end
end

--@function: 一场战斗结束
function KG_UIFight:EndAnimation()
	local fnCallBack = function()
		self:Over()
		if not self.m_bOneTime then
			local nBoxID = me:RandomMonsterBoxID();
			-- 接下来一场
			self:SearchAndFight(os.time(), nBoxID);
		end
	end
	
	local action = cc.Sequence:create(cc.DelayTime:create(0.8), cc.CallFunc:create(fnCallBack));
	self:runAction(action);
end

function KG_UIFight:PlayAnimation()
	local fight = KGC_FightHall:getInstance();
	local nWinner = fight:GetWinner()
	local products = fight:GetProducts()

	local nTurn = self.m_nAnimationTurn;
	self.m_nAnimationTurn = self.m_nAnimationTurn + 1;
	
	if type(products) ~= "table" then return 0; end
	
	if products:GetTotalNum() <= 0 then return 0; end
	print("nTurn/nTotal", nTurn .. "/" .. products:GetTotalNum())
	if nTurn > products:GetTotalNum() then 
		self:EndAnimation();
		return;
	end
	local nRound = products:GetRound(nTurn)
	local nNextRound = products:GetRound(nTurn+1) or 0
	local tbLauhcer = products:GetLaunchers(nTurn);
	local tbDefend = products:GetDefends(nTurn)
	local tbRetState = products:GetRetState(nTurn)
	
	--test
	local szPos = "{"
	local szCamp1 = "我方"
	local szCamp2 = "敌方"
	for _, v in pairs(tbLauhcer) do
		if v:GetSrc() then
			szPos = szPos .. v:GetPos() .. ","
		end
		local nCamp = v:GetCamp()
		if nCamp == l_tbCamp.ENEMY then
			szCamp1 = "敌方"
			szCamp2 = "我方"
		end
	end
	szPos = szPos .. "}"
	
	local szPosDef = "{"
	for _, v in pairs(tbDefend) do
		szPosDef = szPosDef .. v:GetPos() .. ","
	end
	szPosDef = szPosDef .. "}"
	cclog ("Test: %s(%s) --> %s(%s)", szCamp1, szPos, szCamp2, szPosDef)
	--test end
		
	if dbf_GetFlag() then
		local lblAttack = ccui.Helper:seekWidgetByName(self.m_pnlTest, "lbl_attack")
		if lblAttack then
			local szBuf = szPos .. "-->" .. szPosDef
			lblAttack:setString(szBuf)
		end
	end
	-------------------
	--播放技能动画
	local fnSkillAnimation = function(sender, tbArg)
		local tbLauhcer, tbDefend, tbRetState, self, fnCallFunc, nCastRet = unpack(tbArg)
		local skill = tbLauhcer[1]:GetSkill();
		skill:PlayAnimation(tbLauhcer, tbDefend, tbRetState, self, fnCallFunc, nCastRet, nTurn)

		--同步更新文字输出
		self:UpdateText(tbLauhcer, tbDefend, skill);
	end
	-------------------
	--新的每一轮开始需要等待时间
	local nDelaySecond = 0.1;
	if self.m_nRound ~= nRound then
		nDelaySecond = 1;
	end

	local spaRound = cc.Spawn:create(cc.DelayTime:create(nDelaySecond), cc.CallFunc:create(self.UpdateRound, {nRound, self}))
	
	local nDelayEnd = 0.5
	local nCastRet = products:GetCastRet(nTurn)
	--每一轮结束等待时间(连携不需要等待)
	if nCastRet == l_tbSkillCastRet.RETRY then
		nDelayEnd = 0.1;
	end

	local spaRoundEnd = cc.Spawn:create(cc.DelayTime:create(nDelayEnd), cc.CallFunc:create(self.RoundEnd, {nRound-1, nNextRound-1, self}))
	
	local seqAni = cc.Sequence:create(spaRoundEnd, spaRound, cc.CallFunc:create(fnSkillAnimation, {tbLauhcer, tbDefend, tbRetState, self, self.PlayAnimation, nCastRet}))
	self:runAction(seqAni);
end

function KG_UIFight:ConstructText(nType, tbColour, nOpacity, content, szFont, nFontSize)
	local tbRet = {};
	local r, g, b = unpack(tbColour or {255, 255, 255})
	
	tbRet[1] = nType or 1;
	tbRet[2] = {r, g, b}
	tbRet[3] = nOpacity or 255
	tbRet[4] = content
	tbRet[5] = szFont or "Helvetica"
	tbRet[6] = nFontSize or 26
	return tbRet;
end

function KG_UIFight:UpdateText(tbRetLau, tbRetDef, skill)
	print("[Log]开始更新战斗播报文字 ... ")
	local lau = skill:GetRetLau(tbRetLau);
	local nCamp, nPos = lau:GetKey();
	local hero = lau:GetNpc()
	
	local szAttacker = hero:GetName();
	local szSkill = skill:GetName();
	local szRange = skill:UIGetSelectRange(tbRetDef);
	
	local tbDamage = skill:UIGetDamage(tbRetDef)
	local nDMin, nDMax = 9999999, 0
	for _, v in pairs(tbDamage) do
		local nDamage = math.floor(v)
		if nDamage < nDMin then
			nDMin = nDamage;
		end
		if nDamage > nDMax then
			nDMax = nDamage;
		end
	end
	local szDamage = tostring(nDMax);
	if nDMax > nDMin then
		szDamage = nDMin .. "~" .. nDMax;
	end

	local nEffectType = skill:GetEffectType() or 0;
	local tbTextConfig = l_tbBroadCast[nEffectType]
	if not tbTextConfig then
		cclog("[Error]播报配置错误!@UpdateText(效果类型(%s))", tostring(nEffectType))
		return;
	end
	
	-- 默认文本配置
	local tbNormal = tbTextConfig.textcolour;
	local tbNormalColour = tbNormal[1]
	local nNormalOpacity = tbNormal[2]
	local nNormalFontSize = tbNormal[3]
	
	local tbTexts = {}
	-- 第一个：说明文字1
	local szText1 = tbTextConfig.text1
	local nCastType = skill:GetCastType();
	if nCastType == 1 then
		szText1 = l_tbFightTextConfig.tbCastText[1]
	elseif nCastType == 2 then
		szText1 = l_tbFightTextConfig.tbCastText[2]
	end
	local ret1 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szText1, nil, nNormalFontSize)
	table.insert(tbTexts, ret1);
	
	-- 第二个：费用图片
	local imgCost = ccui.ImageView:create(l_tbFightTextConfig.szPath3)
	imgCost:ignoreContentAdaptWithSize(false);
	local nW, nH = unpack(l_tbFightTextConfig.tbContentSize);
	imgCost:setContentSize(cc.size(nW, nH))
	local lblNumber = ccui.TextBMFont:create()
	lblNumber:setFntFile(l_tbFightTextConfig.szPath4);
	lblNumber:setString(skill:GetCost());
	lblNumber:setScale(l_tbFightTextConfig.nFontScale)
	local sizeImage = imgCost:getContentSize();
	lblNumber:setPosition(cc.p(sizeImage.width/2, sizeImage.height/2))
	imgCost:addChild(lblNumber);
	local retImage1 = self:ConstructText(3, tbNormalColour, nNormalOpacity, imgCost)
	table.insert(tbTexts, retImage1);
	
	-- 第二个：技能名字
	-- print("szSkill = ", szSkill)
	local tbSkillConfig = tbTextConfig.skillnamecolour
	local ret2 = self:ConstructText(1, tbSkillConfig[1], tbSkillConfig[2], szSkill, nil, tbSkillConfig[3])
	table.insert(tbTexts, ret2);
	
	-- 第三个：说明文字2
	local szText2 = " ," .. tbTextConfig.text2
	print("szText2 = ", szText2);
	local ret3 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szText2, nil, nNormalFontSize)
	table.insert(tbTexts, ret3);
	
	-- 第四个：范围类型
	local tbSkillConfig = tbTextConfig.effectrangecolour
	print("szRange = ", szRange);
	local ret4 = self:ConstructText(1, tbSkillConfig[1], tbSkillConfig[2], szRange, nil, tbSkillConfig[3])
	table.insert(tbTexts, ret4);
	
	-- 第五个：说明文字3
	local szText3 = tbTextConfig.text3
	local ret5 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szText3, nil, nNormalFontSize)
	table.insert(tbTexts, ret5);
	
	-- 第六个：效果
	local szEffect = ""
	local tbSkillConfig = tbTextConfig.effectcolour
	if nEffectType == l_tbEffect.E_ATK or nEffectType == l_tbEffect.E_CURE then
		szEffect = szDamage;
	else
		szEffect = skill:GetFightText();
	end
	local ret6 = self:ConstructText(1, tbSkillConfig[1], tbSkillConfig[2], szEffect, nil, tbSkillConfig[3])
	table.insert(tbTexts, ret6);
	
	-- 第七个：说明文字4
	local szText4 = tbTextConfig.text4
	local ret7 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szText4, nil, nNormalFontSize)
	table.insert(tbTexts, ret7);
	self:InsertText(szAttacker, tbTexts, nCamp)
	
	print("[Log]更新战斗播报文字 end ... ")
end

--@function: 插入一个播报到战斗界面中
--@szHead: 头标识
--@tbTexts: 播报内容
--@nCamp: 阵营-头标识显示在左边还是右边
--@bFlag: 是否显示头(长度还是根据前面szHead确定), 默认显示
function KG_UIFight:InsertText(szHead, tbTexts, nCamp, bFlag)
	local nCamp = nCamp or 0;
	local tbPics = {
		[l_tbCamp.MINE] = l_tbFightTextConfig.szPath1,
		[l_tbCamp.ENEMY] = l_tbFightTextConfig.szPath2,
		[0] = l_tbFightTextConfig.szPath2,
	}
	
	local sizeWin = VisibleRect:getVisibleRectType();
	local width = l_tbFightTextConfig.nWidth or 500; 		-- 固定宽度为500
	local height = 10;		-- 初始化高度为100
	local rx, ry, rw, rh = unpack(l_tbFightTextConfig.tbCapInsets or {10, 10, 5, 22})
	local backGround = ccui.ImageView:create(tbPics[nCamp]);
	local nLeftFixedWidth = l_tbFightTextConfig.nFixedWidth;
	backGround._camp = nCamp;
	backGround:ignoreContentAdaptWithSize(false);
	backGround:setScale9Enabled(true);
	backGround:setCapInsets(cc.rect(rx, ry, rw, rh));

	backGround:setContentSize(cc.size(width, height))
	self.m_svText:addChild(backGround);
	
	local lblNpcName = self.m_lblNpcName:clone();
	lblNpcName:setVisible(true);
	lblNpcName:setLocalZOrder(-1);				-- 名字在战斗文字下层
	
	if bFlag then
		lblNpcName:setVisible(false);
	end
	local szNpcName = "";
	if szHead then
		szNpcName = "【" .. szHead .. "】"
	end
	lblNpcName:setString(szNpcName);
	backGround:addChild(lblNpcName);
	-- 重要：每一个聊天气泡从(0.5, 0)这个地方放置, 更方便计算
	backGround:setAnchorPoint(cc.p(0.5, 0))
	
	local sizeName = lblNpcName:getContentSize()
	local sizeBg = backGround:getContentSize();
	-- local x2 = sizeName.width + sizeBg.width/2
	-- page@2015/11/13 名字占固定宽度-->左对齐
	local x2 = sizeBg.width/2 + nLeftFixedWidth;
	if nCamp == l_tbCamp.MINE then
		-- x2 = sizeName.width + sizeBg.width/2
		--颜色(蓝)
		local r, g, b = unpack(l_tbFightTextConfig.tbColorBlue or {0, 153, 255})
		lblNpcName:setColor(cc.c3b(r, g, b));
	elseif nCamp == l_tbCamp.ENEMY then
		-- x2 = sizeWin.width - x2;
		--颜色(红)
		local r, g, b = unpack(l_tbFightTextConfig.tbColorRed or {255, 110, 0})
		lblNpcName:setColor(cc.c3b(r, g, b));
	elseif nCamp == 3 then
		x2 = sizeWin.width/2;
	else
		lblNpcName:setColor(cc.c3b(255, 0, 255));
	end
	--[[
		注：
		* 底框气泡做了一次翻转做了翻转, 0点坐标在尾部
		* 名字的坐标根据固定长度和名字长度计算得到
	--]]
	-- local x1 = sizeBg.width + sizeName.width/2;
	local x1 = sizeBg.width + (nLeftFixedWidth - sizeName.width/2);
	
	lblNpcName:setPosition(cc.p(x1, sizeBg.height/2))
	backGround:setPosition(cc.p(x2, -30));
	
	backGround:setScaleX(-1)
	lblNpcName:setScaleX(-1)
	
	local richText = ccui.RichText:create()
	richText:setVisible(false);
	local nWidthModify = l_tbFightTextConfig.nWidthModify or 25;
	richText:setContentSize(cc.size(width - nWidthModify, height))

	-- notify: 必须从小到大顺序填写
	for tag, tbItems in ipairs(tbTexts or {}) do
		local item = nil;
		local nType = tbItems[1];
		local r, g, b = unpack(tbItems[2])
		local nOpacity = tbItems[3]
		local szText = tbItems[4];
		local nFontSize = tbItems[6]
		if nType == 1 then
			item = ccui.RichElementText:create(tag, cc.c3b(r, g, b), nOpacity, szText, "Helvetica", nFontSize)
		elseif nType == 3 then		-- 自定义节点
			item = ccui.RichElementCustomNode:create(tag, cc.c3b(r, g, b), nOpacity, szText)
		end
		if item then
			richText:pushBackElement(item);
		end
	end
	
	local size = backGround:getContentSize();
	richText:setPosition(cc.p(size.width/2, size.height/2))
	richText:setName("richtext")
	-- 文本框需要在旋转一次才正常
	richText:setScaleX(-1)
	backGround:addChild(richText)
	
	-- 现在下一帧把最大长度调整一下
	local fnUpdate = function()
		local sizeRichText = richText:getVirtualRendererSize();
		local nWidthNew = sizeRichText.width + nWidthModify;

		-- richText:ignoreContentAdaptWithSize(true)
		-- if nWidthNew > width then
			-- richText:setContentSize(cc.size(width - nWidthModify, sizeRichText.height))
			-- richText:ignoreContentAdaptWithSize(false)
		-- else
			-- richText:ignoreContentAdaptWithSize(true)
		-- end
		
		if not self.m_tbRichTexts then
			self.m_tbRichTexts = {}
		end
		table.insert(self.m_tbRichTexts, backGround);
		
		-- page@2015/10/10 播报第一个出来太早了
		backGround:setVisible(false);
		
		self:RefreshText();
		
		backGround:setVisible(true);
	end
	self:runAction(cc.Sequence:create(cc.DelayTime:create(0), cc.CallFunc:create(fnUpdate)))
end

function KG_UIFight:RefreshText()
	local height = 100;		-- 初始化高度为100
	local fnMove = function()
		if not self.m_tbRichTexts then
			self.m_tbRichTexts = {}
		end

		local nTotal = #self.m_tbRichTexts;
		local posYS = l_tbFightTextConfig.nStartHeight or 30;	-- 起始高度
		local nMax = l_tbFightTextConfig.nMaxNums or 8;			-- 最大显示的战斗数据
		local nInterval = l_tbFightTextConfig.nSpace or 5;		-- 间隔
		local nLeftFixedWidth = l_tbFightTextConfig.nFixedWidth;
		
		-- 先放在最下面，再整体向上移动
		local fnModify = function(node)
			local nCamp = node._camp;
			local richtextPre = node:getChildByName("richtext");
			richtextPre:setVisible(true);
			local sizeRichText = richtextPre:getVirtualRendererSize();
			local nRichH = sizeRichText.height;
			if nRichH <= 0 then
				nRichH = height;
			end

			local nHeightModify = l_tbFightTextConfig.nHeightModify or 25;
			local nHeightNew = nRichH + nHeightModify;
			local nWidthModify = 36;
			local nWidthNew = sizeRichText.width + nWidthModify;
			node:setContentSize(cc.size(nWidthNew, nHeightNew))
			richtextPre:setPosition(cc.p(nWidthNew/2, nHeightNew/2))
			if nCamp == 3 then
				-- richtext锚点是(0.5, 0.5)
				richtextPre:setPosition(cc.p(nWidthNew/2, nHeightNew/2))
			end
			
			local lblNpcName = node:getChildByName("lbl_npc_name")
			local sizeName = lblNpcName:getContentSize()
			--[[
				注：
				* 底框气泡做了一次翻转做了翻转, 0点坐标在尾部
				* 名字的坐标根据固定长度和名字长度计算得到
			--]]
			local x0 = nWidthNew + (nLeftFixedWidth - sizeName.width/2);
			-- local x0 = nWidthNew + sizeName.width/2;
			lblNpcName:setPosition(cc.p(x0, nHeightNew/2));
			
			local sizeSvText = self.m_svText:getContentSize();
			-- page@2015/11/13 名字占固定宽度-->左对齐
			-- local x2 = sizeName.width + nWidthNew/2
			local x2 = nWidthNew/2 + nLeftFixedWidth;
			if nCamp == 3 then
				x2 = sizeSvText.width/2;
			end
			node:setPositionX(x2)

			return nHeightNew + nInterval;
		end
		
		--所有都重新调整大小(渲染getVirtualRendererSize才会得到真正的大小)
		local nYAdd = 0;
		for i= nTotal, 1, -1 do
			local node = self.m_tbRichTexts[i]
			if i > nTotal - nMax then	
				local h = fnModify(node)
				local posX, posY = node:getPosition();
				posY = posYS + nYAdd;
				node:setPositionY(posY);
				nYAdd = nYAdd + h;
			else
				self.m_svText:removeChild(node, true);
			end
		end
		
		for i = nTotal, 1, -1 do
			if i <= nTotal - nMax then
				table.remove(self.m_tbRichTexts, i);
			end
		end
		
	end
	
	-- 注意：延时getVirtualRendererSize的值才会刷新
	self:runAction(cc.Sequence:create(cc.DelayTime:create(0.1), cc.CallFunc:create(fnMove)))
end

--@function: 插入系统播报
--@nType: 区分不同的播报类型, eg: 1000-奖励
function KG_UIFight:InsertSystemText(nType, tbArg)
	local tbTextConfig = l_tbBroadCast[nType]
	if not tbTextConfig then
		cclog("[Error]播报配置错误!@UpdateText(效果类型(%s))", tostring(nType))
		return;
	end
	
	-- 默认文本配置
	local tbNormal = tbTextConfig.textcolour;
	local tbNormalColour = tbNormal[1]
	local nNormalOpacity = tbNormal[2]
	local nNormalFontSize = tbNormal[3]
	
	if nType == 1000 then			-- 战斗奖励
		local tbTexts = {};
		local nWinner, nGoldAdd, nExpAdd = unpack(tbArg or {});
		-- 1. 
		local szResult = (nWinner == 1) and "战斗胜利, " or "战斗失败, ";
		local ret1 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szResult, nil, nNormalFontSize)
		table.insert(tbTexts, ret1);
		-- 2.
		local szText1 = tbTextConfig.text1
		local ret2 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szText1, nil, nNormalFontSize)
		table.insert(tbTexts, ret2);
		-- 3.
		local tbGoldConfig = tbTextConfig.skillnamecolour
		local szGold = tostring(nGoldAdd or 0);
		local ret3 = self:ConstructText(1, tbGoldConfig[1], tbGoldConfig[2], szGold, nil, tbGoldConfig[3])
		table.insert(tbTexts, ret3);
		-- 4.
		local szText2 = " ," .. tbTextConfig.text2
		local ret4 = self:ConstructText(1, tbNormalColour, nNormalOpacity, szText2, nil, nNormalFontSize)
		table.insert(tbTexts, ret4);
		-- 5.
		local tbExpConfig = tbTextConfig.effectrangecolour;
		local szExp = tostring(nExpAdd or 0);
		local ret5 = self:ConstructText(1, tbExpConfig[1], tbExpConfig[2], szExp, nil, tbExpConfig[3])
		table.insert(tbTexts, ret5);

		self:InsertText("系统", tbTexts)
	end
end

function KG_UIFight:SetArmature(nCamp, nPos, arm)
	if not self:IsValidCamp(nCamp) then
		cclog("[Error]camp is invalid!")
		return false;
	end
	if not self.m_tbArms[nCamp] then
		self.m_tbArms[nCamp] = {}
	end
	if not gf_IsValidPos(nPos) then
		cclog("[Error]position is invalid!@SetArmature")
		return false;
	end
	
	-- 旧的删掉
	local old = self.m_tbArms[nCamp][nPos]
	if old then
		print("删除旧的骨骼...")
		old:runAction(cc.RemoveSelf:create())
	end
	self.m_tbArms[nCamp][nPos] = arm;
end

function KG_UIFight:GetArmature(nCamp, nPos)
	if not self:IsValidCamp(nCamp) then
		cclog("[Error]camp is invalid @GetArmature")
		return;
	end
	
	if not gf_IsValidPos(nPos) then
		cclog("[Error]position is invalid!@GetArmature")
		return false;
	end
	return self.m_tbArms[nCamp][nPos];
end

function KG_UIFight:GetHeroByPos(nCamp, nPos)
	if not self:IsValidCamp(nCamp) then
		cclog("[Error]camp is invalid!@GetHeroByPos");
		return nil;
	end

	return self.m_tbHeros[nCamp][nPos];
end

--@nPos：界面上位置(1-18)
--@return: hero(data), widgetHero
function KG_UIFight:GetHeroInfo(nCamp, nPos)
	local hero = self:GetHeroByPos(nCamp, nPos)
	local widget = self:GetWidgetHero(nCamp, nPos)
	return hero, widget
end

function KG_UIFight:Update(dt)
	
end

function KG_UIFight:setPlaySpeed()
	local img_icon = self.btn_double:getChildByName("doubleicon")
	if self.m_nCurrentSpeed ==1 then
		cc.Director:getInstance():getScheduler():setTimeScale(2)
		self.m_nCurrentSpeed =   2
		img_icon:loadTexture(CUI_PATH_SPEED_2)
	elseif self.m_nCurrentSpeed ==2 then
		cc.Director:getInstance():getScheduler():setTimeScale(1)
		self.m_nCurrentSpeed = 1
		img_icon:loadTexture(CUI_PATH_SPEED_1)
	end
end

function KG_UIFight:GetPlaySpeed()
	return self.m_nCurrentSpeed;
end

--显示遮罩
function KG_UIFight:ShowCover(nCamp, nPos)
	local nZOrder = l_tbLocalZOrder.PNL_SHIP_MASK;
	local nZOrder1 = l_tbLocalZOrder.PNL_SHIP_NPC;
	local pnlShip = self:GetShipPanel(nCamp)
	
	--先把ship panel的层级关系调整一下
	self:ChangePanelOrder(nCamp);
	
	if pnlShip then
		local pnlCover = pnlShip:getChildByName("pnl_cover")
		if pnlCover then
			pnlCover:setVisible(true)
			--直接pnlShip:getChildByName()会好点，但是接口就乱了
			local pnlHero = self:GetStillNode(nCamp, nPos);
			pnlCover:setLocalZOrder(nZOrder)
			
			if pnlHero then
				pnlHero:setLocalZOrder(nZOrder1)
			end
			
			local szName = "pnl_skillname_" .. nCamp
			local pnlSkill = pnlShip:getChildByName(szName)
			if pnlSkill then
				pnlSkill:setLocalZOrder(nZOrder1)
			end
		end
	else
		--显示全部遮罩
		for nCamp in pairs(l_tbCamp) do
			local pnlShip = self:GetShipPanel(l_tbCamp.MINE)
			if pnlShip then
				local pnlCover = pnlShip:getChildByName("pnl_cover")
				pnlCover:setVisible(true)
				pnlCover:setLocalZOrder(nZOrder)
			end
		end
	end
end

function KG_UIFight:HideCover(nCamp, nPos)
	local nZOrder = 0;
	local pnlShip = self:GetShipPanel(nCamp)
	if pnlShip then
		local pnlCover = pnlShip:getChildByName("pnl_cover")
		if pnlCover then
			pnlCover:setVisible(false)
			--直接pnlShip:getChildByName()会好点，但是接口就乱了
			local pnlHero = self:GetStillNode(nCamp, nPos);
			pnlHero:setLocalZOrder(nZOrder)
			
			local szName = "pnl_skillname_" .. nCamp
			local pnlSkill = pnlShip:getChildByName(szName)
			if pnlSkill then
				pnlSkill:setLocalZOrder(nZOrder)
			end
		end
	end
end

function KG_UIFight:RandomPlaceByPoint(nCamp, nPos, fnCall)
	local nZOrder = l_tbLocalZOrder.PNL_SHIP_NPC;
	--配置表
	local tbConfig = require("script/cfg/client/action/skillrandom")
	
	--根据panel的大小设置随机图的大小
	local fnSetScale = function(node1, node2)
		local size1 = node1:getContentSize();
		local size2 = node2:getContentSize();
		local nScale = size1.width / size2.width;
		if size2.width == 0 then
			nScale = 1;
		end
		node2:setScale(nScale * 1.2)
	end
	local sprite = cc.Sprite:create(CUI_PATH_EFFECT_SKILL_RANDOM);
	local nSrc, nDst = unpack(tbConfig.tbRandomAlpha)
	sprite:setBlendFunc(nSrc, nDst);	--gl.BLEND_SRC_ALPHA
	sprite:setVisible(false)
	local target = self:GetStillNode(nCamp, nPos)
	fnSetScale(target, sprite)

	--需求：开始之前所有英雄都要亮起来
	local tbNodes = {}
	local tbSprites = {}
	for i = l_tbPos.POS_4, l_tbPos.POS_6 do
		local node = self:GetStillNode(nCamp, i)
		if node then
			local spriteAlpha = cc.Sprite:create(CUI_PATH_EFFECT_SKILL_RANDOM);
			local size = node:getContentSize();
			spriteAlpha:setPosition(cc.p(size.width/2, size.height/2))
			fnSetScale(node, spriteAlpha)
			local nSrc, nDst = unpack(tbConfig.tbStartAlpha)
			spriteAlpha:setBlendFunc(nSrc, nDst);
			table.insert(tbSprites, spriteAlpha)
			node:addChild(spriteAlpha)
			node:setLocalZOrder(nZOrder + 1)
	
			table.insert(tbNodes, node);
		end
	end
	if #tbNodes <= 0 then
		return false;
	end
	
	local pnlShip = self:GetShipPanel(nCamp)
	pnlShip:addChild(sprite)
	
	--开始随机之后删除全部都亮的精灵
	local callAlphaRemove = function()
		sprite:setVisible(true)
		for k, v in pairs(tbSprites) do
			v:removeFromParent(true)
		end

	end
	
	--随机完之后删除
	local call = function()
		-- print("[延时]随机特效播放完毕 ..........................")
		sprite:removeFromParent(true);
		fnCall();
	end
	
	--随机完之后，在随机到的英雄身上加亮光，持续一段时间
	local callAlphaFind = function()
		for k, v in pairs(tbNodes) do
			v:setLocalZOrder(0)
		end
		
		local posTarX, posTarY = target:getPosition();
		local sizeTar = target:getContentSize();
		fnSetScale(target, sprite)
		sprite:setPosition(posTarX + sizeTar.width/2, posTarY + sizeTar.height/2)
		local nSrc, nDst = unpack(tbConfig.tbEndAlpha)
		sprite:setBlendFunc(nSrc, nDst)
		target:setLocalZOrder(nZOrder + 1)
	end

	local action = cc.EaseExponentialOut:create(cc.PlaceByPoint:create(tbConfig.nDuration, tbNodes, nPos-3, tbConfig.nPeroid))
	sprite:runAction(cc.Sequence:create(cc.DelayTime:create(tbConfig.nDelayTimeStart), 
		cc.CallFunc:create(callAlphaRemove),
		action, 
		cc.CallFunc:create(callAlphaFind),
		cc.DelayTime:create(tbConfig.nDelayTimeEnd),
		cc.CallFunc:create(call)))
end

--@function:
--@src: 上一个技能的相关信息
function KG_UIFight:PlayEffect(nID, tbArg, fnCallBack)
	local nLayerID = self:GetLayerID();			-- for 特效
	
	if nID == 1 then			--连携
		local nCamp, nPos, src = unpack(tbArg);
		if not nCamp or not nPos then
			return;
		end
		local fnCombo = function() 
			local pnlCombo = ccui.Helper:seekWidgetByName(self.m_Layout, "pnl_combo")
			pnlCombo:setVisible(true);
			pnlCombo:setLocalZOrder(l_tbLocalZOrder.PNL_SHIP_NPC)	--在遮罩上面
			
			-- 眼睛资源换掉
			local imgDstEye = pnlCombo:getChildByName("img_selfeye");
			local imgSrcEye = pnlCombo:getChildByName("img_comboeye");
			local heroSrc = nil;
			if src then
				local nCampSrc = src:GetFightShip():GetCamp();
				local nPosSrc = src:GetPos();
				heroSrc = self:GetHeroByPos(nCampSrc, nPosSrc);
			end
			local heroDst = self:GetHeroByPos(nCamp, nPos);
			if heroSrc then
				local _, _, sz3 = heroSrc:GetHeroObj():GetHeadIcon();
				imgSrcEye:loadTexture(sz3);
			end
			if heroDst then
				local _, _, sz3 = heroDst:GetHeroObj():GetHeadIcon();
				imgDstEye:loadTexture(sz3);
			end
			
			local fnCall = function()
				pnlCombo:setVisible(false)
				pnlCombo:setLocalZOrder(l_tbLocalZOrder.DEFAULT)
				
				fnCallBack();
				
				local node = self:GetStillNode(nCamp, nPos);
				af_BindEffect2Node(node, 60005, {nil, 1}, 1, nil, {nil, nil, nLayerID});
			end
			ccs.ActionManagerEx:getInstance():playActionByName("fight.json", "combo_eyes", cc.CallFunc:create(fnCall))
			--连携特效
			local node = self:GetStillNode(nCamp, nPos);
			local effect = af_BindEffect2Node(self.m_Layout, 60004, {nil, 100}, 1, nil, {nil, nil, nLayerID})
			local tbPos = l_tbEffectDecoration[1000].position
			effect:setPosition(cc.p(unpack(tbPos)))
		end
		
		--连携触发英雄
		-- local _, _, _, sz4, szCharacter = npc:GetHeroObj():GetHeadIcon();
		local nodeSrc = nil;
		if src then
			local nCamp = src:GetFightShip():GetCamp();
			local nPos = src:GetPos();
			nodeSrc = self:GetStillNode(nCamp, nPos);
		end
		if nodeSrc then
			af_BindEffect2Node(nodeSrc, 60005, {nil, 1}, 1, nil, {nil, nil, nLayerID})
			fnCombo();
		else
			fnCombo();
		end
	elseif nID == 2 then		-- 合作技能
		local tbRes = tbArg;
		local imgHero1 = self.m_pnlCombo:getChildByName("img_unite01");
		local imgHero2 = self.m_pnlCombo:getChildByName("img_unite02");
		-- imgHero1:setOpacity(255);
		-- imgHero2:setOpacity(255);
		imgHero1:loadTexture(tbRes[1]);
		imgHero2:loadTexture(tbRes[2]);
		self.m_pnlCombo:setVisible(true);
		self.m_pnlCombo:setLocalZOrder(1);
		local fnCall = function()
			self.m_pnlCombo:setVisible(false);
		end
		ccs.ActionManagerEx:getInstance():playActionByName("fight.json", "untest", cc.CallFunc:create(fnCall))
	else
		if fnCallBack then
			fnCallBack()
		end
	end
end

--@function: 生物进入队列的动作表现
function KG_UIFight:PlayContractEnter(hero, fnCallBack)
	local nCamp = hero:GetFightShip():GetCamp();
	local nPos = hero:GetPos();
	local pnlHero = self:GetNode(nCamp, nPos)
	local heroSize = pnlHero:getContentSize();
	local pnlShip = self:GetShipPanel(nCamp)
	
	if pnlHero then
		--因为层级关系, 特效都往panel ship上放
		local armature = self:CreateHero(hero, pnlShip);
		local pos = pnlHero:convertToWorldSpace(cc.p(heroSize.width/2, 0))
		armature:setPosition(pnlShip:convertToNodeSpace(pos))
		
		armature:setLocalZOrder(l_tbLocalZOrder.ARMATURE_COMBO)	
		local szAnimation = "combo"
		local function fnSpineAnimationEvent(event)
			if event.animation == szAnimation then
				-- armature:unregisterSpineEventHandler(sp.EventType.ANIMATION_COMPLETE)
				-- armature:removeFromParent(true)
				-- page@2015/07/06 切记spine的回调函数中不能删除spine节点对象
				armature:runAction(cc.RemoveSelf:create())
			end
		end
		
		print("[registerSpineEventHandler] fightview 2", szAnimation)
		armature:registerSpineEventHandler(fnSpineAnimationEvent, sp.EventType.ANIMATION_COMPLETE)

		armature:setAnimation(0, szAnimation, false)
	end
end

--@function: 只战斗一次
function KG_UIFight:FightOneTime(nSeed, nHeronBoxID, nBoxID, nWinner, nRewardID, bFlag)
	print("/************************************************/")
	print("/*******************FightOneTime*****************/")
	print("/************************************************/")
	self.m_bOneTime = true;
	if nHeronBoxID == 1 then
	elseif nHeronBoxID == 2 then
		self:StartSearch();
	elseif nHeronBoxID == 3 then
		self:StartSearch();
	end
	self.m_nHeroBoxID = nHeronBoxID;
	
	self:StartFight(nSeed, nBoxID, nWinner, nRewardID, bFlag);
end

--@function: 搜索和战斗
--@bFlag: 是否搜索: false-搜索(默认); true-不搜索
function KG_UIFight:SearchAndFight(nSeed, nBoxID, nWinner, nRewardID, bFlag)
	self.m_nHeroBoxID = nil;
	self:RandomBgImage(nBoxID);
	
	self:StartSearch();
	self:StartFight(nSeed, nBoxID, nWinner, nRewardID, bFlag);
end

--@function: 搜索
function KG_UIFight:StartSearch()
	print("[Log]==========================开始搜索===========================")
	self.m_pnlSearch:setVisible(true);
end

--@function: 战斗前处理
function KG_UIFight:BeforeStartFight(bFlag)
	if bFlag then
		local pnlReward = self:getChildByName("pnl_reward")
		if pnlReward then
			pnlReward:closeLayer();
		end
	end
	self.m_bCustomFight = bFlag or false;
	
	self:ProcessButtonState();
end

--@function: 逻辑上开始战斗计算
function KG_UIFight:StartFight(nSeed, nBoxID, nWinner, nRewardID, bFlag)
	self:BeforeStartFight(bFlag);
	--test 
	print("@StartFight...............")
	print("[StartFight]随机种子：", nSeed)
	print("[StartFight]怪物盒子：", nBoxID)
	--test end
	-- nSeed = 39329343
	-- nBoxID = 10409;
	-- nSeed = 1448958276
	-- nBoxID = 102002;

	gf_SetRandomSeed(nSeed)
	--测试阶段：重现bug
	if DEBUG_VERSION_PC then
		local f = io.open("seed.txt", "a+")
		f:write("seed:" .. nSeed .. ", " .. nBoxID .. "\n")
		f:close();
	else
		cc.UserDefault:getInstance():setIntegerForKey("seed",nSeed)
		cc.UserDefault:getInstance():setIntegerForKey("boxid",nBoxID)
	end
	-- 记录随机种子和服务器调试保持一致or查错用
	if DEBUG_SEED then
		local szLog = "seed:" .. nSeed .. ", " .. nBoxID .. "\n";
		tst_write_file("tst_seed.txt", szLog);
	end
	--测试阶段：重现bug
	
	-- 准备战斗数据
	-- if not self.m_bOneTime then
	local enemy = g_PlayerFactory:CreateMonsterBox(nBoxID)
	local tbData = {
		{l_tbCamp.ENEMY, enemy},
	};
	self:UpdateData(tbData);
	-- end
	self.m_nRewardID = nRewardID;

	--每一场战斗都有一个全局UI条件触发器(和逻辑上的全局条件触发器一样)
	g_UICondTrigger = KGC_SUB_CONDITION_BASE_TYPE.new()
	self.m_FightHall = KGC_FightHall:getInstance()
	
	local nWin = 0;
	local fnFight = function()
		print("fight ... ");
		if self.m_bOneTime then
			nWin = self.m_FightHall:FightWithConfig(nSeed, nil, self.m_nHeroBoxID);
		else
			nWin = self.m_FightHall:Fight(nSeed);
		end
		if bFlag then
			KGC_PROGRESS_VIEW_LOGIC_TYPE:getInstance():OnCallBack();
		end
		if not nWinner then
			nWinner = nWin;
		end
		FightViewLogic:getInstance():SetWinner(nWinner)
	
		-- 搜索之后播放
		local fnCall = function()
			self:UpdateView({l_tbCamp.ENEMY});
			self:StartAnimation();
		end
		
		-- 播放战斗动画先播放对话
		local fnDialog = function()
			self.m_pnlSearch:setVisible(false);
			-- self:UpdateDialog(fnCall);
			--page@2015/10/24 策划不需要这种对话
			fnCall();
		end
		
		-- 搜索时间
		local nID = me:GetCurrentAfkPoint();
		local tbAfkConfig = l_tbAfkConfig[nID] or {};
		local nTime = (tbAfkConfig.searchtime or 3000)/1000;	-- 配置表是毫秒
		if bFlag then
			nTime = 0;
		end
		-- 指引
		if self.m_bOneTime then
			local tbConfig = l_tbHeroBox[self.m_nHeroBoxID];
			-- nTime = (tbConfig.delaytime or 0)/1000;
		end
		print("search time: ", nTime);

		local action = cc.Sequence:create(cc.DelayTime:create(nTime), cc.CallFunc:create(fnDialog));
		self:runAction(action);
	end
	
	-- 计算也是延后0.5秒, 进度条显示： 下一帧开始处理
	local ac = cc.Sequence:create(cc.DelayTime:create(0), cc.CallFunc:create(fnFight));
	self:runAction(ac);
end

function KG_UIFight:ClearAllHero()
	print("清空hero数据.................", self.m_tbHeros);
	for camp, tbHeros in pairs(self.m_tbHeros) do
		for pos, hero in pairs(tbHeros) do
			self:RemoveHero(camp, pos);
		end
	end
	
	-- 清空英雄数据
	self.m_tbHeros = {};
	self.m_tbHeros[l_tbCamp.MINE] = {}
	self.m_tbHeros[l_tbCamp.ENEMY] = {}
end

function KG_UIFight:StartSpeed()
	TipsViewLogic:getInstance():addMessageTips(30000);
end

function KG_UIFight:OpenChat()
	GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_CHAT);
end

function KG_UIFight:OpenAfkPoint()
	TipsViewLogic:getInstance():addMessageTips(30000);
end

--@function: 英雄升级
function KG_UIFight:UpdateLevel(nPos)
	local nCamp = l_tbCamp.MINE;		-- 升级玩家角色
	local node = self:GetNode(nCamp, nPos)
	local tbEffectConfig = af_GetEffectModifyInfo(1001) or {};
	if node and tbEffectConfig then
		local nEffectID, tbPos, nScale = unpack(tbEffectConfig);
		local nLayerID = self:GetLayerID();		-- for 特效
		af_BindEffect2Node(node, nEffectID, {{0.5, 0}}, nScale, nil, {nil, 0, nLayerID})
	end
end

function KG_UIFight:GetEffectPanel()
	return self.m_pnlEffect;
end

function KG_UIFight:GetEffectShipPanel(nCamp)
	print("[Log]GetEffectShipPanel", nCamp);
	if self:IsValidCamp(nCamp) then
		local panel = self:GetEffectPanel()
		if panel then
			local szName = "pnl_ship_effect_" .. nCamp;
			local pnlShip = panel:getChildByName(szName)
			return pnlShip
		end
	end
end

--@function: 设置战斗界面中离开事件是否启用
function KG_UIFight:SetLeaveTouchEnabled(bEnable)
	print("[log]设置退出战斗界面按钮是否可用", bEnable);
	local bEnable = bEnable or false;
	local pnlFightText = self.m_Layout:getChildByName("pnl_fight_text")
	
	-- 首页
	local btn2Main = self.m_layerDown:getChildByName("btn_main")
	btn2Main:setEnabled(bEnable);
	-- 探索地图
	local btnMap = pnlFightText:getChildByName("btn_map")
	btnMap:setEnabled(bEnable);
end

--@function: 子layer关闭回调
function KG_UIFight:OnCloseSubLayer()
	print("OnCloseSubLayer ... ")
end

--@function: 随机战斗背景图
function KG_UIFight:RandomBgImage(nBoxID)
	local tbPics = KGC_PLAYER_FACTORY_TYPE:getInstance():GetFightBg(nBoxID);
	--Notify: 注意使用gf_Random会影响整个战斗过程中的种子，故不用
	if not tbPics then
		return;
	end
	local nRandom = math.random(#tbPics);
	local nPicID = tbPics[nRandom] or 102;
	local szImage1, szImage2, szImage3 = l_tbBgImageConfig[nPicID].Pic1, l_tbBgImageConfig[nPicID].Pic2, l_tbBgImageConfig[nPicID].Pic3
	print("[log]随机战斗背景", nPicID);
	local pnlBg = self.m_Layout:getChildByName("pnl_bg");
	local img1 = pnlBg:getChildByName("img_1");
	img1:loadTexture(szImage1);
	local img2 = pnlBg:getChildByName("img_2");
	img2:loadTexture(szImage2);
	local img3 = pnlBg:getChildByName("img_3");
	img3:loadTexture(szImage3);
end

--@function: 处理战斗界面功能按钮状态
function KG_UIFight:ProcessButtonState()
	print("ProcessButtonState ... ", self.m_bCustomFight);
	local pnlRewardMore = self.m_Layout:getChildByName("pnl_reward_more");
	if self.m_bCustomFight then
		self:SetLeaveTouchEnabled(not self.m_bCustomFight);
		pnlRewardMore:setVisible(false);
		return;
	end
	
	if self.m_bOneTime then
		self:SetLeaveTouchEnabled(not self.m_bOneTime);
		pnlRewardMore:setVisible(false);
		return;
	end
	
	self:SetLeaveTouchEnabled(true);
	-- pnlRewardMore:setVisible(true);
	-- 等级控制
	if SystemOpen:getInstance():getSystemIsOpen(SystemOpen.SYS_MAIN) then
		self:SetLeaveTouchEnabled(true);
	else
		self:SetLeaveTouchEnabled(false);
	end
end

--@function: 获取进度奖励
function KG_UIFight:GetRewardMore()
	FightViewLogic:getInstance():ReqGetRewardMore();
	
	local pnlRewardMore = self.m_Layout:getChildByName("pnl_reward_more");
	local nLayerID = self:GetLayerID();		-- for 特效
	af_BindEffect2Node(pnlRewardMore, 60068, nil, 1, nil, {nil, 0, nLayerID}); -- 60068
	if self.m_actionRewardMore then
		self.m_actionRewardMore:stop();
	end
	
	if self.m_effectRewardMore then
		self.m_effectRewardMore:removeFromParent(true);
		self.m_effectRewardMore = nil;
	end
	
end

--@function: 更新进度奖励
function KG_UIFight:UpdateRewardMore(nCount, nStep)
	local nCount = nCount or 0;
	local nStep = nStep or 1;
	local pnlRewardMore = self.m_Layout:getChildByName("pnl_reward_more");
	local pnlMonsterInfo = pnlRewardMore:getChildByName("pnl_monster_info");
	local lblNum = pnlMonsterInfo:getChildByName("lbl_reward");
	
	if self.m_bOneTime or self.m_bCustomFight then
		pnlRewardMore:setVisible(false);
		return;
	end
	
	local nAfkerPoint = me:GetCurrentAfkPoint();
	local tbConfig = (l_tbAfkConfig[nAfkerPoint] or {}).Score or {};
	local nNeedMonster = tbConfig[nStep] or 0;
	if not tbConfig[nStep] then
		cclog("[Log]阶段奖励已经取完了，不再显示!");
		pnlRewardMore:setVisible(false);
		return;
	end
	pnlRewardMore:setVisible(true);
	
	local nLeft = (nNeedMonster - nCount) > 0 and (nNeedMonster - nCount) or 0;
	print("UpdateRewardMore", l_tbAfkConfig[nAfkerPoint], nAfkerPoint, nCount, nStep, nNeedMonster, nLeft);
	lblNum:setString(nLeft);
	if nLeft <= 0 then
		-- pnlRewardMore:setTouchEnabled(true);
		self.m_canGetReward = true
		pnlMonsterInfo:setVisible(false);
		self.m_actionRewardMore = ccs.ActionManagerEx:getInstance():playActionByName("fight.json", "rewardcage");
		-- 最后一个参数保证循环播放
		if not self.m_effectRewardMore then
			local nLayerID = self:GetLayerID();		-- for 特效
			self.m_effectRewardMore = af_BindEffect2Node(pnlRewardMore, 60067, {nil, -1}, 1, nil, {nil, 1, nLayerID});
		end
	else
		-- pnlRewardMore:setTouchEnabled(false);
		self.m_canGetReward = false
		pnlMonsterInfo:setVisible(true);
		
		if self.m_actionRewardMore then
			self.m_actionRewardMore:stop();
		end
		
		if self.m_effectRewardMore then
			self.m_effectRewardMore:removeFromParent(true);
			self.m_effectRewardMore = nil;
		end
	end
end

function KG_UIFight:OnExit()
	print("KG_UIFight OnExit ... ")
	-- ccs.ActionManagerEx:destroyInstance();
	
	local scheduler = cc.Director:getInstance():getScheduler()
	if g_shedule_particle_contract then
		scheduler:unscheduleScriptEntry(g_shedule_particle_contract)
	end

	-- for camp, tbHeros in pairs(self.m_tbHeros) do
		-- for pos, hero in pairs(tbHeros) do
			-- hero:UnInit();
		-- end
	-- end
	self:ClearAllHero();
	
	--恢复初始速度
	cc.Director:getInstance():getScheduler():setTimeScale(1)
	self.m_nCurrentSpeed = 1;
end
------------------------------------------------------------------
function KG_UIFight:TextPrintHero()
	for camp, tbHeros in pairs(self.m_tbHeros) do
		print("阵营", camp, #tbHeros)
		for pos, hero in pairs(tbHeros) do
			print("\t位置: ", pos, hero:GetName())
		end
	end
end

function KG_UIFight:TestEffect()
	local pnlTest = self.m_Layout:getChildByName("pnl_test")
	pnlTest:setVisible(true);
	local btnEffect = pnlTest:getChildByName("btn_effect")
	local lvEffect = pnlTest:getChildByName("lv_effect")
	-- 回到首页
	local btnMain = pnlTest:getChildByName("btn_test_main")
	local fnClose = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			self:runAction(cc.RemoveSelf:create())
		end
	end
	btnMain:addTouchEventListener(fnClose);
	
	-- 打印内存
	local btnPrint = pnlTest:getChildByName("btn_test_print");
	local fnPrint = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			tst_print_textures_cache();
			cc.SpriteFrameCache:getInstance():removeSpriteFrames();
		end
	end
	btnPrint:addTouchEventListener(fnPrint);
	
	local tbArmatures = require("script/cfg/client/effect")
	lvEffect:removeAllItems();
	local fnTouch = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			if self.m_testCurEffect then
				self.m_testCurEffect:removeFromParent(true);
			end
			local node = self:GetNode(1, 2);
			local nID = sender.__effectid;
			local nLayerID = self:GetLayerID();		-- for 特效
			local effect = af_BindEffect2Node(node, nID, nil, nil, nil, {nil, 1, nLayerID});
			self.m_testCurEffect = effect;
			if effect then
				local sizeNode = node:getContentSize();
				local sizeEffect = effect:getContentSize();
				local nScale = sizeNode.width/sizeEffect.width;
				local nEffectScaleH = sizeNode.height/sizeEffect.height;
				if nScale < nEffectScaleH then
					nScale = nEffectScaleH;
				end
				if nEffScale then
					print("受击特效比例", nEffScale, nScale, nEffScale * nScale)
					effect:setScale(nEffScale * nScale)
				end
			end
		end
	end
	
	-- 按照ID排序
	local tbHashIDs = {}
	for nID, tbData in pairs(tbArmatures) do
		table.insert(tbHashIDs, nID);
	end
	local fnCompare = function(a, b)
		return a.effectid > b.effectid;
	end
	table.sort(tbHashIDs)
	
	-- 设置特效长度
	local btnSize = btnEffect:getContentSize();
	local nWidth = btnSize.width + 1;
	local nTotal = #(tbHashIDs or {});
	local size = lvEffect:getInnerContainerSize();
	lvEffect:setInnerContainerSize(cc.size(nTotal * nWidth, size.height));
	for _, nID in ipairs(tbHashIDs) do
		local tbModel = tbArmatures[nID]
		local item = btnEffect:clone();
		item.__effectid = nID;
		item:setVisible(true);
		item:setTitleText(nID);
		lvEffect:pushBackCustomItem(item);
		item:addTouchEventListener(fnTouch);
	end
end

function KG_UIFight:TestModel()
	local pnlTest = self.m_Layout:getChildByName("pnl_test")
	pnlTest:setVisible(true);
	local btnModel = pnlTest:getChildByName("btn_effect")
	local lvModel = pnlTest:getChildByName("lv_model")
	
	local tbArmatures = require("script/cfg/client/model")
	lvModel:removeAllItems();
	local fnTouch = function(sender, eventType)
		if eventType == ccui.TouchEventType.ended then
			local node = self:GetNode(1, 5);
			local nID = sender.__modelid;
			--UpdateHero
			local tbShips = self.m_FightHall:GetShips();
			local hero = tbShips[1]:GetHeroByPos(5);
			hero:GetHeroObj():SetModelID(nID);
			self:UpdateHero(hero)
		end
	end
	
	-- 按照ID排序
	local tbHashIDs = {}
	for nID, tbData in pairs(tbArmatures) do
		table.insert(tbHashIDs, nID);
	end
	local fnCompare = function(a, b)
		return a.modelid > b.modelid;
	end
	table.sort(tbHashIDs)
	for _, nID in ipairs(tbHashIDs) do
		local tbModel = tbArmatures[nID]
		local item = btnModel:clone();
		item.__modelid = nID;
		item:setVisible(true);
		item:setTitleText(nID);
		lvModel:pushBackCustomItem(item);
		item:addTouchEventListener(fnTouch);
	end
end

function KG_UIFight:TestTouchHero()
	local tbAnimations = KGC_MODEL_MANAGER_TYPE:getInstance():GetAnimation();
	local szAnimation = tbAnimations[math.random(#tbAnimations)]
	
	local arm = self:GetArmature(1, 5)
	if arm then
		if arm._is_using then
			return;
		end
		
		-- 标记正在动作
		arm._is_using = true
		
		arm:registerSpineEventHandler(function (event)
			if event.animation == szAnimation then
				arm:setAnimation(0, "standby", true);
				arm._is_using = nil;
			end
		end, sp.EventType.ANIMATION_COMPLETE)
  
		arm:setAnimation(0, szAnimation, false)
	end
end
