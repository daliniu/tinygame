----------------------------------------------------------
-- file:	fightlogic.lua
-- Author:	page
-- Time:	2015/01/26
-- Desc:	
----------------------------------------------------------
require("script/ui/fightview/fightview")
require("script/ui/fightview/resultlayer")
require("script/class/class_base_ui/class_base_logic")

local l_tbUIUpdateType = def_GetUIUpdateTypeData();
local l_tbHeroBox = require("script/cfg/client/herobox");

local TB_STRUCT_FIGHT_VIEW_LOGIC = {
	m_pLogic = nil,
	m_pLayer = nil,

	m_nCurStage = 0,				-- 当前战斗阶段(指引用)
}

FightViewLogic = class("FightViewLogic", KGC_UI_BASE_LOGIC, TB_STRUCT_FIGHT_VIEW_LOGIC)

function FightViewLogic:getInstance()
	if FightViewLogic.m_pLogic==nil then
        FightViewLogic.m_pLogic=FightViewLogic:create()
		GameSceneManager:getInstance():insertLogic(FightViewLogic.m_pLogic)
	end
	return FightViewLogic.m_pLogic
end

function FightViewLogic:create()
    local _logic = FightViewLogic:new()
    return _logic
end

function FightViewLogic:initLayer(parent,id, tbArg)
	local tbArg = tbArg or {};
	local bGuide, nHeroBoxID = tbArg[1], tbArg[2];
	if bGuide then
	-----------------------------------------------------
		-- 指引用
		-- 初始化新的战斗界面
		if not self.m_pLayer then
			self.m_pLayer = KG_UIFight.new({bDebug = true});
			self.m_pLayer.id = id
			parent:addChild(self.m_pLayer);
		end
		self:OpenGuideFight(nHeroBoxID);
	else
	-----------------------------------------------------
		-- 挂机用
		if self.m_pLayer ~= nil then
			GameSceneManager:getInstance():ShowLayer(id) 
			self.m_pLayer:RefreshText();
			return
		end
		GameSceneManager:getInstance():ShowLayer(id) 
		
		self.m_pLayer = KG_UIFight.new()
		self.m_pLayer:Init(self.m_EnemyData, self.m_nRewardID)
		self.m_pLayer.id = id

		print("战斗结果：", nWinner, self.m_nWinner)
		if true or nWinner == self.m_nWinner then				--测试：直接通过
			--直接给奖励
			parent:addChild(self.m_pLayer)
		else
			print("战斗结果数据错误!")
			--通知界面
		end
	end
end

--@function: 关闭战斗界面
--@bGuide: 是否是指引战斗
function FightViewLogic:closeLayer(bGuide)
	-- 指引战斗直接关闭
	if bGuide then
		if self.m_pLayer then
			GameSceneManager:getInstance():removeLayer(self.m_pLayer.id);
			self.m_pLayer = nil;
		end
		
	-- 挂机界面一直存在
	else
		if self.m_pLayer then
			GameSceneManager:getInstance():HideLayer(self.m_pLayer.id)
		end
	end
end

--@function: 更新界面
--@iType: 类型, 参考
function FightViewLogic:OnUpdateLayer(iType, tbArg)
	-- print("[界面更新]OnUpdateLayer", self.m_pLayer, iType, tbArg)
	local tbArg = tbArg or {}
	local nPos = tbArg[1] or 0;
	if self.m_pLayer then
		if iType == l_tbUIUpdateType.EU_LEVELUP then
			TipsViewLogic:getInstance():addMessageTips(12000);
			self.m_pLayer:UpdateLevel(nPos)		
		end
		self.m_pLayer:UpdateMoneyData()
		if self.m_pLayer.m_btnLayer then
			self.m_pLayer.m_btnLayer:initButtonState()
		end
	end
end

function FightViewLogic:SetPlayerInfoVisible(bVisble)
	if self.m_pLayer then
		self.m_pLayer:SetPlayerInfoVisible(bVisble)
	end
end

function FightViewLogic:SetEnemy(data)
	self.m_tbEnemy = data;
end

function FightViewLogic:GetEnemy()
	return self.m_tbEnemy;
end

function FightViewLogic:SetWinner(nWinner)
	self.m_nWinner = nWinner;
end

--@function: 强制结束当前战斗重新开始一场
function FightViewLogic:ForceOver()
	if self.m_pLayer then
		self.m_pLayer:Over(true);
		local nBoxID = me:RandomMonsterBoxID();
		self.m_pLayer:SearchAndFight(os.time(), nBoxID);
	end
end

--@再封装一层的直接战斗接口
--@nSeed: 随机种子(eg: os.time())
--@nBoxID: 怪物盒子的ID
--@nWinner: 服务器传过来的战斗结果
--@tbReward: 奖励相关数据
--[[
	rewardid =,		-- 奖励ID获取数值类奖励
	cost =,			-- 补给消耗
	bagAdd = ,		-- 道具列表(服务端要随机生成)
]]
function FightViewLogic:StartFightWithMonster(nSeed, nBoxID, nWinner, tbReward)
	print("[Log]StartFightWithMonster ... ", nSeed, nBoxID, nWinner, tbReward)
	tst_print_lua_table(tbReward or {});
	local nRewardID = tbReward.rewardid;
	local nAPCost = tbReward.cost;
	local tbItems = tbReward.bagAdd;
	-- local tbItems = tbData and tbData.itemList;
	local enemyData = g_PlayerFactory:CreateMonsterBox(nBoxID)
	
	self.m_nSeed = nSeed;				-- 随机种子
	self.m_EnemyData = enemyData;		-- 
	self.m_nWinner = nWinner;
	self.m_tbReward = {nRewardID, nAPCost, tbItems}

	GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_PROGRESS);
	local fnCall = function()
	-- 开一场新的
		GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_FIGHT);
		if self.m_pLayer then
			self.m_pLayer:RefreshText();
			self.m_pLayer:Over(true);
			self.m_pLayer:SearchAndFight(nSeed, nBoxID, nWinner, nRewardID, true)
		end
	end
	local action = cc.Sequence:create(cc.DelayTime:create(0.5), cc.CallFunc:create(fnCall));
	GameSceneManager:getInstance().pLayer:runAction(action)
	
	return true;
end

function FightViewLogic:OnFightCallBack()
	local nWinner = self.m_nWinner;
	local nRewardID, nAPCost, tbItems = unpack(self.m_tbReward or {})
	local nGold, nExp, nExpTeam, nAP, nSign, tbItemAdd
	print("FightViewLogic:OnFightCallBack ... ", nWinner, nRewardID, nAPCost, tbItemAdd)

	if nWinner and nWinner > 0 and nRewardID and nRewardID > 0 then
		nGold, nExp, nExpTeam, nAP, nSign = KGC_REWARD_MANAGER_TYPE:getInstance():GetReward(nRewardID)
		if not nGold then
			cclog("[Error]获取奖励为空，检测配置表@OnFightCallBack");
			return false;
		end
		
		--战斗胜利才会给奖励
		if nWinner == 1 then
			tbItemAdd = KGC_REWARD_MANAGER_TYPE:getInstance():AddReward(nGold, nExp, nAP, tbItems)
		end
		print("OnFightCallBack", nGold, nExp, tbItemAdd);
		local tbItemObjs = {}
		for _, tbData in pairs(tbItemAdd or {}) do
			local nID, nNum = unpack(tbData);
			local item = me:GetBag():GetItemByID(nID);
			table.insert(tbItemObjs, item);
		end
		self:InsertFightText(nWinner, nGold, nExp, tbItemObjs);
		
		self.m_nWinner = 0;
		self.m_tbReward = {};
	end
	
	-- 显示奖励界面
	if self.m_pLayer then
		local layer = KGC_UI_FIGHT_RESULT_LAYER_TYPE:create(self.m_pLayer);
		-- 每次打开需要用这个名字查找之前的panel, 用于关闭
		layer:setName("pnl_reward")
		layer:UpdateData(nWinner, nAPCost, nSign, {nGold, nExp, nAP, tbItemObjs});
	end
end

--@function: 请求离线奖励
function FightViewLogic:ReqFightRewardOffLine()
	local fnCallBack = function(tbArg)
		local tbItems = tbArg.bagitem;
		local tbPlayer = tbArg.playerInfo;
		
		local nRet = tbArg.retCode;	-- 返回结果
		local nTime = tbArg.offTime;
		local nGoldAdd = tbArg.gold;
		local nExpAdd = tbArg.exp;
		local nAp = tbArg.action;
		local szLog = "[离线奖励接受]"
		szLog = szLog .. ", msg = {addgold = " .. tostring(nGoldAdd) .. ", addexp = " .. tostring(nExpAdd) .. ", 行动力 = " .. tostring(nAp) .. "}"
		KGC_AFK_STATISTICS_LOGIC_TYPE:getInstance():OnRspAfkStatistics(nGoldAdd, nExpAdd, nAP, nTime, tbPlayer, tbItems)
		cclog("[离线奖励接受]", szLog)
	end
	print("[离线奖励请求]");
	g_Core.communicator.loc.offlineProfit(fnCallBack);
end

--@function: 发送在线奖励
--@bWin: true-胜; false-败
function FightViewLogic:ReqFightRewardOnLine(bWin, nHeroBoxID)
	local nFPID = 0;
	if nHeroBoxID then
		local tbConfig = l_tbHeroBox[nHeroBoxID] or {};
		nFPID = tbConfig.afkerpoint or 0;
	end
	
	local tbReqArg = {}
	tbReqArg.isWin = 1;
	tbReqArg.pointId = nFPID;
	cclog("[发送协议]在线奖励, isWin(%d), pointId(%s - %s)", 1, tostring(nFPID), tostring(type(nFPID)))
	
	if bWin then
		local fnCallBack = function(tbArg)
			local nGoldAdd = tbArg.gold
			local nExpAdd =  tbArg.exp
			local nAp = tbArg.action
			local tbPlayer = tbArg.playerInfo
			local tbItems = tbArg.bagitem
			cclog("[接收在线奖励] gold = %s, nExp = %s, nAP = %s", tostring(nGoldAdd), tostring(nExpAdd), tostring(nAP));
			self:OnRepFightReward(nGoldAdd, nExpAdd, nAp, tbPlayer, tbItems, 1)
		end
		
		g_Core.communicator.loc.onlineProfit(tbReqArg, fnCallBack);
	else
		self:InsertFightText(2, 0, 0);
	end
end

--@function: 服务器返回奖励回调
function FightViewLogic:OnRepFightReward(nGoldAdd, nExpAdd, nAPAdd, tbPlayer, tbItems, bRewardType)
	local nGold = tbPlayer.gold
		
	me:SetGold(nGold);
	me:OnAddExp(tbPlayer, {}, nExpAdd)
	me:AddAP(nAPAdd);
	
	local tbObjs = {};
	for nIndex, tbData in pairs(tbItems.itemList or {}) do
		local item, num = me:GetBag():AddItem(nIndex, tbData);
		table.insert(tbObjs, {item, num});
	end
	
	for nIndex, tbData in pairs(tbItems.equipList or {}) do
		local item, num = me:GetBag():AddItem(nIndex, tbData);
		table.insert(tbObjs, {item, num});
	end

	local nWinner = 1;
	if bRewardType == 1 then				-- 插入到播报
		self:InsertFightText(nWinner, nGoldAdd, nExpAdd, tbObjs);
	elseif bRewardType == 2 then			-- 弹出通用奖励界面
		-- GameSceneManager:getInstance():addLayer(GameSceneManager.LAYER_ID_REWARD, {2, {nGoldAdd, nAPAdd, tbObjs}});
		KGC_AFK_STATISTICS_LOGIC_TYPE:getInstance():UpdateData(nGoldAdd, nExpAdd, nAPAdd, tbItems, nil)
	end
	
	-- 通知给地图挂机点显示奖励
	local nMapID = me:GetMapID();
	local nFPID = me:GetCurrentAfkPoint();
	local tbReward = {nGoldAdd, nExpAdd, nAPAdd, tbItems};
	MapViewLogic:getInstance():HookFightFinished(nMapID, nFPID, nil, tbReward);
end

--@function: 请求奖励宝箱进度
function FightViewLogic:ReqRewardMoreCount()
	local fnCallBack = function(tbArg)
		local nCount = tbArg.rewardCount;
		local nStep = tbArg.step;
		cclog("[接收协议]返回挂机奖励宝箱进度次数 rewardCount = %s, step = %s", tostring(nCount), tostring(nStep));
		self:OnRspRewardMoreCount(nCount, nStep)
	end
	
	cclog("[发送协议]获取挂机奖励宝箱进度次数");
	g_Core.communicator.loc.getRewardTime(fnCallBack);
end

--@function: 服务器返回奖励宝箱进度
function FightViewLogic:OnRspRewardMoreCount(nCount, nStep)
	if self.m_pLayer then
		self.m_pLayer:UpdateRewardMore(nCount, nStep);
	end
end

--@function: 请求获取奖励宝箱内容
function FightViewLogic:ReqGetRewardMore()
	local fnCallBack = function(tbArg)
		local nGoldAdd = tbArg.gold
		local nExpAdd =  tbArg.exp
		local nAp = tbArg.action
		local tbPlayer = tbArg.playerInfo
		local tbItems = tbArg.bagitem
		local nCount = tbArg.rewardCount
		local nStep = tbArg.step
		cclog("[接收协议]获取挂机奖励宝箱奖励 gold = %s, nExp = %s, nAP = %s, nCount = %s, nStep = %s", tostring(nGoldAdd), tostring(nExpAdd), tostring(nAP), tostring(nCount), tostring(nStep));
		self:OnRepFightReward(nGoldAdd, nExpAdd, nAp, tbPlayer, tbItems, 2)
		self.m_pLayer:UpdateRewardMore(0, nStep);
	end
	
	cclog("[发送协议]获取挂机奖励宝箱奖励");
	g_Core.communicator.loc.getPresent(fnCallBack);
end

function FightViewLogic:InsertFightText(nWinner, nGoldAdd, nExpAdd, tbObjs)
	
	--增加统计数据
	me:AddAfkStatistics(nGoldAdd, nExpAdd, nAPAdd, tbObjs);

	self.m_pLayer:InsertSystemText(1000, {nWinner, nGoldAdd, nExpAdd})
	
	GameSceneManager:getInstance():updateLayer(l_tbUIUpdateType.EU_MONEY);
	
	print("InsertFightText ... ", nWinner);
end

--@function: 设置第机场指引战斗结束
function FightViewLogic:SetFightGuideStage(nStage)
	self.m_nCurStage = nStage;
end

--@function: 指引获取战斗是否结束
function FightViewLogic:GetFightGuideStage()
	return self.m_nCurStage;
end

--@function: 指引战斗
function FightViewLogic:OpenGuideFight(nHeroBoxID)
	local tbConfig = l_tbHeroBox[nHeroBoxID] or {};
	local nAfkerPoint = tbConfig.afkerpoint;
	local nMonsterBoxID = me:RandomMonsterBoxID(nAfkerPoint);
	local nSeed = os.time();
	print("[Log]StartGuideFight ... ", nSeed, nHeroBoxID, nAfkerPoint, nMonsterBoxID)
	
	local data = g_PlayerFactory:TestCreatePlayer(nHeroBoxID)
	self.m_pLayer:Init(data, nil)
	
	local fnCall = function()
		self.m_pLayer:FightOneTime(nSeed, nHeroBoxID, nMonsterBoxID);
	end
	
	self.m_pLayer:runAction(cc.Sequence:create(cc.DelayTime:create(0), cc.CallFunc:create(fnCall)));
end
------------------------------------------------------------------------
-- test
function FightViewLogic:TestStartAFight(parent)
	print("[Log]TestStartAFight ... ", nSeed, nBoxID, nWinner, tbReward)
	
	-- 初始化新的战斗界面
	local layout = KG_UIFight.new({bDebug = true});
	parent:addChild(layout);
	-- layout.m_FightHall = KGC_FightHall:getInstance()
	
	local data1 = g_PlayerFactory:TestCreatePlayer()
	-- local data2 = g_PlayerFactory:CreateMonsterBox(nBoxID)
	layout:Init(data1, data2)
end

--@测试：和服务器验证结果是否正确
function FightViewLogic:TestFightCompareWithServer()
	local nBoxID = 10101;
	local fnCallBack = function(tbArg)
		local nSeed = tbArg.seed;
		gf_SetRandomSeed(nSeed)
		local szLog = string.format("[战斗测试返回]seed(%s)", tostring(nSeed));
		print(szLog);
		for i = 1, 1 do
			-- local nSeed = os.time();
			-- local nBoxID = me:RandomMonsterBoxID();
			local enemy = g_PlayerFactory:CreateMonsterBox(nBoxID)
			local fightHall = KGC_FightHall:getInstance();
			fightHall:Init(me, enemy);
			fightHall:Fight(nSeed);
		end
	end
	
	local tbReqArg = {}
	tbReqArg.monsterid = nBoxID;
	cclog("[战斗测试请求]monsterid(%s)", tostring(tbReqArg.monsterid));
	g_Core.communicator.loc.testfight(tbReqArg, fnCallBack);
end

function FightViewLogic:TestStartFightWithMonster(parent, nBoxID)
	local nSeed = os.time();
	nSeed = 1444895980;
	print("[Log]TestStartFightWithMonster ... ", nSeed, nBoxID)
	
	-- 初始化新的战斗界面
	local layout = KG_UIFight.new({bDebug = true});
	parent:addChild(layout);

	-- local data1 = g_PlayerFactory:TestCreatePlayer()
	local enemy = g_PlayerFactory:CreateMonsterBox(nBoxID)
	layout:Init()
	layout:UpdateData(enemy)
	
	local fnCall = function()
		layout:FightOneTime(nSeed, nBoxID);
	end
	
	layout:runAction(cc.Sequence:create(cc.DelayTime:create(3), cc.CallFunc:create(fnCall)));
	return layout;
end

function FightViewLogic:TestStartFightWithMonsterCustom(parent, nHeroBoxID, nMonsterBoxID)
	local nSeed = os.time();
	nSeed = 1444895980;
	print("[Log]TestStartFightWithMonster ... ", nSeed, nHeroBoxID, nMonsterBoxID)
	
	-- 初始化新的战斗界面
	local layout = KG_UIFight.new({bDebug = true});
	parent:addChild(layout);

	local data = g_PlayerFactory:TestCreatePlayer(nHeroBoxID)
	local enemy = g_PlayerFactory:CreateMonsterBox(nMonsterBoxID)
	layout:Init(data, enemy)
	
	local fnCall = function()
		layout:FightOneTime(nSeed, nHeroBoxID, nMonsterBoxID);
	end
	
	layout:runAction(cc.Sequence:create(cc.DelayTime:create(3), cc.CallFunc:create(fnCall)));
	return layout;
end

function FightViewLogic:TestStartFightWithMonsterCustom2(layout, nHeroBoxID, nMonsterBoxID)
	local nSeed = os.time();
	print("[Log]TestStartFightWithMonsterCustom2 ... ", nSeed, nHeroBoxID, nMonsterBoxID)
	
	-- 初始化新的战斗界面
	if not layout then
		cclog("[Error]前面一场战斗已经关闭~");
		return;
	end
	local data = g_PlayerFactory:TestCreatePlayer(nHeroBoxID)
	local enemy = g_PlayerFactory:CreateMonsterBox(nMonsterBoxID)
	layout:Init(data, enemy)
	
	local fnCall = function()
		layout:FightOneTime(nSeed, nHeroBoxID, nMonsterBoxID);
	end
	
	layout:runAction(cc.Sequence:create(cc.DelayTime:create(0), cc.CallFunc:create(fnCall)));
	return layout;
end