----------------------------------------------------------
-- file:	resultview.lua
-- Author:	page
-- Time:	2015/08/27 14:42
-- Desc:	战斗结果界面
----------------------------------------------------------
require("script/class/class_base_ui/class_base_sub_layer")
local l_tbBattleResult = require("script/cfg/battleresult")
local l_tbSignConfig = require("script/cfg/exploration/common/sign");
local l_tbCamp = def_GetFightCampData();
local l_tbRewardType = {
	-- ET_EXP		= 1,			-- 经验
	ET_GOLD		= 1,			-- 金币
	ET_AP		= 2,			-- 行动力
	-- ET_SIGN		= 4,			-- 标记
}
	
local TB_STRUCT_FIGHT_RESULT_VIEW = {
	m_pLayout = nil,
	m_pnlMain = nil,
	m_svStars = nil,
	m_btnConfirm = nil,					-- 确定退出按钮
	
	-- m_tbActions = {},					-- 界面动画保存
}

KGC_UI_FIGHT_RESULT_LAYER_TYPE = class("KGC_UI_FIGHT_RESULT_LAYER_TYPE", KGC_UI_BASE_SUB_LAYER, TB_STRUCT_FIGHT_RESULT_VIEW)

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:OnExit()
    -- 动画需要stop掉
	-- if self.m_tbActions then
		-- for _, action in pairs(self.m_tbActions) do
			-- if action then
				-- action:stop();
			-- end
		-- end
	-- end
	
	-- self.m_tbActions = {};
end

---初始化
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:initAttr()
	-- if not self.m_tbActions then
		-- self.m_tbActions = {};
	-- end
	
	self:LoadScheme();
end

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:LoadScheme()
	self.m_pLayout = ccs.GUIReader:getInstance():widgetFromJsonFile(CUI_JSON_FIGHT_RESULT_PATH)
	self:addChild(self.m_pLayout)
	
	self.m_pnlMain = self.m_pLayout:getChildByName("pnl_main")
	local fnClose = function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			MapViewLogic:getInstance():openCurrentMap();
			self:closeLayer();
		end
	end
	
	-- 星级
	self.m_svStars = self.m_pnlMain:getChildByName("sv_stars")
	
	-- 奖励
	self.m_pnlReward = self.m_pLayout:getChildByName("pnl_rewards");
	self.m_pnlReward:setVisible(false);
	
	self.m_btnConfirm = self.m_pLayout:getChildByName("btn_confirm");
	self.m_btnConfirm:addTouchEventListener(fnClose);
	self.m_btnConfirm:setTouchEnabled(false);
	
	-- 经验条
	self.m_pnlExp = self.m_pLayout:getChildByName("pnl_exp");
	self.m_pnlExp:setVisible(false);
	
	-- 失败提示面板
	self.m_pnlTip = self.m_pLayout:getChildByName("pnl_tip");
	self.m_pnlTip:setVisible(false);
end

--@function: 更新界面数据
--@nAPCost:  战斗消耗的补给
--@nWinCamp: 1-胜利;2-失败(和阵营对应)
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateData(nWinCamp, nAPCost, nSign, tbReward)
	local nGold, nExp, nAP, tbItems = unpack(tbReward or {});
	nAP = nAP or 0;
	nGold = nGold or 0;
	nExp = nExp or 0;
	tbItems = tbItems or {}
	print("Fight Result UpdateData(Gold, nExp, nAP, nAPCost): ", nGold, nExp, nAP, nAPCost)
	-- 战斗结果：胜利 or 失败
	self:UpdateResult(nAPCost)
	
	-- 数值类奖励(经验、金币、行动力、标记)
	local tbRewardOrder = {}
	if nGold > 0 then
		table.insert(tbRewardOrder, {l_tbRewardType.ET_GOLD, nGold})
	end
	
	if nAP > 0 then
		table.insert(tbRewardOrder, {l_tbRewardType.ET_AP, nGold})
	end
	self:UpdateReward(self.m_pnlReward, tbRewardOrder)
	
	self:UpdateItems(tbItems, nSign);
	
	self:UpdateTeam();
	self:UpdateHeros();
end

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateItems(tbItems, nSign)
	local pnlReward = self.m_pnlReward;

	-- page@2015/10/24 特殊处理洁媛说的补给东东
	for i=1, 1 do
		local szName = "img_item" .. i;
		local imgItem = pnlReward:getChildByName(szName)
		local imgIcon = imgItem:getChildByName("img_icon")
		local bmlNum = imgItem:getChildByName("bml_num")
		local tbConfig = l_tbSignConfig[nSign];
		
		bmlNum:setVisible(false);
		if tbConfig then
			local szName = tbConfig.Name;
			local szPath = tbConfig.Pic;
			imgItem:setVisible(true);
			imgIcon:loadTexture(szPath);
		else
			imgItem:setVisible(false);
		end
	end
	-- 道具显示
	for i = 2, 4 do
		local szName = "img_item" .. i;
		local imgItem = pnlReward:getChildByName(szName)
		local imgIcon = imgItem:getChildByName("img_icon")
		local item = tbItems[i];
		if item then
			imgItem:setVisible(true);
			imgIcon:loadTexture(item:GetIcon())
			local bmlNum = imgItem:getChildByName("bml_num")
			bmlNum:setString(item:GetNum())
			local imgQuality = imgItem:getChildByName("img_quality")
			imgQuality:loadTexture(item:GetQualityIcon())
		else
			imgItem:setVisible(false);
		end
	end
end

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateStars(svStars, nStar)
	print("UpdateStars", nStar);
	if svStars and nStar then
		for i = 1, 5 do
			local szName = "img_star" .. i
			local imgStarEmpty = svStars:getChildByName(szName)
			imgStarEmpty:setVisible(true);
			local imgStarFull = imgStarEmpty:getChildByName("img_star")
			if i <= nStar then
				imgStarFull:setVisible(true);
			else
				imgStarFull:setVisible(false);
			end
		end
	end
end

--@function: 更新奖励界面, 第一部分(经验、金币、行动力、标记)
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateReward(pnlReward, tbReward)
	print("UpdateReward", pnlReward, #tbReward);
	if not pnlReward then
		return;
	end
	
	local tbImages = {
		[l_tbRewardType.ET_GOLD] = "res/ui/05_mainUI/05_ico_main_03.png",
		[l_tbRewardType.ET_AP] = "res/ui/05_mainUI/05_ico_main_01.png",
	}
	
	local tbReward = tbReward or {}
	for i=1, #tbImages do
		local szName = "img_reward_" .. i;
		local imgReward = pnlReward:getChildByName(szName)
		if imgReward then
			local imgIcon = imgReward:getChildByName("img_icon");
			local lblContent = imgReward:getChildByName("lbl_content")
			local tbData = tbReward[i] or {}
			local nType, szContent = unpack(tbData)
			if nType and szContent then
				imgReward:setVisible(true);
				local szImage = tbImages[nType]
				if szImage then
					imgIcon:loadTexture(szImage)
				end
				lblContent:setString(szContent);
			else
				imgReward:setVisible(false);
			end
		end
	end
end

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateResult(nSupplyDec)
	print("UpdateResult", nSupplyDec);
	if not nSupplyDec then
		cclog("[Error]补给错误nSupplyDec:%s", tostring(nSupplyDec))
		self:PlayStarsEffect(0);
		return;
	end
	local nSupplyDec = tonumber(nSupplyDec);
	local nStar, szPath = self:GetResultConfig(nSupplyDec)
	if not nStar or not szPath then
		cclog("[Error]错误的战斗结果配置表, 星级或者路径没有找到")
		return;
	end
	
	-- 胜利不一样，加载不一样的资源
	local imgResult = self.m_pnlMain:getChildByName("img_result")
	imgResult:loadTexture(szPath)
	
	-- 补给
	local lblSupply = self.m_pnlReward:getChildByName("lbl_suppliesnum")
	local szSupply = "-" .. nSupplyDec .. "%"
	lblSupply:setString(szSupply)
	
	-- 星级播放特效
	self:PlayStarsEffect(nStar);
end

--@function: 根据补给值得到是哪一档的奖励
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:GetResultConfig(nSupplyDec)
	for _, tbData in pairs(l_tbBattleResult) do
		if nSupplyDec == tbData.SupplyDeduction then
			local nStar = tbData.StarLevel;
			local szPath = tbData.PicRes;
			return nStar, szPath;
		end
	end
	cclog("[Error]没有找到对应补给的配置表GetResultConfig(%s)", tostring(nSupplyDec))
end

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:PlayStarsEffect(nStar, fnCallBack)
	print("PlayStarsEffect", nStar, fnCallBack);
	local nStar = nStar or 0;
	if nStar > 5 then
		nStar = 5;
	end
	
	-- 动作回调函数
	local fnCall = function()
		if fnCallBack then
			fnCallBack();
		end
		
		self:UpdateStars(self.m_svStars, nStar);
		
		-- 可见
		self.m_btnConfirm:setTouchEnabled(true);
		self.m_pnlReward:setVisible(true);
		
		if nStar > 0 then		-- 胜利
			self.m_pnlExp:setVisible(true);
		else					-- 失败
			self.m_pnlTip:setVisible(true);
		end
	end
	
	local fnPlayStar = function()
		if nStar <= 0 then
			fnCall();
		else
			for i = 1, nStar do
				local szAction = "star" .. i;
				local action = nil;
				if i == 1 then
					-- action = ccs.ActionManagerEx:getInstance():playActionByName("ui_fight_result.json", szAction, cc.CallFunc:create(fnCall))
					self:PlayUIAction("ui_fight_result.json", szAction, cc.CallFunc:create(fnCall));
				else
					-- action = ccs.ActionManagerEx:getInstance():playActionByName("ui_fight_result.json", szAction)
					self:PlayUIAction("ui_fight_result.json", szAction);
				end
				-- 保存动画
				-- table.insert(self.m_tbActions, action);
			end
		end
	end
	
	-- 胜利或者失败的动画
	local szAction = "";
	if nStar > 0 then
		szAction = "win";
	else
		szAction = "lose";
	end

	-- local action = ccs.ActionManagerEx:getInstance():playActionByName("ui_fight_result.json", szAction, cc.CallFunc:create(fnPlayStar))
	self:PlayUIAction("ui_fight_result.json", szAction, cc.CallFunc:create(fnPlayStar));
	
	-- 保存动画
	-- table.insert(self.m_tbActions, action);
end

--@function: 队伍信息
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateTeam()
	print("UpdateTeam");
	-- 团队经验
	local nTeamLevel = me:GetLevel();
	local nExp = me:GetExp()
	local nLevelUpExp = me:GetLevelUpExp();
	local szExp = nExp .. "/" .. nLevelUpExp;
	local nPercent = nExp / nLevelUpExp * 100;
	
	local imgPlayerInfo = self.m_pnlExp:getChildByName("img_playerlevel");
	local bmlLevel = imgPlayerInfo:getChildByName("bmp_playerlevel");
	local barExp = imgPlayerInfo:getChildByName("bar_exp");
	local bmlExp = imgPlayerInfo:getChildByName("bmp_expnum");
	
	bmlLevel:setString(nTeamLevel);
	barExp:setPercent(nPercent);
	bmlExp:setString(szExp);
end

--@function: 英雄信息
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateHeros()
	local tbHeros = me:GetHeros();
	for i = 1, 3 do
		local szName = "pnl_hero_" .. i;
		local pnlHero = self.m_pnlExp:getChildByName(szName);
		if pnlHero then
			local hero = tbHeros[i]
			self:UpdateHero(pnlHero, hero);
		end
	end
end

function KGC_UI_FIGHT_RESULT_LAYER_TYPE:UpdateHero(pnlHero, hero)
	if not pnlHero then
		return;
	end
	
	if not hero then
		pnlHero:setVisible(false);
		return;
	end
	pnlHero:setVisible(true);
	
	local imgHeroBg = pnlHero:getChildByName("img_herobg");				-- 英雄背景
	local imgHero = imgHeroBg:getChildByName("img_hero");				-- 英雄头像
	local imgTypeBg = imgHeroBg:getChildByName("img_herotypebg")		-- 英雄类型底框
	local imgType = imgTypeBg:getChildByName("img_type")				-- 英雄类型
	local lblName = pnlHero:getChildByName("lbl_heroname");				-- 英雄名字
	local imgExpBg = pnlHero:getChildByName("img_expbg");				
	local barExp = imgExpBg:getChildByName("bar_exp");					-- 经验条
	
	local nQuality = hero:GetQuality();
	local szType = hero:GetHeroTypeResource();
	local szIconS, szIconR, szIconP = hero:GetHeadIcon();
	local tbColor, _, szHeroBg, szStarBg, szTypeBg = hero:GetResourceByQuality(nQuality)
	local r, g, b = unpack(tbColor or {255, 255, 255});
	local nExp = hero:GetExp();
	local nLevelUpExp = hero:GetLevelUpExp();
	local nPercent = nExp/nLevelUpExp * 100;
	
	imgHeroBg:loadTexture(szHeroBg);
	imgHero:loadTexture(szIconS);
	imgTypeBg:loadTexture(szTypeBg);
	imgType:loadTexture(szType);
	lblName:setString(hero:GetName());
	lblName:setColor(cc.c3b(r, g, b));
	barExp:setPercent(nPercent);
end
-------------------------------------------------------------
--test

--@function: 随机给一个扣除的补给百分比
function KGC_UI_FIGHT_RESULT_LAYER_TYPE:TestGetSupply()
	local tbSupply = {}
	for _, tbData in pairs(l_tbBattleResult) do
		table.insert(tbSupply, tbData.SupplyDeduction or 0);
	end
	local nRand = math.random(#tbSupply);

	return nRand;
end