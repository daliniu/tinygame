require("script/ui/mapchooseview/mapchooselayer");

local MAP_CHOOSE_LOGIC_TB={
	
}

MapChooseLogic = class("MapChooseLogic", KGC_UI_BASE_LOGIC,MAP_CHOOSE_LOGIC_TB);

function MapChooseLogic:getInstance()
    if MapChooseLogic.m_pLogic == nil then
        MapChooseLogic.m_pLogic = MapChooseLogic:create()
        GameSceneManager:getInstance():insertLogic(MapChooseLogic.m_pLogic)
    end
	
    return MapChooseLogic.m_pLogic
end

function MapChooseLogic:create()
    local _logic = MapChooseLogic.new()
    _logic:Init()
    return _logic
end

function MapChooseLogic:Init()
    
end

function MapChooseLogic:initLayer(parent,id)
    if self.m_pLayer then
    	return
    end

    self.m_pLayer = MapChooseLayer:create();
    self.m_pLayer.id = id;
    self.m_pLayer.flag = true
    parent:addChild(self.m_pLayer)

    -- 设置主界面底部按钮底框可见
    KGC_MainViewLogic:getInstance():ShowMenuBg();
    MapViewLogic:getInstance():ShowMenuBg();
    FightViewLogic:getInstance():SetPlayerInfoVisible(true);
end



function MapChooseLogic:closeLayer()
	if self.m_pLayer then
		local nID = self.m_pLayer.id
		self.m_pLayer:closeLayer();
		self.m_pLayer = nil;
	end

    -- 设置主界面底部按钮底框不可见
    KGC_MainViewLogic:getInstance():HideMenuBg();
    MapViewLogic:getInstance():HideMenuBg();
    FightViewLogic:getInstance():SetPlayerInfoVisible(false);
end

function MapChooseLogic:OnUpdateLayer(iType)
	if self.m_pLayer ==nil then 
		return;
	end

end
