require("script/class/class_base_ui/class_base_layer")
require("script/ui/mainbuttonview/mainbuttonview")

local mapInfoConfigFile = require("script/cfg/exploration/common/mapinfo");

MapChooseLayer = class("MapChooseLayer",function()
	return KGC_UI_BASE_LAYER:create()
end)

function MapChooseLayer:create()
	self = MapChooseLayer.new();
    self:initAttr();
	return self;
end

function OnExit()
	self.ilandItme:release();
end

function MapChooseLayer:ctor()
	
	self.pWidget=ccs.GUIReader:getInstance():widgetFromJsonFile("res/mapChoose.json")
    self:addChild(self.pWidget)

    self.pLogic = MapChooseLogic:getInstance();

    local function fun_close(sender,eventType)
        if eventType==ccui.TouchEventType.ended then
            self.pLogic:closeLayer();
        end
    end

    local btn_close = self.pWidget:getChildByName("btn_close")
    btn_close:addTouchEventListener(fun_close)
    
    --创建主按钮
    self:AddSubLayer(MainButtonLayer:create())

  	self.ilandItme = self.pWidget:getChildByName("panel_item")
  	self.ilandItme:retain();
  	self.ilandItme:removeFromParent();

end


function MapChooseLayer:selfUpdate()
    local function update(dt)
    	for k,v in pairs(self.pMapTb) do
    		local pWorldPos = v:getParent():convertToWorldSpaceAR(cc.p(v:getPosition()));
    		local centerY = 650;
    		local fSpaceY = math.abs(centerY - pWorldPos.y);
    		local scaleValue = -0.0008*fSpaceY+1;
    		v:getChildByName("img"):setScale(scaleValue);
    	end
    end

    self:scheduleUpdateWithPriorityLua(update, 0);
end


function MapChooseLayer:initAttr()
	function fun_opeMap(sender,eventType)
        if eventType==ccui.TouchEventType.ended then
			local id =sender:getTag();
			if MapViewLogic:getInstance().maxMap <id then 
				return;
			end
			self:openMap(id);
            --self:openMap(100)
			self.pLogic:closeLayer();
        end
	end

	function onEnterDate(node,ptable)
		self.pList:jumpToBottom();
	end

    self.pList = self.pWidget:getChildByName("ScrollView_list");

	local iSize = self.pList:getInnerContainerSize();
	local iNUm = 4;
	self.pList:setInnerContainerSize(cc.size(iSize.width,iSize.height*2));    
    for i=1,iNUm do
    	local _item = self.ilandItme:clone();
    	self.pList:addChild(_item);
    	_item:setPositionY((i-1)*200+100);
    	_item:setTag(i);
    	_item:getChildByName("img"):loadTexture(mapInfoConfigFile[i].PicMapItem);
    	_item:getChildByName("img_name"):loadTexture(mapInfoConfigFile[i].PicMapName);
    	local iposx = i%2;
    	_item:setPositionX(iposx*350+70);
        if i == MapViewLogic:getInstance().currentMapID then 
            self:addPlayerHead(_item);
        end
    end


    self.pMapTb = self.pList:getChildren()

	for k,v in pairs(self.pMapTb) do
		if v:getTag()>MapViewLogic:getInstance().maxMap then 
			self:setImagGray(v:getChildren()[1]);
		end
		v:addTouchEventListener(fun_opeMap)
	end


	self:runAction(cc.CallFunc:create(onEnterDate,{}))
	self:selfUpdate();
end


function MapChooseLayer:openMap(id)
	MapViewLogic:getInstance():openMap(id);
end


function MapChooseLayer:setImagGray(pWidget)
   	pWidget:getVirtualRenderer():setGLProgramState(SystemOpen:getInstance().glprogramstate)
end


function MapChooseLayer:addPlayerHead(panel)
    local pNode = cc.Node:create();
    local spBg = cc.Sprite:create("res/ui/16_mapchoose/16_bg_herocover_01.png");
    local spHead = cc.Sprite:create("res/ui/16_mapchoose/16_hero_face_01.png");
    pNode:addChild(spHead);
    pNode:addChild(spBg);
    pNode:setPosition(cc.p(100,200));

    panel:addChild(pNode);
end