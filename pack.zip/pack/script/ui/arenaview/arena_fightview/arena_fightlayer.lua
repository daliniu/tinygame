----------------------------------------------------------
-- file:	arena_fightlayer.lua
-- Author:	page
-- Time:	2015/12/08 17:21
-- Desc:	竞技场敌我对战界面
----------------------------------------------------------
require ("script/ui/resource");
require ("script/ui/arenaview/arena_fightview/rewardsublayer");
----------------------------------------------------------
--data struct
local TB_STRUCT_ARENA_FIGHT_LAYER = {
	-- config
	m_bUpdate = true,				--是否updae
	----------------------------------------------------------
	m_pLayout = nil,					-- json界面
	
	m_pnlPlayerInfoTemplate = nil,		-- listview的模版
	m_tbRewardButton = {},				-- 奖励宝箱按钮
	
	m_tbPlayerData = {},				-- 每一个panel对应的玩家数据对象
	m_bRewardFlag = false,				-- 是否已经弹出奖励界面
	
	m_nCurStage = 0,					-- 当前阶段(筹码赛、八强赛)
	m_nCurStep = 0,						-- 阶段下面的段
}

KGC_ARENA_FIGHT_LAYER_TYPE = class("KGC_ARENA_FIGHT_LAYER_TYPE", KGC_UI_BASE_LAYER, TB_STRUCT_ARENA_FIGHT_LAYER)
--------------------------------
--ui function
--------------------------------

function KGC_ARENA_FIGHT_LAYER_TYPE:Init()
	self.m_pLayout = ccs.GUIReader:getInstance():widgetFromJsonFile(CUI_JSON_PVP_ARENA_FIGHT_PATH);
    self:addChild(self.m_pLayout);
	self.m_nCurStage, self.m_nCurStep = KGC_ARENA_FACTORY_TYPE:getInstance():GetCurrentStage();
	
	self:LoadScheme();
	
	self:UpdateData();
end

--解析界面文件
function KGC_ARENA_FIGHT_LAYER_TYPE:LoadScheme()
	self.m_pnlMain = self.m_pLayout:getChildByName("pnl_main");
	local btnClose = self.m_pLayout:getChildByName("btn_close");
	local fnClose = function(sender,eventType)
		if eventType == ccui.TouchEventType.ended then
			KGC_ARENA_FIGHT_LOGIC_TYPE:getInstance():closeLayer()
        end
	end
	btnClose:addTouchEventListener(fnClose);
	
end

function KGC_ARENA_FIGHT_LAYER_TYPE:Update(dt)
	
	local nStage, nStep = KGC_ARENA_FACTORY_TYPE:getInstance():GetCurrentStage();
	if nStage == 1 then			-- 筹码赛阶段状态判断
		local nTurn, nMaxTurn = KGC_ARENA_FACTORY_TYPE:getInstance():GetArenaDailyTurn();
		-- print("nStep, nTurn, nMaxTurn", nStep, nTurn, nMaxTurn);
		if nStep <= nTurn and nStep > self.m_nCurStep then
			print("跳转到筹码赛下一个阶段：", nStep);
			self.m_nCurStep = nStep;
			self:UpdateDataAtTime();
		elseif nStep == nTurn + 1 then				-- 弹出奖励界面
			if not self.m_bRewardFlag then
				self.m_bRewardFlag = true;
				
				if not true then		-- 是否已经领取奖励
					
				else
					print("打开筹码赛奖励界面：", nStep);
					KGC_UI_ARENA_REWARD_SUBLAYER_TYPE:create(self);
				end
				-- 请求获取八强数据
			end
		end
	elseif nStage == 2 then		-- 八强赛阶段状态判断
		-- 判断是否已经进入八强赛
		if false then
			-- 八强赛只有四轮(加一个等待时间)
			local nTurn = 4;
			if nStep <= nTurn and nStep > self.m_nCurStep then
				print("跳转到八强赛下一个阶段：", nStep);
				self.m_nCurStep = nStep;
				self:UpdateDataAtTime();
			elseif nStep == nTurn + 1 then	-- 弹出奖励界面
				-- if not self.m_bRewardFlag then
					
				-- end
			end
		end
	end
end

function KGC_ARENA_FIGHT_LAYER_TYPE:UpdateData()
	--test
	self:UpdateDataAtTime();
	--test end
end

function KGC_ARENA_FIGHT_LAYER_TYPE:UpdateDataAtTime()
	local lblMoney = self.m_pLayout:getChildByName("lbl_moneynum");
	lblMoney:setString(self.m_nCurStage .. "-" .. self.m_nCurStep);
end