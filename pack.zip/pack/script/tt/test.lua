
local fight = function(a)
	--while true do
		--print('f1............')
		--end
		print('f1 end............', a)
		return "cba"
end

return fight
