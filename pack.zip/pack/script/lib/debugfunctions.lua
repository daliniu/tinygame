----------------------------------------------------------
-- file:	debugfunctions.lua
-- Author:	page
-- Time:	2015/03/03 
-- Desc:	һЩ����Ҫ�õĺ���
----------------------------------------------------------
--�Ƿ����ģʽ
DEBUG_VERSION = false
--�Ƿ�ر�����
DEBUG_CLOSED_NETWORK = false;
-- �Ƿ�����
-- _SERVER = false
--�����������
_DEBUG_ = false;
-- �����ڴ�й©
DEBUG_MEMORY_LEAK = true;
-- �������Կͻ��˺ͷ�����������
-- DEBUG_SEED = true;

function dbf_SwitchFlag()
	if DEBUG_VERSION == true then
		DEBUG_VERSION = false
	else
		DEBUG_VERSION = true;
	end
end

function dbf_GetFlag()
	return DEBUG_VERSION;
end

if not _SERVER then

local targetPlatform = cc.Application:getInstance():getTargetPlatform()
if cc.PLATFORM_OS_WINDOWS == targetPlatform then
	print("/****************************************************/")
	print("/*********************windows***********************/");
	print("/****************************************************/")
	DEBUG_VERSION_PC = true;
end

end

-- ͳ������������ô���
g_nTestCount = 0;

----------------------------------------------------------------
--[[
                   _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \\|     |//  `.
            /  \\|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
         ���汣��       ����BUG
]]