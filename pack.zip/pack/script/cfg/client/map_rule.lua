﻿
local tb_MAP_RULE_CFG = {
	MAX_STEPS		=		10,				--最多一次走多少步
	PHY_TIPS		=		100,			--体力小于等于多少的时候给弹窗提示
	PHY_ZERO_TIPS	=		5,				--体力小于多少的时候加入提示使用
	MOVE_TIME		=		0.4,			--移动时间
}

return tb_MAP_RULE_CFG;