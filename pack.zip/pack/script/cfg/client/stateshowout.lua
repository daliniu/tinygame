-- excel xlstable format (sparse 3d matrix)
--{	[sheet1] = { [row1] = { [col1] = value, [col2] = value, ...},
--					 [row5] = { [col3] = value, }, },
--	[sheet2] = { [row9] = { [col9] = value, }},
--}
-- nameindex table
--{ [sheet,row,col name] = index, .. }
sheetname = {
["Sheet1"] = 1,
};

sheetindex = {
[1] = "Sheet1",
};

local stateshowout = {
[1] = {
	[60001] = {
		["id"] = 60001,
		["name"] = "大气护盾",
		["effectid"] = 50001,
		["position"] = "torso",
		["zorder"] = 1,
		["scale"] = 1,
		["speed"] = 30,
		["position2"] = {0.5,0.4},
	},
	[60002] = {
		["id"] = 60002,
		["name"] = "增幅",
		["effectid"] = 50002,
		["position"] = "root",
		["zorder"] = 1,
		["scale"] = 1,
		["speed"] = 30,
		["position2"] = {0.5,0.05},
	},
	[60003] = {
		["id"] = 60003,
		["name"] = "飞行",
		["effectid"] = 70007,
		["position"] = "torso",
		["zorder"] = 1,
		["scale"] = 1,
		["speed"] = 30,
		["position2"] = {0.5,0.12},
	},
	[60004] = {
		["id"] = 60004,
		["name"] = "力竭",
		["effectid"] = 50003,
		["position"] = "root",
		["zorder"] = -1,
		["scale"] = 1,
		["speed"] = 30,
		["position2"] = {0.5,0.05},
	},
	[60005] = {
		["id"] = 60005,
		["name"] = "眩晕",
		["effectid"] = 50004,
		["position"] = "head",
		["zorder"] = 1,
		["scale"] = 1,
		["speed"] = 30,
		["position2"] = {0.5,1},
	},
	[60006] = {
		["id"] = 60006,
		["name"] = "士气",
		["effectid"] = 50002,
		["position"] = "root",
		["zorder"] = 1,
		["scale"] = 1,
		["speed"] = 30,
		["position2"] = {0.5,0.05},
	},
},
};

-- functions for xlstable read
local __getcell = function (t, a,b,c) return t[a][b][c] end
function GetCell(sheetx, rowx, colx)
	rst, v = pcall(__getcell, xlstable, sheetx, rowx, colx)
	if rst then return v
	else return nil
	end
end

function GetCellBySheetName(sheet, rowx, colx)
	return GetCell(sheetname[sheet], rowx, colx)
end

__XLS_END = true

local tbConfig = gf_CopyTable(stateshowout[1])

setmetatable(tbConfig, {__newindex = function(k, v)
		print("[Error]config is read only!")
	end})

return tbConfig;
