----------------------------------------------------------
-- file:	fightsetting.lua
-- Author:	page
-- Time:	2015/12/8 20:00
-- Desc:	战斗下拉菜单配置表(策划用)
----------------------------------------------------------
local TB_CONFIG_FIGHT_ACTION = {
	--下拉菜单按钮的配置
	nOriY = 600,				--移动前y坐标
	nY = 550,					--移动终点的y坐标
	nTime = 0.1,				--移动时间(单位：s)

	--飘血配置
	nBeforeDis = 40,			--前半段移动距离
	nBeforeT = 1,				--前半段移动时间
	nScaleB = 1.2,				--变大比例
	nScaleBT = 0.1,				--变大时间
	nScaleS = 1.1,				--变小比例
	nScaleST = 0.1,				--变小时间
	nAfterDis = 40,				--后半段移动距离
	nAfterT = 1,				--后半段移动时间
}


return TB_CONFIG_FIGHT_ACTION;