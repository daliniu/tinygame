-- excel xlstable format (sparse 3d matrix)
--{	[sheet1] = { [row1] = { [col1] = value, [col2] = value, ...},
--					 [row5] = { [col3] = value, }, },
--	[sheet2] = { [row9] = { [col9] = value, }},
--}
-- nameindex table
--{ [sheet,row,col name] = index, .. }
sheetname = {
["Sheet1"] = 1,
};

sheetindex = {
[1] = "Sheet1",
};

local explortalk = {
[1] = {
	[1] = {
		["id"] = 1,
		["talk"] = "发现敌人！进入战斗！",
	},
	[2] = {
		["id"] = 2,
		["talk"] = "看潘多拉下面……",
	},
	[3] = {
		["id"] = 3,
		["talk"] = "和曹操一起吃饼……",
	},
	[4] = {
		["id"] = 4,
		["talk"] = "和美杜莎调情……",
	},
	[5] = {
		["id"] = 5,
		["talk"] = "给异世界的朋友写信……",
	},
	[6] = {
		["id"] = 6,
		["talk"] = "玩球中……",
	},
	[7] = {
		["id"] = 7,
		["talk"] = "练习打飞机……",
	},
	[8] = {
		["id"] = 8,
		["talk"] = "向逃跑的怪物发起冲锋……",
	},
	[9] = {
		["id"] = 9,
		["talk"] = "避开发怒的队友……",
	},
	[10] = {
		["id"] = 10,
		["talk"] = "往队友的鞋里放冰块……",
	},
	[11] = {
		["id"] = 11,
		["talk"] = "往队友身上泼水……",
	},
	[12] = {
		["id"] = 12,
		["talk"] = "偷看队友洗澡……",
	},
	[13] = {
		["id"] = 13,
		["talk"] = "和曹操一起搞鸡……",
	},
	[14] = {
		["id"] = 14,
		["talk"] = "大家一起吃豆腐……",
	},
	[15] = {
		["id"] = 15,
		["talk"] = "跟我一起干一杯~",
	},
},
};

-- functions for xlstable read
local __getcell = function (t, a,b,c) return t[a][b][c] end
function GetCell(sheetx, rowx, colx)
	rst, v = pcall(__getcell, xlstable, sheetx, rowx, colx)
	if rst then return v
	else return nil
	end
end

function GetCellBySheetName(sheet, rowx, colx)
	return GetCell(sheetname[sheet], rowx, colx)
end

__XLS_END = true

local tbConfig = gf_CopyTable(explortalk[1])

setmetatable(tbConfig, {__newindex = function(k, v)
		print("[Error]config is read only!")
	end})

return tbConfig;
