----------------------------------------------------------
-- file:	config.lua
-- Author:	page
-- Time:	2015/03/31	9:39
-- Desc:	策划可修改的配置数据
----------------------------------------------------------

local TB_CONFIG_OTHERS = {
	nMaxContractQueue = 3,		--契约生物队列最大长度
	
	nMaxEquipStar = 5,			-- 装备升星的最高级

}

return TB_CONFIG_OTHERS;
