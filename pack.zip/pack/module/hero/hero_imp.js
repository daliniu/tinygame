var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var tiny = require('../../tiny');
var heroHandle = require('../dataprocess/hero_handle');
var playerHandle = require('../dataprocess/player_handle');
var equipHandle = require('../dataprocess/equip_handle');
var async = require('async');
var utils = require('../utils');
var async = require('async');

// 获取英雄图鉴信息
var getHeroInfoList = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	outArgs = {};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取英雄图鉴信息
		function(session, callback) {
			// 获取英雄列表
			heroHandle.getHeroInfoList(session.area, session.uuid, function(err, heroInfoList, heroBookInfo) {
				if (err) {
					// 获取数据失败,未获取过英雄或者获取数据失败
					callback(ErrCode.NEVER_CREATE_HERO_INFO_LIST, err, session);
				} else {
					// 获取数据成功
					callback(null, null, session, heroInfoList, heroBookInfo);
				}
			});
		}
	], function(err, errStr, session, heroInfoList, heroBookInfo) {
		if (err) {
			tiny.log.error("getHeroInfoList", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfoList = heroInfoList;
			outArgs.heroBookInfo = heroBookInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});

	//返回
	return ErrCode.SUCCESS;
};

// 创建新英雄
var createHero = function(inArgs, onResponse, current) {
	// 定义变量
	var retCode, outArgs, uuid, area, heroId;

	// 获取输入参数
	uuid = inArgs.uuid;
	area = inArgs.area;
	heroId = inArgs.heroId;

	// 处理逻辑
	tiny.log.debug("|createHero|uuid:",area, uuid);

	outArgs = {};

	// 创建新英雄
	heroHandle.setHeroToHeroList(area, uuid, heroId, function(err, heroInfoList) {
		if (err) {
			// 获取数据失败,未获取过英雄或者获取数据失败
			tiny.log.error("|createHero|uuid:", uuid, area, err);
			outArgs.heroInfo = {};
			retCode = ErrCode.CREATE_HERO_INFO_FAILURE;
		} else {
			// 获取数据成功
			if (heroInfoList.hasOwnProperty(heroId)) {
				outArgs.heroInfo = heroInfoList[heroId];
				retCode = ErrCode.SUCCESS;
			} else {
				retCode = ErrCode.FAILURE;
			}
		}
		onResponse(retCode, current, inArgs, outArgs);
	});

	//返回
	return ErrCode.SUCCESS;
};

// 提升英雄经验，等级
var upgradeHeroLevel = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, heroId, expPlayer, exp;

	// 获取输入参数
	heroId    = inArgs.heroId;
	expPlayer = inArgs.expPlayer;
	exp       = inArgs.exp;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 升级
		function(session, callback) {
			if (heroId) {
				// 升级单个英雄
				heroHandle.updateHeroExpInHeroList(session.area, session.uuid, heroId, exp, function(err, heroInfo) {
					if (err) {
						tiny.log.error("updateHeroExpInHeroList", session.uuid, session.area, err);
						callback(ErrCode.NEVER_CREATE_HERO_INFO_LIST, err, session);
					} else {
						callback(null, session, heroInfo, {});
					}
				});
			} else {
				// 升级玩家经验
				playerHandle.updatePlayerExp(session.area, session.uuid, expPlayer, function(err, playerInfo) {
					if (err) {
						tiny.log.error("updatePlayerExp", session.uuid, session.area, err);
						callback(ErrCode.NEVER_CREATE_PLAYER, err, session);
					} else {
						callback(null, session, {}, playerInfo);
					}
				});
			}
		},
		// 升级团队英雄经验
		function(session, heroInfo, playerInfo, callback) {
			var heroIds;
			if (!heroId && exp) {
				// 取团队英雄id
				heroIds = playerHandle.getHeroIdsFromPosList(playerInfo.posList);
				// 升级英雄经验
				heroHandle.updateHerosExpInHeroList(session.area, session.uuid, heroIds, exp, function(err, teamList) {
					if (err) {
						tiny.log.error("updateHerosExpInHeroList", session.uuid, session.area, err);
						callback(ErrCode.NEVER_CREATE_TEAM_LIST, err, session);
					} else {
						// 转换团队英雄列表
						playerInfo.teamList = playerHandle.transPosListToTeamList(playerInfo.posList, teamList);
						callback(null, null, session, heroInfo, playerInfo);
					}
				});
			} else {
				callback(null, null, session, heroInfo, playerInfo);
			}
		}
	], function(err, errStr, session, heroInfo, playerInfo) {
		if (err) {
			tiny.log.error("upgradeHeroLevel", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfo = heroInfo;
			outArgs.playerInfo = playerInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});

};

/*
*/
// 提升技能槽等级
var upgradeSkillSlot = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, heroId, slotId;

	// 获取输入参数
	heroId = inArgs.heroId;
	slotId = inArgs.slotId;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 提升技能槽等级
		function(session, callback) {
			heroHandle.upgradeSkillSlot(session.area, session.uuid, heroId, slotId, function(err, heroInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, heroInfo);
				}
			});
		}
	], function(err, errStr, session, heroInfo) {
		if (err) {
			tiny.log.error("upgradeSkillSlot", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfo = heroInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 英雄升星
var upgradeHeroStar = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, heroId;

	// 获取输入参数
	heroId = inArgs.heroId;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取玩家基本数据
		function(session, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, baseInfo);
				}
			});
		},
		// 获取英雄数据
		function(session, baseInfo, callback) {
			heroHandle.getHeroInfo(session.area, session.uuid, heroId, function(err, heroInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, baseInfo);
				}
			});
		},
		// 获取背包信息
		function(session, heroInfo, baseInfo, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, baseInfo, bagList);
				}
			});
		},
		// 逻辑计算
		function(session, heroInfo, baseInfo, bagList, callback) {
			tiny.log.debug("upgradeHeroStar", JSON.stringify(heroInfo), JSON.stringify(baseInfo), JSON.stringify(bagList));
			if (!heroHandle.upgradeHeroStarBaseInfo(heroInfo, baseInfo)) {
				callback(ErrCode.FAILURE, "upgradeHeroStarBaseInfo error", session);
			} else {
				if (!heroHandle.upgradeHeroStarBagList(heroInfo, bagList)) {
					callback(ErrCode.FAILURE, "upgradeHeroStarBagList error", session);
				} else {
					if (!heroHandle.upgradeHeroStarLevel(heroInfo)) {
						callback(ErrCode.FAILURE, "upgradeHeroStarLevel error", session);
					} else {
						callback(null, session, heroInfo, baseInfo, bagList);
					}
				}
			}
		},
		// 保存玩家基本数据
		function(session, heroInfo, baseInfo, bagList, callback) {
			tiny.log.debug("...1");
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, baseInfo, bagList);
				}
			});
		},
		// 保存背包数据
		function(session, heroInfo, baseInfo, bagList, callback) {
			tiny.log.debug("...2");
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, baseInfo, bagList);
				}
			});
		},
		// 保存英雄信息
		function(session, heroInfo, baseInfo, bagList, callback) {
			tiny.log.debug("...3");
			heroHandle.setHeroInfo(session.area, session.uuid, heroId, heroInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, heroInfo, baseInfo, bagList);
				}
			});
		},
	], function(err, errStr, session, heroInfo) {
		if (err) {
			tiny.log.error("upgradeHeroStar", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfo = heroInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 英雄布阵
var makeHeroLineup = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	// 获取输入参数

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 提升英雄星级
		function(session, callback) {
			playerHandle.makeHeroLineup(session.area, session.uuid, inArgs.posDst, inArgs.heroId, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, baseInfo);
				}
			});
		}
	], function(err, errStr, session) {
		if (err) {
			outArgs.isOk = ErrCode.NOT_OK;
			tiny.log.error("makeHeroLineup", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.isOk = ErrCode.OK;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 召唤英雄
var rollHero = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	// 随机英雄
	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 召唤英雄
		function(session, callback) {
			heroHandle.rollHero(session.area, session.uuid, parseInt(inArgs.heroId, 10), function(err, heroInfo, heroBookInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, heroInfo, heroBookInfo);
				}
			});
		}
	], function(err, errStr, session, heroInfo, heroBookInfo) {
		if (err) {
			tiny.log.error("rollHero", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfo = heroInfo;
			outArgs.heroBookInfo = heroBookInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 英雄升星
var upgradeHeroQuality = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, heroId;

	// 获取输入参数
	heroId = inArgs.heroId;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取英雄数据
		function(session, callback) {
			heroHandle.getHeroInfo(session.area, session.uuid, heroId, function(err, heroInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo);
				}
			});
		},
		// 获取背包信息
		function(session, heroInfo, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, bagList);
				}
			});
		},
		// 逻辑计算
		function(session, heroInfo, bagList, callback) {
			tiny.log.debug("upgradeHeroQuality", JSON.stringify(heroInfo), JSON.stringify(bagList));
			if (!heroHandle.upgradeHeroQualityBagList(heroInfo, bagList)) {
				callback(ErrCode.FAILURE, "upgradeHeroQualityBagList error", session);
			} else {
				if (!heroHandle.upgradeHeroQualityLevel(heroInfo)) {
					callback(ErrCode.FAILURE, "upgradeHeroQuality error", session);
				} else {
					callback(null, session, heroInfo, bagList);
				}
			}
		},
		// 保存背包数据
		function(session, heroInfo, bagList, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, bagList);
				}
			});
		},
		// 保存英雄信息
		function(session, heroInfo, bagList, callback) {
			heroHandle.setHeroInfo(session.area, session.uuid, heroId, heroInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, heroInfo, bagList);
				}
			});
		},
	], function(err, errStr, session, heroInfo) {
		if (err) {
			tiny.log.error("upgradeHeroQuality", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfo = heroInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};


// 英雄碎片合成
var shopHero = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取背包信息
		function(session, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, bagList);
				}
			});
		},
		// 获取英雄汇总数据
		function(session, bagList, callback) {
			heroHandle.getHeroInfo(session.area, session.uuid, Const.HERO_BOOK_INFO_INDEX, function(err, heroBookInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, bagList, heroBookInfo);
				}
			});
		},
		// 获取玩家信息
		function(session, bagList, heroBookInfo, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, bagList, heroBookInfo, baseInfo);
				}
			});
		},
		// 逻辑计算
		function(session, bagList, heroBookInfo, baseInfo, callback) {
			var bagItem ={};
			if (!heroHandle.shopHero(inArgs.shopId, bagList, heroBookInfo, baseInfo, bagItem)) {
				callback(ErrCode.SHOP_HERO_ERROR, "shopHero error", session);
			} else {
				callback(null, session, heroBookInfo, bagList, bagItem);
			}
		},
		// 保存英雄汇总数据
		function(session, heroBookInfo, bagList, bagItem, callback) {
			heroHandle.setHeroInfo(session.area, session.uuid, Const.HERO_BOOK_INFO_INDEX, heroBookInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, bagList, bagItem);
				}
			});
		},
		// 保存背包数据
		function(session, bagList, bagItem, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, bagItem);
				}
			});
		},
	], function(err, errStr, session, bagItem) {
		if (err) {
			tiny.log.error("shopHero", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.bagItem = bagItem;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 刷新英雄商店
var refreshHeroShop = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取英雄汇总数据
		function(session, callback) {
			heroHandle.getHeroInfo(session.area, session.uuid, Const.HERO_BOOK_INFO_INDEX, function(err, heroBookInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroBookInfo);
				}
			});
		},
		// 获取背包信息
		function(session, heroBookInfo, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroBookInfo, baseInfo);
				}
			});
		},
		// 逻辑计算
		function(session, heroBookInfo, baseInfo, callback) {
			var time = heroHandle.refreshHeroShop(inArgs.isRefresh, heroBookInfo, baseInfo);
			if (time < 0) {
				callback(ErrCode.FAILURE, "refreshHeroShop error", session);
			} else {
				callback(null, session, heroBookInfo, time);
			}
		},
		// 保存英雄汇总数据
		function(session, heroBookInfo, time, callback) {
			heroHandle.setHeroInfo(session.area, session.uuid, Const.HERO_BOOK_INFO_INDEX, heroBookInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, heroBookInfo, time);
				}
			});
		},
	], function(err, errStr, session, heroBookInfo, time) {
		if (err) {
			tiny.log.error("shopHero", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.shop1 = heroBookInfo.shop1;
			outArgs.shop2 = heroBookInfo.shop2;
			outArgs.shop3 = heroBookInfo.shop3;
			outArgs.shop4 = heroBookInfo.shop4;
			outArgs.shop5 = heroBookInfo.shop5;
			outArgs.refreshNums = heroBookInfo.refreshNums;
			outArgs.time = time;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

//洗练英雄
var washHero = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取英雄数据
		function(session, callback) {
			heroHandle.getHeroInfo(session.area, session.uuid, inArgs.heroId, function(err, heroInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo);
				}
			});
		},
		// 获取背包信息
		function(session, heroInfo, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, bagList);
				}
			});
		},
		// 获取基本信息
		function(session, heroInfo, bagList, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, bagList, baseInfo);
				}
			});
		},
		// 逻辑计算
		function(session, heroInfo, bagList, baseInfo, callback) {
			// 洗练英雄
			if (!heroHandle.washHeroInfo(heroInfo, bagList, baseInfo, inArgs)) {
				callback(ErrCode.WASH_HERO_ERROR, "washHeroInfo error", session);
			} else {
				callback(null, session, heroInfo, bagList, baseInfo);
			}
		},
		// 保存基本信息
		function(session, heroInfo, bagList, baseInfo, callback) {
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, bagList);
				}
			});
		},
		// 保存背包信息
		function(session, heroInfo, bagList, callback) {
			heroHandle.setHeroInfo(session.area, session.uuid, inArgs.heroId, heroInfo, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, session, heroInfo, bagList);
				}
			});
		},
		// 保存英雄数据
		function(session, heroInfo, bagList, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, heroInfo);
				}
			});
		},
	], function(err, errStr, session, heroInfo) {
		if (err) {
			tiny.log.error("washHero", session.area, session.uuid, err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.heroInfo = heroInfo;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 配置技能槽
var adapterSkillSlot = function(dataValue, inArgs) {
	var outArgs = {}, i;
	outArgs.retCode = ErrCode.SUCCESS;
	for (i = 1; i < 7; i++) {
		if (inArgs["skillId" + i] !== 0) {
			dataValue.heroInfo.skillSlotList[i].skillId = inArgs["skillId" + i];
		}
	}
	outArgs.heroInfo = dataValue.heroInfo;
	return outArgs;
};
module.exports = {
"getHeroInfoList" : getHeroInfoList,
"createHero" : createHero,
"upgradeHeroLevel" : upgradeHeroLevel,
"upgradeSkillSlot" : upgradeSkillSlot,
"upgradeHeroStar" : upgradeHeroStar,
"makeHeroLineup" : makeHeroLineup,
"rollHero" : rollHero,
"upgradeHeroQuality" : upgradeHeroQuality,
"shopHero" : shopHero,
"refreshHeroShop" : refreshHeroShop,
"washHero" : washHero,
"testNew" : {
"adapterSkillSlot" : adapterSkillSlot,
},
};
