/*
Don't modify this file manually!
*/
var _p = {
    30002 : {
        "next_skill" : 0,
        "character_level" : 1,
        "ID" : 30002,
        "cost" : 0,
    },
    30003 : {
        "next_skill" : 0,
        "character_level" : 1,
        "ID" : 30003,
        "cost" : 0,
    },
    30004 : {
        "next_skill" : 0,
        "character_level" : 1,
        "ID" : 30004,
        "cost" : 0,
    },
    30005 : {
        "next_skill" : 0,
        "character_level" : 1,
        "ID" : 30005,
        "cost" : 0,
    },
    30001 : {
        "next_skill" : 0,
        "character_level" : 1,
        "ID" : 30001,
        "cost" : 0,
    },

};
module.exports = _p;
