/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "EffectArg" : 30,
        "Effecttype" : 1,
        "BuffId" : 1,
        "Desc" : "每次行走的步数消耗减少30%",
        "TimeArg" : 30,
        "Name" : "减少步耗（百分比）",
        "BuffType" : 1,
        "EffectID" : 0,
        "Pic" : 10000,
    },
    2 : {
        "EffectArg" : 2,
        "Effecttype" : 2,
        "BuffId" : 2,
        "Desc" : "每次行走的步数消耗减少2",
        "TimeArg" : 30,
        "Name" : "减少步耗（数值）",
        "BuffType" : 1,
        "EffectID" : 0,
        "Pic" : 10001,
    },
    3 : {
        "EffectArg" : 30,
        "Effecttype" : 3,
        "BuffId" : 3,
        "Desc" : "每次行走的步数消耗增加30%",
        "TimeArg" : 30,
        "Name" : "增加步耗（百分比）",
        "BuffType" : 1,
        "EffectID" : 0,
        "Pic" : 10001,
    },
    20 : {
        "EffectArg" : 30,
        "Effecttype" : 6,
        "BuffId" : 20,
        "Desc" : "商店道具单价降低30%",
        "TimeArg" : 86400,
        "Name" : "降价",
        "BuffType" : 2,
        "EffectID" : 0,
        "Pic" : 10001,
    },
    10 : {
        "EffectArg" : 20,
        "Effecttype" : 5,
        "BuffId" : 10,
        "Desc" : "每次获得的金钱奖励加成20%",
        "TimeArg" : 5,
        "Name" : "金钱奖励加成",
        "BuffType" : 2,
        "EffectID" : 0,
        "Pic" : 10001,
    },

};
module.exports = _p;
