/*
Don't modify this file manually!
*/
var _p = {
    1001 : {
        "scale" : 1.5,
        "describe" : "升级特效（60006）",
        "majoreffctid" : 1001,
    },
    1003 : {
        "scale" : 1.1,
        "describe" : "角色升品特效（60036）",
        "majoreffctid" : 1003,
    },
    1000 : {
        "scale" : 1,
        "majoreffctid" : 1000,
        "describe" : "连携主特效（60004）",
        "position" : {
            1 : 375,
            2 : 967,
        },
    },
    1002 : {
        "scale" : 2.2,
        "majoreffctid" : 1002,
        "describe" : "角色升品主特效（60034）",
        "position" : {
            1 : 375,
            2 : 858,
        },
    },
    1004 : {
        "scale" : 2,
        "majoreffctid" : 1004,
        "describe" : "角色升星特效（60035）",
        "position" : {
            1 : 380,
            2 : 862,
        },
    },

};
module.exports = _p;
