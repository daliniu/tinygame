/*
Don't modify this file manually!
*/
var _p = {
    2 : {
        "iconpath" : "res/ui/05_mainUI/05_ico_main_03.png",
        "iconID" : 2,
        "iconname" : "金钱",
    },
    3 : {
        "iconpath" : "res/ui/05_mainUI/05_ico_main_02.png",
        "iconID" : 3,
        "iconname" : "钻石",
    },
    4 : {
        "iconpath" : "res/ui/05_mainUI/05_ico_main_01.png",
        "iconID" : 4,
        "iconname" : "步数",
    },

};
module.exports = _p;
