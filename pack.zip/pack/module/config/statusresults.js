/*
Don't modify this file manually!
*/
var _p = {
    6001 : {
        "arg2" : 50,
        "effecttype" : 2,
        "id" : 6001,
        "arg3" : 1,
        "arg5" : 0,
        "arg1" : 50,
        "arg4" : 1,
        "arg6" : 0,
        "arg7" : 0,
    },
    6003 : {
        "arg2" : 0,
        "effecttype" : 1,
        "id" : 6003,
        "arg3" : 0,
        "arg5" : 0,
        "arg1" : 0,
        "arg4" : 0,
        "arg6" : 0,
        "arg7" : 0,
    },
    6005 : {
        "arg2" : 0,
        "effecttype" : 8,
        "id" : 6005,
        "arg3" : 0,
        "arg5" : 0,
        "arg1" : 0,
        "arg4" : 0,
        "arg6" : 0,
        "arg7" : 0,
    },
    6002 : {
        "arg2" : 80,
        "effecttype" : 5,
        "id" : 6002,
        "arg3" : 10,
        "arg5" : 0,
        "arg1" : 8001,
        "arg4" : 0,
        "arg6" : 0,
        "arg7" : 0,
    },
    6004 : {
        "arg2" : 100,
        "effecttype" : 9,
        "id" : 6004,
        "arg3" : 0,
        "arg5" : 0,
        "arg1" : 8001,
        "arg4" : 0,
        "arg6" : 0,
        "arg7" : 0,
    },

};
module.exports = _p;
