/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "price" : 10,
        "Bid" : 1,
        "itemNo" : 10,
        "itemId" : 15001,
    },
    2 : {
        "price" : 10,
        "Bid" : 2,
        "itemNo" : 20,
        "itemId" : 15001,
    },
    3 : {
        "price" : 300,
        "Bid" : 3,
        "itemNo" : 1,
        "itemId" : 15002,
    },

};
module.exports = _p;
