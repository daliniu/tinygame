/*
Don't modify this file manually!
*/
var _p = {
    60003 : {
        "effectid" : 70007,
        "id" : 60003,
        "name" : "飞行",
        "position" : "torso",
        "scale" : 1,
        "speed" : 30,
        "zorder" : 1,
        "position2" : {
            1 : 0.5,
            2 : 0.12,
        },
    },
    60005 : {
        "effectid" : 50004,
        "id" : 60005,
        "name" : "眩晕",
        "position" : "head",
        "scale" : 1,
        "speed" : 30,
        "zorder" : 1,
        "position2" : {
            1 : 0.5,
            2 : 1,
        },
    },
    60002 : {
        "effectid" : 50002,
        "id" : 60002,
        "name" : "增幅",
        "position" : "root",
        "scale" : 1,
        "speed" : 30,
        "zorder" : 1,
        "position2" : {
            1 : 0.5,
            2 : 0.05,
        },
    },
    60004 : {
        "effectid" : 50003,
        "id" : 60004,
        "name" : "力竭",
        "position" : "root",
        "scale" : 1,
        "speed" : 30,
        "zorder" : -1,
        "position2" : {
            1 : 0.5,
            2 : 0.05,
        },
    },
    60006 : {
        "effectid" : 50002,
        "id" : 60006,
        "name" : "士气",
        "position" : "root",
        "scale" : 1,
        "speed" : 30,
        "zorder" : 1,
        "position2" : {
            1 : 0.5,
            2 : 0.05,
        },
    },
    60001 : {
        "effectid" : 50001,
        "id" : 60001,
        "name" : "大气护盾",
        "position" : "torso",
        "scale" : 1,
        "speed" : 30,
        "zorder" : 1,
        "position2" : {
            1 : 0.5,
            2 : 0.4,
        },
    },

};
module.exports = _p;
