/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "StarLevel" : 0,
        "Key" : 1,
        "RemainingBlood" : {
            1 : -100,
            2 : 0,
        },
        "PicRes" : "res/ui/temp/temp_battle_0xing.png",
        "SupplyDeduction" : 15,
    },
    2 : {
        "StarLevel" : 1,
        "Key" : 2,
        "RemainingBlood" : {
            1 : 0,
            2 : 5,
        },
        "PicRes" : "res/ui/temp/temp_battle_1xing.png",
        "SupplyDeduction" : 10,
    },
    3 : {
        "StarLevel" : 2,
        "Key" : 3,
        "RemainingBlood" : {
            1 : 5,
            2 : 20,
        },
        "PicRes" : "res/ui/temp/temp_battle_2xing.png",
        "SupplyDeduction" : 8,
    },
    4 : {
        "StarLevel" : 3,
        "Key" : 4,
        "RemainingBlood" : {
            1 : 20,
            2 : 45,
        },
        "PicRes" : "res/ui/temp/temp_battle_3xing.png",
        "SupplyDeduction" : 5,
    },
    5 : {
        "StarLevel" : 4,
        "Key" : 5,
        "RemainingBlood" : {
            1 : 45,
            2 : 60,
        },
        "PicRes" : "res/ui/temp/temp_battle_4xing.png",
        "SupplyDeduction" : 3,
    },
    6 : {
        "StarLevel" : 5,
        "Key" : 6,
        "RemainingBlood" : {
            1 : 60,
            2 : 100,
        },
        "PicRes" : "res/ui/temp/temp_battle_5xing.png",
        "SupplyDeduction" : 0,
    },

};
module.exports = _p;
