/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "InitPos" : {
            1 : 5,
            2 : 5,
        },
        "BGPic" : 201,
        "MapId" : 1,
        "UnlockCondition1" : 0,
        "MapSign" : {
            1 : 1,
            2 : 2,
            3 : 3,
        },
        "ScenePic" : 1,
        "InfoFile" : "01.json",
        "BattlePic" : {
            1 : 101,
            2 : 102,
            3 : 103,
            4 : 104,
            5 : 105,
        },
        "ExitId" : 105,
        "ResPath" : "res/map/01.tmx",
        "UnlockCondition3" : 0,
        "Area1" : 2,
        "UnlockCondition2" : 0,
    },
    2 : {
        "InitPos" : {
            1 : 9,
            2 : 5,
        },
        "BGPic" : 201,
        "MapId" : 2,
        "UnlockCondition1" : 0,
        "MapSign" : {
            1 : 1,
            2 : 2,
            3 : 3,
        },
        "ScenePic" : 1,
        "InfoFile" : "02.json",
        "BattlePic" : {
            1 : 101,
            2 : 102,
            3 : 103,
            4 : 104,
            5 : 105,
        },
        "ExitId" : 816,
        "ResPath" : "res/map/02.tmx",
        "UnlockCondition3" : 0,
        "Area1" : 823,
        "UnlockCondition2" : 0,
    },
    3 : {
        "InitPos" : {
            1 : 5,
            2 : 22,
        },
        "BGPic" : 201,
        "MapId" : 3,
        "UnlockCondition1" : 0,
        "MapSign" : {
            1 : 1,
            2 : 2,
            3 : 3,
        },
        "ScenePic" : 1,
        "InfoFile" : "03.json",
        "BattlePic" : {
            1 : 101,
            2 : 102,
            3 : 103,
            4 : 104,
            5 : 105,
        },
        "ExitId" : 1454,
        "ResPath" : "res/map/03.tmx",
        "UnlockCondition3" : 0,
        "Area1" : 1359,
        "UnlockCondition2" : 0,
    },
    4 : {
        "InitPos" : {
            1 : 2,
            2 : 6,
        },
        "BGPic" : 201,
        "MapId" : 4,
        "UnlockCondition1" : 0,
        "MapSign" : {
            1 : 1,
            2 : 2,
            3 : 3,
        },
        "ScenePic" : 1,
        "InfoFile" : "04.json",
        "BattlePic" : {
            1 : 101,
            2 : 102,
            3 : 103,
            4 : 104,
            5 : 105,
        },
        "ExitId" : 1541,
        "ResPath" : "res/map/04.tmx",
        "UnlockCondition3" : 0,
        "Area1" : 1483,
        "UnlockCondition2" : 0,
    },

};
module.exports = _p;
