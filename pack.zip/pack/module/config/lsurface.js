/*
Don't modify this file manually!
*/
var _p = {
    10005 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 0,
        "Name" : "沼泽6",
        "LandType" : 1,
        "Id" : 10005,
        "ElementType" : 30,
        "Genre" : 10,
        "Pic" : 3206,
    },
    20003 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 4,
        "Name" : "大风下",
        "LandType" : 2,
        "Id" : 20003,
        "ElementType" : 31,
        "Genre" : 10,
        "Pic" : 0,
    },
    10000 : {
        "Area" : {
            1 : 2,
            2 : 1,
        },
        "Direction" : 0,
        "Name" : "沼泽1",
        "LandType" : 1,
        "Id" : 10000,
        "ElementType" : 30,
        "Genre" : 10,
        "Pic" : 3201,
    },
    10002 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 0,
        "Name" : "沼泽3",
        "LandType" : 1,
        "Id" : 10002,
        "ElementType" : 30,
        "Genre" : 10,
        "Pic" : 3203,
    },
    10004 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 0,
        "Name" : "沼泽5",
        "LandType" : 1,
        "Id" : 10004,
        "ElementType" : 30,
        "Genre" : 10,
        "Pic" : 3205,
    },
    20001 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 2,
        "Name" : "大风右",
        "LandType" : 2,
        "Id" : 20001,
        "ElementType" : 31,
        "Genre" : 10,
        "Pic" : 0,
    },
    20000 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 1,
        "Name" : "大风左",
        "LandType" : 2,
        "Id" : 20000,
        "ElementType" : 31,
        "Genre" : 10,
        "Pic" : 0,
    },
    10001 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 0,
        "Name" : "沼泽2",
        "LandType" : 1,
        "Id" : 10001,
        "ElementType" : 30,
        "Genre" : 10,
        "Pic" : 3202,
    },
    20002 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 3,
        "Name" : "大风上",
        "LandType" : 2,
        "Id" : 20002,
        "ElementType" : 31,
        "Genre" : 10,
        "Pic" : 0,
    },
    10003 : {
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Direction" : 0,
        "Name" : "沼泽4",
        "LandType" : 1,
        "Id" : 10003,
        "ElementType" : 30,
        "Genre" : 10,
        "Pic" : 3204,
    },

};
module.exports = _p;
