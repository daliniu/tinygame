/*
Don't modify this file manually!
*/
var _p = {
    10005 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 104,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113011,
        },
        "increasehurt" : 0,
        "name" : "贞德",
        "modelid" : 1005,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 400,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 2,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 1,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10005,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 74,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10007 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 106,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "莫甘娜",
        "modelid" : 1007,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 3,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10007,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 76,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10009 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 108,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "孔明",
        "modelid" : 1009,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 3,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10009,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 78,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10011 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 110,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "托尔",
        "modelid" : 1011,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 4,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10011,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 80,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10013 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 111,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "曹孟德",
        "modelid" : 1013,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 5,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10013,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 81,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10015 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 111,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "赫拉克勒斯",
        "modelid" : 1015,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 5,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10015,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 81,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10002 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 101,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30011,
            2 : 2,
        },
        "skillid" : {
            1 : 30027,
            2 : 30029,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 200,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113008,
        },
        "increasehurt" : 0,
        "name" : "斯巴达克斯",
        "modelid" : 1002,
        "skill2_1" : {
            1 : 30007,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30003,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30005,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 1,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 2,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10002,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30017,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30010,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30006,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 71,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30013,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30020,
            2 : 3,
        },
    },
    10004 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 103,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30023,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 250,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113010,
        },
        "increasehurt" : 0,
        "name" : "布伦希尔德",
        "modelid" : 1004,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 40,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 2,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 1,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10004,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 73,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10006 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 105,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "潘多拉",
        "modelid" : 1006,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 2,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10006,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 75,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10008 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 107,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "苏妲己",
        "modelid" : 1008,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 3,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10008,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 77,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10010 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 109,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "花木兰",
        "modelid" : 1010,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 4,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10010,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 79,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10012 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 111,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "路西法",
        "modelid" : 1012,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 4,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10012,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 81,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10014 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 111,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30024,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113012,
        },
        "increasehurt" : 0,
        "name" : "血腥玛丽",
        "modelid" : 1014,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 5,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10014,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 81,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10001 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 100,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30010,
            2 : 2,
        },
        "skillid" : {
            1 : 30001,
            2 : 30029,
        },
        "hits" : 80,
        "defense" : 70,
        "atk" : 150,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113007,
        },
        "increasehurt" : 0,
        "name" : "亚瑟王",
        "modelid" : 1001,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30002,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 400,
        "skill1_2" : {
            1 : 30004,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 1,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 3,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10001,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 30028,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30007,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30008,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30020,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 70,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30013,
            2 : 3,
        },
    },
    10003 : {
        "reducehurt" : 10,
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 102,
        },
        "anticritrate" : 0,
        "skill4_1" : {
            1 : 30020,
            2 : 2,
        },
        "skillid" : {
            1 : 30022,
        },
        "hits" : 90,
        "defense" : 50,
        "atk" : 200,
        "suit" : {
            1 : 113005,
            2 : 113006,
            3 : 113009,
        },
        "increasehurt" : 0,
        "name" : "卡特琳娜",
        "modelid" : 1003,
        "skill2_1" : {
            1 : 30005,
            2 : 1,
        },
        "skill1_1" : {
            1 : 30021,
            2 : 1,
        },
        "hitlevel" : 0,
        "hp" : 300,
        "skill1_2" : {
            1 : 30007,
            2 : 2,
        },
        "critrate" : 10,
        "skill6_1" : {
            1 : 30018,
            2 : 2,
        },
        "teamId" : 1,
        "skill6_2" : {
            1 : 30018,
            2 : 5,
        },
        "type" : 2,
        "dodgelevel" : 0,
        "dodgerate" : 10,
        "id" : 10003,
        "tenacitylevel" : 0,
        "conskillid" : {
            1 : 0,
            2 : 0,
        },
        "skill2_2" : {
            1 : 30009,
            2 : 2,
        },
        "skill3_1" : {
            1 : 30015,
            2 : 1,
        },
        "penetrationlevel" : 0,
        "skill5_1" : {
            1 : 30006,
            2 : 2,
        },
        "critlevel" : 0,
        "stargrowing" : {
            1 : {
                1 : 10,
                2 : 10,
                3 : 20,
            },
            2 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            3 : {
                1 : 20,
                2 : 20,
                3 : 30,
            },
            4 : {
                1 : 40,
                2 : 40,
                3 : 60,
            },
            5 : {
                1 : 60,
                2 : 60,
                3 : 72,
            },
        },
        "skill5_2" : {
            1 : 30018,
            2 : 4,
        },
        "skill3_2" : {
            1 : 30016,
            2 : 2,
        },
        "skill4_2" : {
            1 : 30011,
            2 : 3,
        },
    },

};
module.exports = _p;
