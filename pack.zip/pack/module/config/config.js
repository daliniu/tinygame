/*
Don't modify this file manually!
*/
var _p = {
    "nMaxContractQueue" : 3,
    "nMaxEquipStar" : 5,

};
module.exports = _p;
