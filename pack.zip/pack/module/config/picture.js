/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "PicId" : 1,
        "Path" : "res/map/building/01_building_001.png",
    },
    33269 : {
        "PicId" : 33269,
        "Path" : "res/map/surface/03_obs_stone_021.png",
    },
    1801 : {
        "PicId" : 1801,
        "Path" : "res/map/building/01_building_006.png",
    },
    1100 : {
        "PicId" : 1100,
        "Path" : "res/map/building/supply001.png",
    },
    33301 : {
        "Path" : "res/map/surface/01_obs_tree_001.png",
        "PicId" : 33301,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33309 : {
        "PicId" : 33309,
        "Path" : "res/map/surface/01_obs_tree_009.png",
    },
    33317 : {
        "PicId" : 33317,
        "Path" : "res/map/surface/02_obs_tree_001.png",
    },
    33102 : {
        "PicId" : 33102,
        "Path" : "res/map/surface/01_obs_edge_002.png",
    },
    33110 : {
        "Path" : "res/map/surface/01_obs_edge_010.png",
        "PicId" : 33110,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 2,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 0,
            },
            4 : {
                1 : 2,
                2 : 1,
            },
            5 : {
                1 : 2,
                2 : 2,
            },
            6 : {
                1 : 3,
                2 : 2,
            },
            7 : {
                1 : 3,
                2 : 3,
            },
        },
    },
    904 : {
        "PicId" : 904,
        "Path" : "res/map/building/02_building_003.png",
    },
    33126 : {
        "PicId" : 33126,
        "Path" : "res/map/surface/02_obs_edge_004.png",
    },
    33134 : {
        "PicId" : 33134,
        "Path" : "res/map/surface/02_obs_edge_012.png",
    },
    1000 : {
        "PicId" : 1000,
        "Path" : "res/map/building/qizi001.png",
    },
    905 : {
        "PicId" : 905,
        "Path" : "res/map/building/02_building_005.png",
    },
    1001 : {
        "Path" : "res/map/building/01_building_015.png",
        "PicId" : 1001,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 1,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 1,
            },
            6 : {
                1 : 2,
                2 : 2,
            },
            7 : {
                1 : 2,
                2 : 3,
            },
        },
    },
    33214 : {
        "Path" : "res/map/surface/01_obs_stone_014.png",
        "PicId" : 33214,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 2,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 0,
            },
            4 : {
                1 : 2,
                2 : 1,
            },
            5 : {
                1 : 2,
                2 : 2,
            },
            6 : {
                1 : 2,
                2 : 3,
            },
            7 : {
                1 : 3,
                2 : 2,
            },
            8 : {
                1 : 3,
                2 : 3,
            },
            9 : {
                1 : 3,
                2 : 4,
            },
            10 : {
                1 : 4,
                2 : 3,
            },
            11 : {
                1 : 4,
                2 : 4,
            },
            12 : {
                1 : 5,
                2 : 4,
            },
        },
    },
    102 : {
        "PicId" : 102,
        "Path" : "res/map/building/00_building_002.png",
    },
    106 : {
        "PicId" : 106,
        "Path" : "res/map/building/00_building_006.png",
    },
    33238 : {
        "PicId" : 33238,
        "Path" : "res/map/surface/02_obs_stone_019.png",
    },
    906 : {
        "PicId" : 906,
        "Path" : "res/map/building/03_building_001.png",
    },
    33254 : {
        "PicId" : 33254,
        "Path" : "res/map/surface/03_obs_stone_006.png",
    },
    33007 : {
        "PicId" : 33007,
        "Path" : "res/map/surface/01_nsur_grass_007.png",
    },
    1002 : {
        "PicId" : 1002,
        "Path" : "res/map/building/02_building_010.png",
    },
    33302 : {
        "Path" : "res/map/surface/01_obs_tree_002.png",
        "PicId" : 33302,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 1,
            },
            5 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33310 : {
        "PicId" : 33310,
        "Path" : "res/map/surface/01_obs_tree_010.png",
    },
    33318 : {
        "PicId" : 33318,
        "Path" : "res/map/surface/02_obs_tree_002.png",
    },
    1301 : {
        "PicId" : 1301,
        "Path" : "res/map/building/01_building_014.png",
    },
    33103 : {
        "PicId" : 33103,
        "Path" : "res/map/surface/01_obs_edge_003.png",
    },
    33111 : {
        "Path" : "res/map/surface/01_obs_edge_011.png",
        "PicId" : 33111,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 2,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
        },
    },
    908 : {
        "PicId" : 908,
        "Path" : "res/map/building/03_building_003.png",
    },
    33127 : {
        "PicId" : 33127,
        "Path" : "res/map/surface/02_obs_edge_005.png",
    },
    33135 : {
        "PicId" : 33135,
        "Path" : "res/map/surface/02_obs_edge_013.png",
    },
    33143 : {
        "PicId" : 33143,
        "Path" : "res/map/surface/03_obs_edge_004.png",
    },
    909 : {
        "PicId" : 909,
        "Path" : "res/map/building/03_building_004.png",
    },
    33207 : {
        "PicId" : 33207,
        "Path" : "res/map/surface/01_obs_stone_007.png",
    },
    33215 : {
        "Path" : "res/map/surface/01_obs_stone_015.png",
        "PicId" : 33215,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33223 : {
        "PicId" : 33223,
        "Path" : "res/map/surface/02_obs_stone_004.png",
    },
    33231 : {
        "PicId" : 33231,
        "Path" : "res/map/surface/02_obs_stone_012.png",
    },
    33239 : {
        "PicId" : 33239,
        "Path" : "res/map/surface/02_obs_stone_020.png",
    },
    910 : {
        "PicId" : 910,
        "Path" : "res/map/building/03_building_005.png",
    },
    33255 : {
        "PicId" : 33255,
        "Path" : "res/map/surface/03_obs_stone_007.png",
    },
    33263 : {
        "PicId" : 33263,
        "Path" : "res/map/surface/03_obs_stone_015.png",
    },
    33016 : {
        "PicId" : 33016,
        "Path" : "res/map/surface/02_nsur_grass_008.png",
    },
    33303 : {
        "Path" : "res/map/surface/01_obs_tree_003.png",
        "PicId" : 33303,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33311 : {
        "Path" : "res/map/surface/01_obs_tree_011.png",
        "PicId" : 33311,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33319 : {
        "PicId" : 33319,
        "Path" : "res/map/surface/02_obs_tree_003.png",
    },
    1500 : {
        "PicId" : 1500,
        "Path" : "res/map/building/shop001.png",
    },
    33104 : {
        "PicId" : 33104,
        "Path" : "res/map/surface/01_obs_edge_004.png",
    },
    1501 : {
        "Path" : "res/map/building/01_building_010.png",
        "PicId" : 1501,
        "MaskArea" : {
            1 : {
                1 : -1,
                2 : 1,
            },
            2 : {
                1 : 0,
                2 : 1,
            },
            3 : {
                1 : 1,
                2 : 0,
            },
            4 : {
                1 : 1,
                2 : 1,
            },
            5 : {
                1 : 1,
                2 : 2,
            },
            6 : {
                1 : 2,
                2 : 1,
            },
        },
    },
    33120 : {
        "PicId" : 33120,
        "Path" : "res/map/surface/01_obs_edge_020.png",
    },
    33128 : {
        "PicId" : 33128,
        "Path" : "res/map/surface/02_obs_edge_006.png",
    },
    33136 : {
        "PicId" : 33136,
        "Path" : "res/map/surface/02_obs_edge_014.png",
    },
    1502 : {
        "PicId" : 1502,
        "Path" : "res/map/building/02_building_009.png",
    },
    913 : {
        "PicId" : 913,
        "Path" : "res/map/building/03_building_008.png",
    },
    401 : {
        "Path" : "res/map/building/01_building_002.png",
        "PicId" : 401,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : -1,
            },
            3 : {
                1 : 1,
                2 : 0,
            },
            4 : {
                1 : 1,
                2 : 1,
            },
            5 : {
                1 : 1,
                2 : 2,
            },
            6 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33006 : {
        "PicId" : 33006,
        "Path" : "res/map/surface/01_nsur_grass_006.png",
    },
    33208 : {
        "PicId" : 33208,
        "Path" : "res/map/surface/01_obs_stone_008.png",
    },
    33216 : {
        "PicId" : 33216,
        "Path" : "res/map/surface/01_obs_stone_016.png",
    },
    103 : {
        "PicId" : 103,
        "Path" : "res/map/building/00_building_003.png",
    },
    33232 : {
        "PicId" : 33232,
        "Path" : "res/map/surface/02_obs_stone_013.png",
    },
    33240 : {
        "PicId" : 33240,
        "Path" : "res/map/surface/02_obs_stone_021.png",
    },
    33248 : {
        "PicId" : 33248,
        "Path" : "res/map/surface/02_obs_stone_029.png",
    },
    33001 : {
        "PicId" : 33001,
        "Path" : "res/map/surface/01_nsur_grass_001.png",
    },
    33009 : {
        "PicId" : 33009,
        "Path" : "res/map/surface/02_nsur_grass_001.png",
    },
    33017 : {
        "PicId" : 33017,
        "Path" : "res/map/surface/02_nsur_grass_009.png",
    },
    33246 : {
        "PicId" : 33246,
        "Path" : "res/map/surface/02_obs_stone_027.png",
    },
    902 : {
        "PicId" : 902,
        "Path" : "res/map/building/02_building_001.png",
    },
    3209 : {
        "PicId" : 3209,
        "Path" : "res/map/surface/01_sur_grass_003.png",
    },
    33304 : {
        "Path" : "res/map/surface/01_obs_tree_004.png",
        "PicId" : 33304,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33312 : {
        "Path" : "res/map/surface/01_obs_tree_012.png",
        "PicId" : 33312,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 3,
            },
            6 : {
                1 : 3,
                2 : 2,
            },
            7 : {
                1 : 3,
                2 : 3,
            },
        },
    },
    33320 : {
        "PicId" : 33320,
        "Path" : "res/map/surface/02_obs_tree_004.png",
    },
    912 : {
        "PicId" : 912,
        "Path" : "res/map/building/03_building_007.png",
    },
    3208 : {
        "PicId" : 3208,
        "Path" : "res/map/surface/01_sur_grass_002.png",
    },
    33257 : {
        "PicId" : 33257,
        "Path" : "res/map/surface/03_obs_stone_009.png",
    },
    3207 : {
        "PicId" : 3207,
        "Path" : "res/map/surface/01_sur_grass_001.png",
    },
    1700 : {
        "PicId" : 1700,
        "Path" : "res/map/building/portal001.png",
    },
    33113 : {
        "PicId" : 33113,
        "Path" : "res/map/surface/01_obs_edge_013.png",
    },
    33121 : {
        "PicId" : 33121,
        "Path" : "res/map/surface/01_obs_edge_021.png",
    },
    33129 : {
        "PicId" : 33129,
        "Path" : "res/map/surface/02_obs_edge_007.png",
    },
    1701 : {
        "Path" : "res/map/building/01_building_005.png",
        "PicId" : 1701,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
        },
    },
    33145 : {
        "PicId" : 33145,
        "Path" : "res/map/surface/03_obs_edge_006.png",
    },
    1702 : {
        "PicId" : 1702,
        "Path" : "res/map/building/02_building_006.png",
    },
    33265 : {
        "PicId" : 33265,
        "Path" : "res/map/surface/03_obs_stone_017.png",
    },
    300 : {
        "PicId" : 300,
        "Path" : "res/map/building/guaji1001.png",
    },
    33245 : {
        "PicId" : 33245,
        "Path" : "res/map/surface/02_obs_stone_026.png",
    },
    33256 : {
        "PicId" : 33256,
        "Path" : "res/map/surface/03_obs_stone_008.png",
    },
    1300 : {
        "PicId" : 1300,
        "Path" : "res/map/building/transport001.png",
    },
    33201 : {
        "Path" : "res/map/surface/01_obs_stone_001.png",
        "PicId" : 33201,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 2,
            },
            4 : {
                1 : 2,
                2 : 3,
            },
            5 : {
                1 : 3,
                2 : 2,
            },
            6 : {
                1 : 3,
                2 : 3,
            },
            7 : {
                1 : 3,
                2 : 4,
            },
            8 : {
                1 : 4,
                2 : 3,
            },
            9 : {
                1 : 4,
                2 : 4,
            },
        },
    },
    33209 : {
        "PicId" : 33209,
        "Path" : "res/map/surface/01_obs_stone_009.png",
    },
    33217 : {
        "PicId" : 33217,
        "Path" : "res/map/surface/01_obs_stone_017.png",
    },
    33225 : {
        "PicId" : 33225,
        "Path" : "res/map/surface/02_obs_stone_006.png",
    },
    33233 : {
        "PicId" : 33233,
        "Path" : "res/map/surface/02_obs_stone_014.png",
    },
    33241 : {
        "PicId" : 33241,
        "Path" : "res/map/surface/02_obs_stone_022.png",
    },
    33249 : {
        "PicId" : 33249,
        "Path" : "res/map/surface/03_obs_stone_001.png",
    },
    33002 : {
        "PicId" : 33002,
        "Path" : "res/map/surface/01_nsur_grass_002.png",
    },
    33010 : {
        "PicId" : 33010,
        "Path" : "res/map/surface/02_nsur_grass_002.png",
    },
    33018 : {
        "PicId" : 33018,
        "Path" : "res/map/surface/02_nsur_grass_010.png",
    },
    33262 : {
        "PicId" : 33262,
        "Path" : "res/map/surface/03_obs_stone_014.png",
    },
    10001 : {
        "PicId" : 10001,
        "Path" : "res/ui/picture/00_pic_buff_03.png",
    },
    301 : {
        "Path" : "res/map/building/01_building_003.png",
        "PicId" : 301,
        "MaskArea" : {
            1 : {
                1 : -1,
                2 : 1,
            },
            2 : {
                1 : 0,
                2 : 1,
            },
            3 : {
                1 : 1,
                2 : -1,
            },
            4 : {
                1 : 1,
                2 : 0,
            },
            5 : {
                1 : 1,
                2 : 1,
            },
            6 : {
                1 : 1,
                2 : 2,
            },
            7 : {
                1 : 2,
                2 : 0,
            },
            8 : {
                1 : 2,
                2 : 1,
            },
            9 : {
                1 : 2,
                2 : 2,
            },
            10 : {
                1 : 2,
                2 : 3,
            },
            11 : {
                1 : 3,
                2 : 2,
            },
        },
    },
    33305 : {
        "Path" : "res/map/surface/01_obs_tree_005.png",
        "PicId" : 33305,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 3,
            },
        },
    },
    33313 : {
        "Path" : "res/map/surface/01_obs_tree_013.png",
        "PicId" : 33313,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
        },
    },
    33321 : {
        "PicId" : 33321,
        "Path" : "res/map/surface/03_obs_tree_001.png",
    },
    3203 : {
        "PicId" : 3203,
        "Path" : "res/map/surface/01_sur_swamp_003.png",
    },
    500 : {
        "PicId" : 500,
        "Path" : "res/map/building/guaji3001.png",
    },
    199 : {
        "PicId" : 199,
        "Path" : "res/map/building/chest001.png",
    },
    3202 : {
        "PicId" : 3202,
        "Path" : "res/map/surface/01_sur_swamp_002.png",
    },
    601 : {
        "PicId" : 601,
        "Path" : "res/map/building/monsterchal002.png",
    },
    10000 : {
        "PicId" : 10000,
        "Path" : "res/ui/picture/00_pic_buff_02.png",
    },
    33122 : {
        "PicId" : 33122,
        "Path" : "res/map/surface/01_obs_edge_022.png",
    },
    33130 : {
        "PicId" : 33130,
        "Path" : "res/map/surface/02_obs_edge_008.png",
    },
    33138 : {
        "PicId" : 33138,
        "Path" : "res/map/surface/02_obs_edge_016.png",
    },
    33146 : {
        "PicId" : 33146,
        "Path" : "res/map/surface/03_obs_edge_007.png",
    },
    900 : {
        "PicId" : 900,
        "Path" : "res/map/building/unknow001.png",
    },
    3201 : {
        "PicId" : 3201,
        "Path" : "res/map/surface/01_sur_grass_01.png",
    },
    1200 : {
        "PicId" : 1200,
        "Path" : "res/map/building/buffstation001.png",
    },
    700 : {
        "PicId" : 700,
        "Path" : "res/map/building/monsterchoo001.png",
    },
    33014 : {
        "PicId" : 33014,
        "Path" : "res/map/surface/02_nsur_grass_006.png",
    },
    33015 : {
        "PicId" : 33015,
        "Path" : "res/map/surface/02_nsur_grass_007.png",
    },
    1201 : {
        "PicId" : 1201,
        "Path" : "res/map/building/buffstation002.png",
    },
    33210 : {
        "PicId" : 33210,
        "Path" : "res/map/surface/01_obs_stone_010.png",
    },
    33218 : {
        "PicId" : 33218,
        "Path" : "res/map/surface/01_obs_stone_018.png",
    },
    104 : {
        "PicId" : 104,
        "Path" : "res/map/building/00_building_004.png",
    },
    1202 : {
        "PicId" : 1202,
        "Path" : "res/map/building/01_building_011.png",
    },
    33242 : {
        "PicId" : 33242,
        "Path" : "res/map/surface/02_obs_stone_023.png",
    },
    33250 : {
        "PicId" : 33250,
        "Path" : "res/map/surface/03_obs_stone_002.png",
    },
    33258 : {
        "PicId" : 33258,
        "Path" : "res/map/surface/03_obs_stone_010.png",
    },
    1203 : {
        "PicId" : 1203,
        "Path" : "res/map/building/02_building_007.png",
    },
    33011 : {
        "PicId" : 33011,
        "Path" : "res/map/surface/02_nsur_grass_003.png",
    },
    33105 : {
        "PicId" : 33105,
        "Path" : "res/map/surface/01_obs_edge_005.png",
    },
    33106 : {
        "PicId" : 33106,
        "Path" : "res/map/surface/01_obs_edge_006.png",
    },
    1204 : {
        "PicId" : 1204,
        "Path" : "res/map/building/02_building_008.png",
    },
    33306 : {
        "PicId" : 33306,
        "Path" : "res/map/surface/01_obs_tree_006.png",
    },
    33314 : {
        "Path" : "res/map/surface/01_obs_tree_014.png",
        "PicId" : 33314,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 2,
            },
            4 : {
                1 : 2,
                2 : 3,
            },
            5 : {
                1 : 3,
                2 : 3,
            },
            6 : {
                1 : 3,
                2 : 4,
            },
            7 : {
                1 : 4,
                2 : 4,
            },
            8 : {
                1 : 4,
                2 : 5,
            },
        },
    },
    33322 : {
        "PicId" : 33322,
        "Path" : "res/map/surface/03_obs_tree_002.png",
    },
    33230 : {
        "PicId" : 33230,
        "Path" : "res/map/surface/02_obs_stone_011.png",
    },
    33112 : {
        "PicId" : 33112,
        "Path" : "res/map/surface/01_obs_edge_012.png",
    },
    200 : {
        "PicId" : 200,
        "Path" : "res/map/building/chestchoo001.png",
    },
    33114 : {
        "PicId" : 33114,
        "Path" : "res/map/surface/01_obs_edge_014.png",
    },
    33107 : {
        "PicId" : 33107,
        "Path" : "res/map/surface/01_obs_edge_007.png",
    },
    33115 : {
        "PicId" : 33115,
        "Path" : "res/map/surface/01_obs_edge_015.png",
    },
    33123 : {
        "PicId" : 33123,
        "Path" : "res/map/surface/02_obs_edge_001.png",
    },
    33131 : {
        "PicId" : 33131,
        "Path" : "res/map/surface/02_obs_edge_009.png",
    },
    33139 : {
        "PicId" : 33139,
        "Path" : "res/map/surface/02_obs_edge_017.png",
    },
    33012 : {
        "PicId" : 33012,
        "Path" : "res/map/surface/02_nsur_grass_004.png",
    },
    33247 : {
        "PicId" : 33247,
        "Path" : "res/map/surface/02_obs_stone_028.png",
    },
    33013 : {
        "PicId" : 33013,
        "Path" : "res/map/surface/02_nsur_grass_005.png",
    },
    33005 : {
        "PicId" : 33005,
        "Path" : "res/map/surface/01_nsur_grass_005.png",
    },
    1601 : {
        "Path" : "res/map/building/01_building_007.png",
        "PicId" : 1601,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 3,
                2 : 3,
            },
        },
    },
    1101 : {
        "Path" : "res/map/building/01_building_008.png",
        "PicId" : 1101,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
        },
    },
    1400 : {
        "PicId" : 1400,
        "Path" : "res/map/building/intelligence001.png",
    },
    33203 : {
        "Path" : "res/map/surface/01_obs_stone_003.png",
        "PicId" : 33203,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 0,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33211 : {
        "PicId" : 33211,
        "Path" : "res/map/surface/01_obs_stone_011.png",
    },
    400 : {
        "PicId" : 400,
        "Path" : "res/map/building/guaji2001.png",
    },
    33227 : {
        "PicId" : 33227,
        "Path" : "res/map/surface/02_obs_stone_008.png",
    },
    33235 : {
        "PicId" : 33235,
        "Path" : "res/map/surface/02_obs_stone_016.png",
    },
    33243 : {
        "PicId" : 33243,
        "Path" : "res/map/surface/02_obs_stone_024.png",
    },
    33251 : {
        "PicId" : 33251,
        "Path" : "res/map/surface/03_obs_stone_003.png",
    },
    33259 : {
        "PicId" : 33259,
        "Path" : "res/map/surface/03_obs_stone_011.png",
    },
    33267 : {
        "PicId" : 33267,
        "Path" : "res/map/surface/03_obs_stone_019.png",
    },
    33220 : {
        "PicId" : 33220,
        "Path" : "res/map/surface/02_obs_stone_001.png",
    },
    105 : {
        "PicId" : 105,
        "Path" : "res/map/building/00_building_005.png",
    },
    101 : {
        "PicId" : 101,
        "Path" : "res/map/building/00_building_001.png",
    },
    33219 : {
        "PicId" : 33219,
        "Path" : "res/map/surface/01_obs_stone_019.png",
    },
    33307 : {
        "PicId" : 33307,
        "Path" : "res/map/surface/01_obs_tree_007.png",
    },
    33315 : {
        "Path" : "res/map/surface/01_obs_tree_015.png",
        "PicId" : 33315,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 0,
            },
            2 : {
                1 : 1,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33206 : {
        "PicId" : 33206,
        "Path" : "res/map/surface/01_obs_stone_006.png",
    },
    600 : {
        "PicId" : 600,
        "Path" : "res/map/building/monsterchal001.png",
    },
    33137 : {
        "PicId" : 33137,
        "Path" : "res/map/surface/02_obs_edge_015.png",
    },
    800 : {
        "PicId" : 800,
        "Path" : "res/map/building/mission001.png",
    },
    33264 : {
        "PicId" : 33264,
        "Path" : "res/map/surface/03_obs_stone_016.png",
    },
    33108 : {
        "PicId" : 33108,
        "Path" : "res/map/surface/01_obs_edge_008.png",
    },
    33116 : {
        "PicId" : 33116,
        "Path" : "res/map/surface/01_obs_edge_016.png",
    },
    33124 : {
        "PicId" : 33124,
        "Path" : "res/map/surface/02_obs_edge_002.png",
    },
    33132 : {
        "PicId" : 33132,
        "Path" : "res/map/surface/02_obs_edge_010.png",
    },
    33140 : {
        "PicId" : 33140,
        "Path" : "res/map/surface/03_obs_edge_001.png",
    },
    33142 : {
        "PicId" : 33142,
        "Path" : "res/map/surface/03_obs_edge_003.png",
    },
    801 : {
        "Path" : "res/map/building/01_building_012.png",
        "PicId" : 801,
        "MaskArea" : {
            1 : {
                1 : -1,
                2 : 1,
            },
            2 : {
                1 : 0,
                2 : 1,
            },
            3 : {
                1 : 1,
                2 : 0,
            },
            4 : {
                1 : 1,
                2 : 1,
            },
            5 : {
                1 : 1,
                2 : 2,
            },
            6 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33144 : {
        "PicId" : 33144,
        "Path" : "res/map/surface/03_obs_edge_005.png",
    },
    33202 : {
        "Path" : "res/map/surface/01_obs_stone_002.png",
        "PicId" : 33202,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 1,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 1,
            },
            6 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    201 : {
        "PicId" : 201,
        "Path" : "res/map/building/01_building_004.png",
    },
    33224 : {
        "PicId" : 33224,
        "Path" : "res/map/surface/02_obs_stone_005.png",
    },
    911 : {
        "PicId" : 911,
        "Path" : "res/map/building/03_building_006.png",
    },
    33204 : {
        "PicId" : 33204,
        "Path" : "res/map/surface/01_obs_stone_004.png",
    },
    33212 : {
        "PicId" : 33212,
        "Path" : "res/map/surface/01_obs_stone_012.png",
    },
    1600 : {
        "PicId" : 1600,
        "Path" : "res/map/building/watchtower001.png",
    },
    33228 : {
        "PicId" : 33228,
        "Path" : "res/map/surface/02_obs_stone_009.png",
    },
    33236 : {
        "PicId" : 33236,
        "Path" : "res/map/surface/02_obs_stone_017.png",
    },
    33244 : {
        "PicId" : 33244,
        "Path" : "res/map/surface/02_obs_stone_025.png",
    },
    33252 : {
        "PicId" : 33252,
        "Path" : "res/map/surface/03_obs_stone_004.png",
    },
    33260 : {
        "PicId" : 33260,
        "Path" : "res/map/surface/03_obs_stone_012.png",
    },
    33268 : {
        "PicId" : 33268,
        "Path" : "res/map/surface/03_obs_stone_020.png",
    },
    33222 : {
        "PicId" : 33222,
        "Path" : "res/map/surface/02_obs_stone_003.png",
    },
    1602 : {
        "PicId" : 1602,
        "Path" : "res/map/building/02_building_004.png",
    },
    33004 : {
        "PicId" : 33004,
        "Path" : "res/map/surface/01_nsur_grass_004.png",
    },
    1401 : {
        "Path" : "res/map/building/01_building_013.png",
        "PicId" : 1401,
        "MaskArea" : {
            1 : {
                1 : -1,
                2 : 1,
            },
            2 : {
                1 : 0,
                2 : 1,
            },
            3 : {
                1 : 0,
                2 : 2,
            },
            4 : {
                1 : 1,
                2 : -1,
            },
            5 : {
                1 : 1,
                2 : 0,
            },
            6 : {
                1 : 1,
                2 : 1,
            },
            7 : {
                1 : 1,
                2 : 2,
            },
            8 : {
                1 : 2,
                2 : 1,
            },
            9 : {
                1 : 2,
                2 : 2,
            },
            10 : {
                1 : 2,
                2 : 3,
            },
            11 : {
                1 : 3,
                2 : 3,
            },
        },
    },
    33308 : {
        "Path" : "res/map/surface/01_obs_tree_008.png",
        "PicId" : 33308,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 3,
            },
            4 : {
                1 : 3,
                2 : 2,
            },
            5 : {
                1 : 3,
                2 : 3,
            },
            6 : {
                1 : 4,
                2 : 2,
            },
            7 : {
                1 : 4,
                2 : 3,
            },
        },
    },
    33234 : {
        "PicId" : 33234,
        "Path" : "res/map/surface/02_obs_stone_015.png",
    },
    33119 : {
        "PicId" : 33119,
        "Path" : "res/map/surface/01_obs_edge_019.png",
    },
    33266 : {
        "PicId" : 33266,
        "Path" : "res/map/surface/03_obs_stone_018.png",
    },
    33226 : {
        "PicId" : 33226,
        "Path" : "res/map/surface/02_obs_stone_007.png",
    },
    33118 : {
        "PicId" : 33118,
        "Path" : "res/map/surface/01_obs_edge_018.png",
    },
    33101 : {
        "PicId" : 33101,
        "Path" : "res/map/surface/01_obs_edge_001.png",
    },
    33109 : {
        "Path" : "res/map/surface/01_obs_edge_009.png",
        "PicId" : 33109,
        "MaskArea" : {
            1 : {
                1 : 2,
                2 : 0,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 3,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 3,
                2 : 2,
            },
            6 : {
                1 : 1,
                2 : 2,
            },
            7 : {
                1 : 0,
                2 : 2,
            },
            8 : {
                1 : 1,
                2 : 3,
            },
            9 : {
                1 : 2,
                2 : 3,
            },
            10 : {
                1 : 3,
                2 : 3,
            },
            11 : {
                1 : 4,
                2 : 3,
            },
            12 : {
                1 : 3,
                2 : 4,
            },
        },
    },
    33117 : {
        "PicId" : 33117,
        "Path" : "res/map/surface/01_obs_edge_017.png",
    },
    33125 : {
        "PicId" : 33125,
        "Path" : "res/map/surface/02_obs_edge_003.png",
    },
    33133 : {
        "PicId" : 33133,
        "Path" : "res/map/surface/02_obs_edge_011.png",
    },
    33141 : {
        "PicId" : 33141,
        "Path" : "res/map/surface/03_obs_edge_002.png",
    },
    33003 : {
        "PicId" : 33003,
        "Path" : "res/map/surface/01_nsur_grass_003.png",
    },
    3204 : {
        "PicId" : 3204,
        "Path" : "res/map/surface/01_sur_swamp_004.png",
    },
    907 : {
        "PicId" : 907,
        "Path" : "res/map/building/03_building_002.png",
    },
    3205 : {
        "PicId" : 3205,
        "Path" : "res/map/surface/01_sur_swamp_005.png",
    },
    901 : {
        "Path" : "res/map/building/01_building_009.png",
        "PicId" : 901,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
        },
    },
    3206 : {
        "PicId" : 3206,
        "Path" : "res/map/surface/01_sur_swamp_006.png",
    },
    903 : {
        "PicId" : 903,
        "Path" : "res/map/building/02_building_002.png",
    },
    33205 : {
        "PicId" : 33205,
        "Path" : "res/map/surface/01_obs_stone_005.png",
    },
    33213 : {
        "PicId" : 33213,
        "Path" : "res/map/surface/01_obs_stone_013.png",
    },
    33221 : {
        "PicId" : 33221,
        "Path" : "res/map/surface/02_obs_stone_002.png",
    },
    33229 : {
        "PicId" : 33229,
        "Path" : "res/map/surface/02_obs_stone_010.png",
    },
    33237 : {
        "PicId" : 33237,
        "Path" : "res/map/surface/02_obs_stone_018.png",
    },
    1800 : {
        "PicId" : 1800,
        "Path" : "res/map/building/postbox001.png",
    },
    33253 : {
        "PicId" : 33253,
        "Path" : "res/map/surface/03_obs_stone_005.png",
    },
    33261 : {
        "PicId" : 33261,
        "Path" : "res/map/surface/03_obs_stone_013.png",
    },
    33008 : {
        "PicId" : 33008,
        "Path" : "res/map/surface/01_nsur_grass_008.png",
    },

};
module.exports = _p;
