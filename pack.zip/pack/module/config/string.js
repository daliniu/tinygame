/*
Don't modify this file manually!
*/
var _p = {
    "sub" : function: 0024A8D0,
    "upper" : function: 0024A910,
    "len" : function: 0024A790,
    "gfind" : function: 0024A710,
    "rep" : function: 0024A850,
    "find" : function: 0024A650,
    "match" : function: 0024A810,
    "char" : function: 0024A5D0,
    "dump" : function: 0024A610,
    "gmatch" : function: 0024A710,
    "reverse" : function: 0024A890,
    "byte" : function: 0024A590,
    "format" : function: 0024A690,
    "gsub" : function: 0024A750,
    "lower" : function: 0024A7D0,

};
module.exports = _p;
