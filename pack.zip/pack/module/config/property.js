/*
Don't modify this file manually!
*/
var _p = {
    8003 : {
        "ID" : 8003,
        "desc" : "暴击率",
    },
    8005 : {
        "ID" : 8005,
        "desc" : "生命上限",
    },
    8002 : {
        "ID" : 8002,
        "desc" : "防御力",
    },
    8004 : {
        "ID" : 8004,
        "desc" : "闪避率",
    },
    8001 : {
        "ID" : 8001,
        "desc" : "攻击力",
    },

};
module.exports = _p;
