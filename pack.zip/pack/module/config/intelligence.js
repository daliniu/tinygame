/*
Don't modify this file manually!
*/
var _p = {
    14001 : {
        "InteACount" : {
            1 : {
                1 : {
                    1 : 1,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            2 : {
                1 : {
                    1 : 2,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            3 : {
                1 : {
                    1 : 3,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
        },
        "ElementType" : 14,
        "Pic1" : 1400,
        "Genre" : 4,
        "Desc1" : 1400,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "RestrictLose" : 0,
        "RestrictStep" : 0,
        "Id" : 14001,
        "GetInto" : 1,
        "Name" : "情报站",
        "Obstacle" : 0,
        "Resetting" : 0,
        "RestrictSuc" : 0,
        "PickupLived" : 1,
        "Pic2" : 1400,
    },
    14002 : {
        "InteACount" : {
            1 : {
                1 : {
                    1 : 1,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            2 : {
                1 : {
                    1 : 2,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            3 : {
                1 : {
                    1 : 3,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
        },
        "ElementType" : 14,
        "Pic1" : 1401,
        "Genre" : 4,
        "Desc1" : 1400,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "RestrictLose" : 0,
        "RestrictStep" : 0,
        "Id" : 14002,
        "GetInto" : 1,
        "Name" : "情报站",
        "Obstacle" : 0,
        "Resetting" : 0,
        "RestrictSuc" : 0,
        "PickupLived" : 1,
        "Pic2" : 1401,
    },

};
module.exports = _p;
