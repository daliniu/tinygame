/*
Don't modify this file manually!
*/
var _p = {
    "tbCapInsets" : {
        1 : 15,
        2 : 30,
        3 : 1,
        4 : 1,
    },
    "nTime" : 0.5,
    "tbColorBlue" : {
        1 : 0,
        2 : 153,
        3 : 255,
    },
    "tbColorRed" : {
        1 : 255,
        2 : 110,
        3 : 0,
    },
    "nSpace" : 10,
    "szPath1" : "res/ui/03_fightUI/03_bg_oursidetext_01.png",
    "nWidthModify" : 40,
    "nFontScale" : 0.8,
    "tbContentSize" : {
        1 : 33,
        2 : 37,
    },
    "szPath2" : "res/ui/03_fightUI/03_bg_enemysidetext_01.png",
    "nWidth" : 530,
    "nHeightModify" : 10,
    "szPath3" : "res/ui/00/00_ico_crystal_01.png",
    "szPath4" : "res/ui/font/txt00.fnt",
    "nStartHeight" : 15,
    "nMaxNums" : 30,
    "tbCastText" : {
        1 : "触发了",
        2 : "释放了",
    },

};
module.exports = _p;
