/*
Don't modify this file manually!
*/
var _p = {
    7001 : {
        "StepCost" : 5,
        "ElementType" : 7,
        "Pic1" : 700,
        "Genre" : 3,
        "Desc1" : 700,
        "Value" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Monster" : 1,
        "PickupLived" : 0,
        "RestrictStep" : 0,
        "Id" : 7001,
        "GetInto" : 1,
        "Obstacle" : 1,
        "Name" : "缺银子的小偷",
        "Resetting" : 0,
        "DirTrigger" : 0,
        "RestrictSuc" : 0,
        "Pic2" : 700,
        "RestrictLose" : 0,
    },

};
module.exports = _p;
