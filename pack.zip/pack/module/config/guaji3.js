/*
Don't modify this file manually!
*/
var _p = {
    5001 : {
        "Benefit" : {
            1 : 10001,
            2 : 5,
        },
        "ElementType" : 5,
        "Pic1" : 500,
        "Genre" : 2,
        "Desc3" : 500,
        "Desc4" : 500,
        "Time" : 1800,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "Monster" : 1,
        "PickupLived" : 1,
        "Pic2" : 1000,
        "Obstacle" : 0,
        "Id" : 5001,
        "PicType" : "1；1,2,x,y",
        "GetInto" : 1,
        "Resetting" : 0,
        "RestrictStep" : 0,
        "Precondition" : 0,
        "Name" : "庙宇",
        "Desc2" : 500,
        "DirTrigger" : 0,
        "RestrictSuc" : 0,
        "RestrictLose" : 0,
        "Desc1" : 500,
    },

};
module.exports = _p;
