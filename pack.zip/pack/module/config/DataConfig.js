/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "id" : 1,
        "isMapInfo" : {
            1 : 1,
            2 : 0,
        },
        "isSession" : 1,
        "isTeamHeroList" : {
            1 : 0,
            2 : 0,
        },
        "isBaseInfo" : {
            1 : 0,
            2 : 0,
        },
        "isBagList" : {
            1 : 0,
            2 : 0,
        },
        "funcName" : "getRewardTime",
        "isHeroInfo" : {
            1 : 0,
            2 : 0,
        },
        "isHeroInfoList" : {
            1 : 0,
            2 : 0,
        },
        "isAfkInfo" : {
            1 : 1,
            2 : 0,
        },
    },
    0 : {
        "id" : 0,
        "isMapInfo" : {
            1 : 1,
            2 : 1,
            3 : "mapId",
        },
        "isSession" : 1,
        "isTeamHeroList" : {
            1 : 0,
            2 : 0,
        },
        "isBaseInfo" : {
            1 : 1,
            2 : 1,
        },
        "isBagList" : {
            1 : 1,
            2 : 1,
        },
        "funcName" : "getPresent",
        "isHeroInfo" : {
            1 : 0,
            2 : 0,
            3 : "heroId",
        },
        "isHeroInfoList" : {
            1 : 0,
            2 : 0,
        },
        "isAfkInfo" : {
            1 : 1,
            2 : 1,
        },
    },

};
module.exports = _p;

