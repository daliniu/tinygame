/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "starLv" : 1,
        "itemId" : 15101,
        "itemNum" : 20,
        "gold" : 20000,
    },
    2 : {
        "starLv" : 2,
        "itemId" : 15102,
        "itemNum" : 20,
        "gold" : 20000,
    },
    3 : {
        "starLv" : 3,
        "itemId" : 15102,
        "itemNum" : 20,
        "gold" : 20000,
    },
    4 : {
        "starLv" : 4,
        "itemId" : 15101,
        "itemNum" : 20,
        "gold" : 20000,
    },
    5 : {
        "starLv" : 5,
        "itemId" : 15102,
        "itemNum" : 20,
        "gold" : 20000,
    },

};
module.exports = _p;
