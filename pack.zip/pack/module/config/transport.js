/*
Don't modify this file manually!
*/
var _p = {
    13001 : {
        "ElementType" : 13,
        "Pic1" : 1300,
        "Genre" : 4,
        "Desc1" : 1300,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "TranACount" : {
            1 : {
                1 : {
                    1 : 1,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            2 : {
                1 : {
                    1 : 2,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            3 : {
                1 : {
                    1 : 3,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
        },
        "RestrictStep" : 0,
        "Id" : 13001,
        "GetInto" : 1,
        "Obstacle" : 0,
        "Name" : "交通站",
        "Resetting" : 0,
        "PickupLived" : 1,
        "RestrictSuc" : 0,
        "Pic2" : 1300,
        "RestrictLose" : 0,
    },
    13002 : {
        "ElementType" : 13,
        "Pic1" : 1301,
        "Genre" : 4,
        "Desc1" : 1300,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "TranACount" : {
            1 : {
                1 : {
                    1 : 1,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            2 : {
                1 : {
                    1 : 2,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
            3 : {
                1 : {
                    1 : 3,
                },
                2 : {
                    1 : 1,
                    2 : 1,
                },
            },
        },
        "RestrictStep" : 0,
        "Id" : 13002,
        "GetInto" : 1,
        "Obstacle" : 0,
        "Name" : "交通站",
        "Resetting" : 0,
        "PickupLived" : 1,
        "RestrictSuc" : 0,
        "Pic2" : 1301,
        "RestrictLose" : 0,
    },

};
module.exports = _p;
