/*
Don't modify this file manually!
*/
var _p = {
    17001 : {
        "ElementType" : 17,
        "Pic1" : 1700,
        "Genre" : 5,
        "Desc1" : 1700,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Map" : 0,
        "RestrictLose" : 0,
        "Portal" : 0,
        "Id" : 17001,
        "GetInto" : 1,
        "Obstacle" : 0,
        "Name" : "1号传送门",
        "PickupLived" : 1,
        "Pic2" : 1700,
        "RestrictSuc" : 0,
        "Resetting" : 0,
        "RestrictStep" : 0,
    },
    17002 : {
        "ElementType" : 17,
        "Pic1" : 1701,
        "Genre" : 5,
        "Desc1" : 1700,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "Map" : 0,
        "RestrictLose" : 0,
        "Portal" : 0,
        "Id" : 17002,
        "GetInto" : 1,
        "Obstacle" : 0,
        "Name" : "1号传送门",
        "PickupLived" : 1,
        "Pic2" : 1701,
        "RestrictSuc" : 0,
        "Resetting" : 0,
        "RestrictStep" : 0,
    },

};
module.exports = _p;
