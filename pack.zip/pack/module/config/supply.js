/*
Don't modify this file manually!
*/
var _p = {
    11001 : {
        "Id" : 11001,
        "PickupLived" : 1,
        "Pic2" : 1100,
        "ElementType" : 11,
        "Price" : 50,
        "Pic1" : 1100,
        "Genre" : 4,
        "RestrictStep" : 0,
        "GetInto" : 1,
        "Desc1" : 1100,
        "Obstacle" : 0,
        "Name" : "补给站",
        "Resetting" : 0,
        "RestrictSuc" : 0,
        "RestrictLose" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
    },
    11002 : {
        "Id" : 11002,
        "PickupLived" : 1,
        "Pic2" : 1101,
        "ElementType" : 11,
        "Price" : 50,
        "Pic1" : 1101,
        "Genre" : 4,
        "RestrictStep" : 0,
        "GetInto" : 1,
        "Desc1" : 1100,
        "Obstacle" : 0,
        "Name" : "补给站",
        "Resetting" : 0,
        "RestrictSuc" : 0,
        "RestrictLose" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
    },

};
module.exports = _p;
