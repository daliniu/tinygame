/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "Id" : 1,
        "Desc" : "附近宝箱可以找到。",
        "Name" : "红钥匙",
        "Pic" : "res/ui/picture/item/item_specialitem_01.png",
    },
    2 : {
        "Id" : 2,
        "Desc" : "在瀑布可以找到。",
        "Name" : "绿钥匙",
        "Pic" : "res/ui/picture/item/item_specialitem_01.png",
    },
    3 : {
        "Id" : 3,
        "Desc" : "听村里的老人说神秘的石屋曾经出现过。",
        "Name" : "黄钥匙",
        "Pic" : "res/ui/picture/item/item_specialitem_01.png",
    },

};
module.exports = _p;
