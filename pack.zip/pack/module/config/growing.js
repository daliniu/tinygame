/*
Don't modify this file manually!
*/
var _p = {
    1001 : {
        "stargrowing" : {
            1 : 10,
            2 : 10,
            3 : 20,
        },
        "levelgrowing" : {
            1 : 50,
            2 : 50,
            3 : 100,
        },
        "id" : 1001,
        "scrapamount" : {
            1 : 20,
            2 : 40,
            3 : 60,
            4 : 80,
            5 : 150,
        },
        "qualityamount" : {
            1 : 1000,
            2 : 2000,
            3 : 4000,
            4 : 8000,
            5 : 15000,
        },
        "qualityskill" : {
            1 : 0,
            2 : 0,
            3 : 0,
            4 : 0,
            5 : 0,
        },
    },

};
module.exports = _p;
