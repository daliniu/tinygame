/*
Don't modify this file manually!
*/
var _p = {
    18001 : {
        "Letter" : 0,
        "Pic1" : 1800,
        "Genre" : 6,
        "Desc1" : 1800,
        "Value" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "RestrictLose" : 0,
        "RestrictStep" : 0,
        "Id" : 18001,
        "GetInto" : 1,
        "Name" : "邮筒",
        "Resetting" : 0,
        "Obstacle" : 0,
        "PickupLived" : 0,
        "Pic2" : 1800,
        "RestrictSuc" : 0,
        "ElementType" : 18,
        "Reward" : 10001,
    },
    18002 : {
        "Letter" : 0,
        "Pic1" : 1801,
        "Genre" : 6,
        "Desc1" : 1800,
        "Value" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "RestrictLose" : 0,
        "RestrictStep" : 0,
        "Id" : 18002,
        "GetInto" : 1,
        "Name" : "邮筒",
        "Resetting" : 0,
        "Obstacle" : 0,
        "PickupLived" : 0,
        "Pic2" : 1801,
        "RestrictSuc" : 0,
        "ElementType" : 18,
        "Reward" : 10001,
    },

};
module.exports = _p;
