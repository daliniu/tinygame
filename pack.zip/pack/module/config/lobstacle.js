/*
Don't modify this file manually!
*/
var _p = {
    32003 : {
        "PickupLived" : 0,
        "PosY" : 0,
        "LandType" : 3,
        "Id" : 32003,
        "PlayType" : 2,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "ElementType" : 32,
        "Name" : "高级可除草丛",
        "Obstacle" : 2,
        "PosX" : 0,
        "Genre" : 11,
        "ToItem" : 10003,
        "Effect" : 60031,
        "Pic" : 3209,
    },
    32001 : {
        "PickupLived" : 0,
        "PosY" : 0,
        "LandType" : 1,
        "Id" : 32001,
        "PlayType" : 2,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "ElementType" : 32,
        "Name" : "初级可除草丛",
        "Obstacle" : 2,
        "PosX" : 0,
        "Genre" : 11,
        "ToItem" : 10001,
        "Effect" : 60031,
        "Pic" : 3207,
    },
    32002 : {
        "PickupLived" : 0,
        "PosY" : 0,
        "LandType" : 2,
        "Id" : 32002,
        "PlayType" : 2,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "ElementType" : 32,
        "Name" : "中级可除草丛",
        "Obstacle" : 2,
        "PosX" : 0,
        "Genre" : 11,
        "ToItem" : 10002,
        "Effect" : 60031,
        "Pic" : 3208,
    },

};
module.exports = _p;
