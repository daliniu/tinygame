/*
Don't modify this file manually!
*/
var _p = {
    "tbGlobal" : {
        "TOUCH_BUTTON_OVER" : 3,
        "TOUCH_PNL_STATE" : 1,
        "DEFAULT" : 0,
        "TOUCH_BUTTON_SPEED" : 2,
        "TOUCH_BUTTON_NPC" : 1,
    },
    "tbLocal" : {
        "DEFAULT" : 0,
        "PNL_SHIP_HIGHER" : 1,
        "PNL_SHIP_STATE" : 150,
        "PNL_SHIP_NPC" : 100,
        "ARMATURE_COMBO" : 1,
        "PNL_SHIP_MASK" : 99,
        "PNL_EFFECT" : 50,
        "PNL_SHIP_ROUND" : 200,
        "PNL_SHIP_HP" : 100,
        "PNL_AFK_STATISTICS" : 201,
    },

};
module.exports = _p;
