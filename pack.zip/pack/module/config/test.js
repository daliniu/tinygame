/*
Don't modify this file manually!
*/
var _p = {
    10002 : {
        "test3" : {
            1 : 7,
            2 : 8,
            3 : 9,
        },
        "test1" : 10002,
        "test2" : "测试1003",
    },
    10001 : {
        "test3" : {
            1 : 4,
            2 : 5,
            3 : 6,
        },
        "test1" : 10001,
        "test2" : "测试1002",
    },
    10000 : {
        "test3" : {
            1 : 1,
            2 : 2,
            3 : 3,
        },
        "test1" : 10000,
        "test2" : "测试10001",
    },

};
module.exports = _p;
