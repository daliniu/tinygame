/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "level" : 0,
        "time" : 0,
        "channel" : 1,
    },
    2 : {
        "level" : 0,
        "time" : 0,
        "channel" : 2,
    },
    3 : {
        "level" : 0,
        "time" : 0,
        "channel" : 3,
    },
    4 : {
        "level" : 0,
        "time" : 30,
        "channel" : 4,
    },
    5 : {
        "level" : 0,
        "time" : 0,
        "channel" : 5,
    },
    6 : {
        "level" : 0,
        "time" : 0,
        "channel" : 6,
    },

};
module.exports = _p;
