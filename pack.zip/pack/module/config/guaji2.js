/*
Don't modify this file manually!
*/
var _p = {
    4001 : {
        "Benefit" : {
            1 : 10006,
            2 : 5,
        },
        "ElementType" : 4,
        "Pic1" : 400,
        "Genre" : 2,
        "Desc4" : 402,
        "Desc1" : 400,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "PickupLived" : 1,
        "Pic2" : 1000,
        "Id" : 4001,
        "PicType" : "1；1,2,x,y",
        "GetInto" : 1,
        "Obstacle" : 0,
        "Resetting" : 0,
        "Precondition" : 0,
        "Name" : "洞天福地",
        "Desc2" : 401,
        "RestrictStep" : 0,
        "RestrictSuc" : 0,
        "RestrictLose" : 0,
        "Time" : 240,
    },
    4002 : {
        "Benefit" : {
            1 : 10006,
            2 : 5,
        },
        "ElementType" : 4,
        "Pic1" : 401,
        "Genre" : 2,
        "Desc4" : 402,
        "Desc1" : 400,
        "Value" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "PickupLived" : 1,
        "Pic2" : 1000,
        "Id" : 4002,
        "PicType" : "1；1,2,x,y",
        "GetInto" : 1,
        "Obstacle" : 0,
        "Resetting" : 0,
        "Precondition" : 0,
        "Name" : "练武场",
        "Desc2" : 401,
        "RestrictStep" : 0,
        "RestrictSuc" : 0,
        "RestrictLose" : 0,
        "Time" : 240,
    },

};
module.exports = _p;
