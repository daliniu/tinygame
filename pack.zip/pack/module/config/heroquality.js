/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "def" : 20,
        "quality" : 1,
        "lv" : 10,
        "hp" : 20,
        "ap" : 20,
    },
    2 : {
        "def" : 20,
        "quality" : 2,
        "lv" : 10,
        "hp" : 20,
        "ap" : 20,
    },
    3 : {
        "def" : 50,
        "quality" : 3,
        "lv" : 20,
        "hp" : 50,
        "ap" : 50,
    },
    4 : {
        "def" : 50,
        "quality" : 4,
        "lv" : 20,
        "hp" : 50,
        "ap" : 50,
    },
    5 : {
        "def" : 50,
        "quality" : 5,
        "lv" : 20,
        "hp" : 50,
        "ap" : 50,
    },
    6 : {
        "def" : 50,
        "quality" : 6,
        "lv" : 20,
        "hp" : 50,
        "ap" : 50,
    },
    7 : {
        "def" : 50,
        "quality" : 7,
        "lv" : 30,
        "hp" : 50,
        "ap" : 50,
    },
    8 : {
        "def" : 50,
        "quality" : 8,
        "lv" : 30,
        "hp" : 50,
        "ap" : 50,
    },
    9 : {
        "def" : 50,
        "quality" : 9,
        "lv" : 30,
        "hp" : 50,
        "ap" : 50,
    },
    10 : {
        "def" : 50,
        "quality" : 10,
        "lv" : 30,
        "hp" : 50,
        "ap" : 50,
    },
    11 : {
        "def" : 50,
        "quality" : 11,
        "lv" : 30,
        "hp" : 50,
        "ap" : 50,
    },
    12 : {
        "def" : 50,
        "quality" : 12,
        "lv" : 30,
        "hp" : 50,
        "ap" : 50,
    },
    13 : {
        "def" : 50,
        "quality" : 13,
        "lv" : 40,
        "hp" : 50,
        "ap" : 50,
    },

};
module.exports = _p;
