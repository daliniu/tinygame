/*
Don't modify this file manually!
*/
var _p = {
    33101 : {
        "Path" : "res/map/surface/01_obs_edge_001.png",
        "PicId" : 33101,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 1,
        },
        "YOffset" : 160,
    },
    33103 : {
        "Path" : "res/map/surface/01_obs_edge_003.png",
        "PicId" : 33103,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 152,
    },
    33105 : {
        "Path" : "res/map/surface/01_obs_edge_005.png",
        "PicId" : 33105,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 158,
    },
    33107 : {
        "Path" : "res/map/surface/01_obs_edge_007.png",
        "PicId" : 33107,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 160,
    },
    33109 : {
        "Path" : "res/map/surface/01_obs_edge_009.png",
        "PicId" : 33109,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 30,
        "MaskArea" : {
            1 : {
                1 : 2,
                2 : 0,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 3,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 3,
                2 : 2,
            },
            6 : {
                1 : 1,
                2 : 2,
            },
            7 : {
                1 : 0,
                2 : 2,
            },
            8 : {
                1 : 1,
                2 : 3,
            },
            9 : {
                1 : 2,
                2 : 3,
            },
            10 : {
                1 : 3,
                2 : 3,
            },
            11 : {
                1 : 4,
                2 : 3,
            },
            12 : {
                1 : 3,
                2 : 4,
            },
        },
    },
    33111 : {
        "Path" : "res/map/surface/01_obs_edge_011.png",
        "PicId" : 33111,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 10,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 2,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
        },
    },
    33113 : {
        "Path" : "res/map/surface/01_obs_edge_013.png",
        "PicId" : 33113,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 10,
    },
    33304 : {
        "Path" : "res/map/surface/01_obs_tree_004.png",
        "PicId" : 33304,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 10,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33306 : {
        "Path" : "res/map/surface/01_obs_tree_006.png",
        "PicId" : 33306,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33308 : {
        "Path" : "res/map/surface/01_obs_tree_008.png",
        "PicId" : 33308,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 3,
            },
            4 : {
                1 : 3,
                2 : 2,
            },
            5 : {
                1 : 3,
                2 : 3,
            },
            6 : {
                1 : 4,
                2 : 2,
            },
            7 : {
                1 : 4,
                2 : 3,
            },
        },
    },
    33310 : {
        "Path" : "res/map/surface/01_obs_tree_010.png",
        "PicId" : 33310,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33312 : {
        "Path" : "res/map/surface/01_obs_tree_012.png",
        "PicId" : 33312,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 3,
            },
            6 : {
                1 : 3,
                2 : 2,
            },
            7 : {
                1 : 3,
                2 : 3,
            },
        },
    },
    33314 : {
        "Path" : "res/map/surface/01_obs_tree_014.png",
        "PicId" : 33314,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 2,
            },
            4 : {
                1 : 2,
                2 : 3,
            },
            5 : {
                1 : 3,
                2 : 3,
            },
            6 : {
                1 : 3,
                2 : 4,
            },
            7 : {
                1 : 4,
                2 : 4,
            },
            8 : {
                1 : 4,
                2 : 5,
            },
        },
    },
    33316 : {
        "Path" : "res/map/surface/01_obs_tree_016.png",
        "PicId" : 33316,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33003 : {
        "Path" : "res/map/surface/01_nsur_grass_003.png",
        "PicId" : 33003,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33005 : {
        "Path" : "res/map/surface/01_nsur_grass_005.png",
        "PicId" : 33005,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33007 : {
        "Path" : "res/map/surface/01_nsur_grass_007.png",
        "PicId" : 33007,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33202 : {
        "Path" : "res/map/surface/01_obs_stone_002.png",
        "PicId" : 33202,
        "XOffset" : -1,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 24,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 1,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 1,
            },
            6 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33204 : {
        "Path" : "res/map/surface/01_obs_stone_004.png",
        "PicId" : 33204,
        "XOffset" : -18,
        "Area" : {
            1 : 1,
            2 : 2,
        },
        "YOffset" : 22,
    },
    33206 : {
        "Path" : "res/map/surface/01_obs_stone_006.png",
        "PicId" : 33206,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 20,
    },
    33208 : {
        "Path" : "res/map/surface/01_obs_stone_008.png",
        "PicId" : 33208,
        "XOffset" : 18,
        "Area" : {
            1 : 2,
            2 : 1,
        },
        "YOffset" : 23,
    },
    33210 : {
        "Path" : "res/map/surface/01_obs_stone_010.png",
        "PicId" : 33210,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33212 : {
        "Path" : "res/map/surface/01_obs_stone_012.png",
        "PicId" : 33212,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33214 : {
        "Path" : "res/map/surface/01_obs_stone_014.png",
        "PicId" : 33214,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 10,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 2,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 0,
            },
            4 : {
                1 : 2,
                2 : 1,
            },
            5 : {
                1 : 2,
                2 : 2,
            },
            6 : {
                1 : 2,
                2 : 3,
            },
            7 : {
                1 : 3,
                2 : 2,
            },
            8 : {
                1 : 3,
                2 : 3,
            },
            9 : {
                1 : 3,
                2 : 4,
            },
            10 : {
                1 : 4,
                2 : 3,
            },
            11 : {
                1 : 4,
                2 : 4,
            },
            12 : {
                1 : 5,
                2 : 4,
            },
        },
    },
    33216 : {
        "Path" : "res/map/surface/01_obs_stone_016.png",
        "PicId" : 33216,
        "XOffset" : -24,
        "Area" : {
            1 : 1,
            2 : 2,
        },
        "YOffset" : 28,
    },
    33218 : {
        "Path" : "res/map/surface/01_obs_stone_018.png",
        "PicId" : 33218,
        "XOffset" : -2,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 23,
    },
    33301 : {
        "Path" : "res/map/surface/01_obs_tree_001.png",
        "PicId" : 33301,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33102 : {
        "Path" : "res/map/surface/01_obs_edge_002.png",
        "PicId" : 33102,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 146,
    },
    33104 : {
        "Path" : "res/map/surface/01_obs_edge_004.png",
        "PicId" : 33104,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 2,
        },
        "YOffset" : 149,
    },
    33106 : {
        "Path" : "res/map/surface/01_obs_edge_006.png",
        "PicId" : 33106,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 165,
    },
    33108 : {
        "Path" : "res/map/surface/01_obs_edge_008.png",
        "PicId" : 33108,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 156,
    },
    33110 : {
        "Path" : "res/map/surface/01_obs_edge_010.png",
        "PicId" : 33110,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 30,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 2,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 0,
            },
            4 : {
                1 : 2,
                2 : 1,
            },
            5 : {
                1 : 2,
                2 : 2,
            },
            6 : {
                1 : 3,
                2 : 2,
            },
            7 : {
                1 : 3,
                2 : 3,
            },
        },
    },
    33112 : {
        "Path" : "res/map/surface/01_obs_edge_012.png",
        "PicId" : 33112,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 10,
    },
    33303 : {
        "Path" : "res/map/surface/01_obs_tree_003.png",
        "PicId" : 33303,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33305 : {
        "Path" : "res/map/surface/01_obs_tree_005.png",
        "PicId" : 33305,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 20,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 2,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
            5 : {
                1 : 2,
                2 : 3,
            },
        },
    },
    33307 : {
        "Path" : "res/map/surface/01_obs_tree_007.png",
        "PicId" : 33307,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 0,
    },
    33309 : {
        "Path" : "res/map/surface/01_obs_tree_009.png",
        "PicId" : 33309,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33311 : {
        "Path" : "res/map/surface/01_obs_tree_011.png",
        "PicId" : 33311,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33313 : {
        "Path" : "res/map/surface/01_obs_tree_013.png",
        "PicId" : 33313,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 15,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
        },
    },
    33315 : {
        "Path" : "res/map/surface/01_obs_tree_015.png",
        "PicId" : 33315,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 0,
            },
            2 : {
                1 : 1,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33002 : {
        "Path" : "res/map/surface/01_nsur_grass_002.png",
        "PicId" : 33002,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33004 : {
        "Path" : "res/map/surface/01_nsur_grass_004.png",
        "PicId" : 33004,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33006 : {
        "Path" : "res/map/surface/01_nsur_grass_006.png",
        "PicId" : 33006,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33008 : {
        "Path" : "res/map/surface/01_nsur_grass_008.png",
        "PicId" : 33008,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33302 : {
        "Path" : "res/map/surface/01_obs_tree_002.png",
        "PicId" : 33302,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 1,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 0,
                2 : 1,
            },
            2 : {
                1 : 1,
                2 : 0,
            },
            3 : {
                1 : 1,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 1,
            },
            5 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33201 : {
        "Path" : "res/map/surface/01_obs_stone_001.png",
        "PicId" : 33201,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 0,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 2,
            },
            4 : {
                1 : 2,
                2 : 3,
            },
            5 : {
                1 : 3,
                2 : 2,
            },
            6 : {
                1 : 3,
                2 : 3,
            },
            7 : {
                1 : 3,
                2 : 4,
            },
            8 : {
                1 : 4,
                2 : 3,
            },
            9 : {
                1 : 4,
                2 : 4,
            },
        },
    },
    33203 : {
        "Path" : "res/map/surface/01_obs_stone_003.png",
        "PicId" : 33203,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 10,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 0,
            },
            3 : {
                1 : 2,
                2 : 1,
            },
            4 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33205 : {
        "Path" : "res/map/surface/01_obs_stone_005.png",
        "PicId" : 33205,
        "XOffset" : -44,
        "Area" : {
            1 : 2,
            2 : 3,
        },
        "YOffset" : 26,
    },
    33207 : {
        "Path" : "res/map/surface/01_obs_stone_007.png",
        "PicId" : 33207,
        "XOffset" : -19,
        "Area" : {
            1 : 1,
            2 : 2,
        },
        "YOffset" : 19,
    },
    33209 : {
        "Path" : "res/map/surface/01_obs_stone_009.png",
        "PicId" : 33209,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33211 : {
        "Path" : "res/map/surface/01_obs_stone_011.png",
        "PicId" : 33211,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33213 : {
        "Path" : "res/map/surface/01_obs_stone_013.png",
        "PicId" : 33213,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },
    33215 : {
        "Path" : "res/map/surface/01_obs_stone_015.png",
        "PicId" : 33215,
        "XOffset" : 0,
        "Area" : {
            1 : 2,
            2 : 2,
        },
        "YOffset" : 10,
        "MaskArea" : {
            1 : {
                1 : 1,
                2 : 2,
            },
            2 : {
                1 : 2,
                2 : 1,
            },
            3 : {
                1 : 2,
                2 : 2,
            },
        },
    },
    33217 : {
        "Path" : "res/map/surface/01_obs_stone_017.png",
        "PicId" : 33217,
        "XOffset" : -19,
        "Area" : {
            1 : 1,
            2 : 2,
        },
        "YOffset" : 23,
    },
    33219 : {
        "Path" : "res/map/surface/01_obs_stone_019.png",
        "PicId" : 33219,
        "XOffset" : 22,
        "Area" : {
            1 : 2,
            2 : 1,
        },
        "YOffset" : 28,
    },
    33001 : {
        "Path" : "res/map/surface/01_nsur_grass_001.png",
        "PicId" : 33001,
        "XOffset" : 0,
        "Area" : {
            1 : 1,
            2 : 1,
        },
        "YOffset" : 0,
    },

};
module.exports = _p;
