/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "id" : 1,
        "name" : "白",
        "color" : {
            1 : 206,
            2 : 129,
            3 : 43,
        },
    },
    2 : {
        "id" : 2,
        "name" : "绿",
        "color" : {
            1 : 42,
            2 : 196,
            3 : 46,
        },
    },
    3 : {
        "id" : 3,
        "name" : "蓝",
        "color" : {
            1 : 58,
            2 : 146,
            3 : 255,
        },
    },
    4 : {
        "id" : 4,
        "name" : "紫",
        "color" : {
            1 : 216,
            2 : 60,
            3 : 225,
        },
    },
    5 : {
        "id" : 5,
        "name" : "橙",
        "color" : {
            1 : 255,
            2 : 174,
            3 : 34,
        },
    },
    0 : {
        "id" : 0,
        "name" : "灰",
        "color" : {
            1 : 87,
            2 : 87,
            3 : 87,
        },
    },

};
module.exports = _p;
