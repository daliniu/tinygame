/*
Don't modify this file manually!
*/
var _p = {
    "tbMenus" : {
        2 : {
            1 : "btn_setting",
        },
        3 : {
            1 : "btn_handbook",
        },
        1 : {
            1 : "btn_mail",
        },
        4 : {
            1 : "btn_test",
        },
        5 : {
            1 : "btn_levelup",
        },
    },
    "nMainDistance" : 50,
    "nTime" : 0.2,
    "nDistance" : 60,
    "nMainTime" : 0.2,
    "tbScale" : {
        1 : 1.8,
        2 : 1.5,
    },

};
module.exports = _p;
