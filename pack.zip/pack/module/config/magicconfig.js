/*
Don't modify this file manually!
*/
var _p = {
    "nFade" : 0.2,
    "nMinSeg" : 40,
    "tbPos" : {
        1 : 0.5,
        2 : 0.2,
    },
    "nTime" : 0.4,
    "tbColor" : {
        1 : 255,
        2 : 100,
        3 : 0,
    },
    "tbPosEnd" : {
        1 : 0.5,
        2 : 0,
    },
    "tbPosStart" : {
        1 : 0.5,
        2 : 1.5,
    },
    "nStroke" : 20,

};
module.exports = _p;
