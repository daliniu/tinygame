/*
Don't modify this file manually!
*/
var _p = {
    1 : {
        "groove" : 1,
        "cost" : {
            1 : 500,
            2 : 100,
        },
    },
    2 : {
        "groove" : 2,
        "cost" : {
            1 : 600,
            2 : 200,
        },
    },
    3 : {
        "groove" : 3,
        "cost" : {
            1 : 700,
            2 : 300,
        },
    },
    4 : {
        "groove" : 4,
        "cost" : {
            1 : 800,
            2 : 400,
        },
    },
    5 : {
        "groove" : 5,
        "cost" : {
            1 : 900,
            2 : 500,
        },
    },
    6 : {
        "groove" : 6,
        "cost" : {
            1 : 1000,
            2 : 600,
        },
    },

};
module.exports = _p;
