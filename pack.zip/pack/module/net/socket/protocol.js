var rpc = require('../mdp/remote_proxy');
var Parse = require('./parse');
var tiny = require('../../../tiny');
module.exports.process = function(sessionid, msgid, data) {
	// test begin
	if (!data) {
		console.log("............Newtest............");
		module.exports.processNew(sessionid, msgid);
		return;
	}
	// test end
	var msg = {},
		server = Parse.getMsgServer(msgid);
	if (server && data) {
		msg.funcName = Parse.getMsgFunction(msgid);
		msg.inArgs = data;
		msg.callbackFunc = "clientResponse";
		msg.current = {};
		msg.current.sessionId = sessionid;
		msg.current.msgId = msgid;
		msg.current.serverName = server;
		msg.current.clientCallFunc = msg.funcName;

		//tiny.log.error("..................process............");
		// server相同不需要远程调用直接给本server处理
		if (server === tiny.type) {
			// tiny.log.debug("|processMsg.tcp.local|msgid:" + msgid + "|sessionid:" + sessionid + "|server:"+ server);
			msg.current.clientRequest = true;
			rpc.processClient(msg);
		} else {
			// tiny.log.debug("|processMsg.tcp.other|msgid:" + msgid + "|sessionid:" + sessionid + "|server:"+ server);
			rpc.processClientToOtherServer(server, msg);
		}
	}
};



module.exports.processNew = function(sessionid, data) {
	var msg = {};
	if (data && data.hasOwnProperty("serverName")) {
		msg.funcName = data.funcName;
		msg.inArgs = data.args;
		msg.callbackFunc = "clientResponse";
		msg.current = {};
		msg.current.sessionId = sessionid;
		msg.current.funcName = data.funcName;
		msg.current.serverName = data.serverName;
		msg.current.funcId = data.funcId;
		msg.current.clientCallFunc = data.funcName;

		tiny.log.error("..................NewProcess............", data.funcId);
		// server相同不需要远程调用直接给本server处理
		if (data.serverName === tiny.type) {
			// tiny.log.debug("processMsg.tcp.local", JSON.stringify(msg));
			msg.current.clientRequest = true;
			rpc.processClient(msg);
		} else {
			 //tiny.log.debug("processMsg.tcp.other", JSON.stringify(msg));
			rpc.processClientToOtherServer(data.serverName, msg);
		}
	}
};
