var protocol = require("./proto");
var utils = require('../../utils');
var tiny = require('../../../tiny');
var StringMaxLength = require('../../const').MAX_PROTO_STRING_LENGTH;
var ErrCode = require('../../const').CLIENT_ERROR_CODE;
var SERIAL_DATA_TYPE = require('../../const').SERIAL_DATA_TYPE;
var Serialize = require('../../dataprocess/serialize/serialize');
var SerialProto = require('../../dataprocess/serialize/serial_proto');
module.exports.parseBytes = function(buffer) {
	var i, j,
		dataArray = [],
		offset = 0,
		len = 0,
		pack = {};

	//try {
		pack.msgid = buffer.readInt16BE(offset);
		offset += 2;

		if (protocol.hasOwnProperty(pack.msgid)) {
			if (protocol[pack.msgid].hasOwnProperty("types")) {
				for (i = 0; i < protocol[pack.msgid].types.length; ++i) {
					switch(protocol[pack.msgid].types[i])
					{
						case 's':
							len = buffer.readInt16BE(offset);
							offset += 2;
							dataArray[i] = buffer.toString('utf8', offset, offset + len);
							offset += len;
							break;
						case 'i':
							dataArray[i] = buffer.readInt32BE(offset);
							offset += 4;
							break;
						default:
							throw 'types wrong!';
					}
				}
				// 检查数据长度一致过于严格，可以考虑只使用接收到的部分
				if (dataArray.length === protocol[pack.msgid].types.length) {
					pack.data = {};
					for (j = 0; j < dataArray.length; ++j) {
						pack.data[protocol[pack.msgid].keys[j]] = dataArray[j];
					}
				} else {
					throw 'package type length wrong!';
				}
			}
		}
	//} catch(e) {
	//	tiny.log.error('parseBytes error: ' + e);
	//	return {};
	//}
	return pack;
};

module.exports.packBytes = function(msgid, data) {
	var i,
		buffer,
		len = 0,
		offset = 0,
		dataArray = [],
		code = ErrCode.SUCCESS;
	if (protocol.hasOwnProperty(msgid)) {
		// 缺少协议状态码
		if (!data.hasOwnProperty('retCode')) {
			tiny.log.error('packBytes retCode null');
			return null;
		}

		// 返回错误状态码的包
		if (data.retCode !== code) {
			code = data.retCode;
			buffer = new Buffer(4);
			buffer.writeUInt16BE(msgid, 0);
			buffer.writeUInt16BE(code, 2);
			return buffer;
		}

		if (protocol[msgid].hasOwnProperty("types")) {
			for (i = 0; i < protocol[msgid].keys.length; ++i) {
				if (data.hasOwnProperty(protocol[msgid].keys[i])) {
					if (typeof(data[protocol[msgid].keys[i]]) === 'object') {
						dataArray.push(JSON.stringify(data[protocol[msgid].keys[i]]));
					} else {
						dataArray.push(data[protocol[msgid].keys[i]]);
					}
					switch(protocol[msgid].types[i])
					{
						case 's':
							// 检查字符串长度是否超过2byte
							if (dataArray[i].length > StringMaxLength) {
								tiny.log.error('packBytes stirng too long');
								return null;
							}
							len += dataArray[i].length + 2;
							break;
						case 'i':
							len += 4;
							break;
						default:
							tiny.log.error('packBytes type error');
							return null;
					}
				} else {
					tiny.log.error('packBytes data has none keys field', protocol[msgid].keys[i]);
					return null;
				}
			}

			buffer = new Buffer(len + 4);
			buffer.writeUInt16BE(msgid, 0);
			buffer.writeUInt16BE(code, 2);
			offset += 4;

			for (i = 0; i < dataArray.length; ++i) {
				switch(protocol[msgid].types[i])
				{
					case 's':
						buffer.writeUInt16BE(dataArray[i].length, offset);
						offset += 2;
						buffer.write(dataArray[i], offset);
						offset += dataArray[i].length;
						break;
					case 'i':
						buffer.writeInt32BE(dataArray[i], offset);
						offset += 4;
						break;
					default:
						tiny.log.error('packBytes type error');
						return null;
				}
			}
			return buffer;
		}
	}

	return null;
};

module.exports.getMsgServer = function(msgid) {
	if (protocol.hasOwnProperty(msgid)) {
		if (protocol[msgid].hasOwnProperty('target')
			&& protocol[msgid].target[0] !== undefined) {
			return protocol[msgid].target[0];
		}
	}
	tiny.log.error('getMsgServer have not found target', msgid);
	return null;
};

module.exports.getMsgFunction = function(msgid) {
	if (protocol.hasOwnProperty(msgid)) {
		if (protocol[msgid].hasOwnProperty('func')
			&& protocol[msgid].func[0] !== undefined) {
			return protocol[msgid].func[0];
		}
	}
	tiny.log.error('getMsgFunction have not found func');
	return null;
};

module.exports.getRspMsgId = function(msgid) {
	if (protocol.hasOwnProperty(msgid)) {
		if (protocol[msgid].hasOwnProperty('rspid')
			&& protocol[msgid].rspid[0] !== undefined) {
			return protocol[msgid].rspid[0];
		}
	}
	tiny.log.error('getRspMsgId have not found rspid' + msgid);
	return null;
};

module.exports.packErr = function(msgid) {
	var buffer = new Buffer(4);
	buffer.writeUInt16BE(msgid, 0);
	buffer.writeUInt16BE(ErrCode.FAILURE, 2);
	return buffer;
};

module.exports.pack = function(data) {
	/*
	var buffer, len, s;
	s = JSON.stringify(data);
	len = s.length;
	if (len > StringMaxLength) {
		tiny.log.error('packBytes stirng too long');
		return null;
	}
	buffer = new Buffer(len + 2);
	buffer.writeUInt16BE(len, 0);
	buffer.write(s, 0);
	return buffer;
	*/
/*
0       serverName
1       funcName
2       args
3       funcId
4       retCode
*/
	try {
	var buffer,str, packData = [];
	try {
	packData[SERIAL_DATA_TYPE.SERVER_NAME] = 0;
	packData[SERIAL_DATA_TYPE.FUNC_NAME] = SerialProto.interface[data.serverName][data.funcName].seq;
	if (data.retCode === ErrCode.SUCCESS || data.retCode > ErrCode.RETCODE_NEED_UNPACK) {
		packData[SERIAL_DATA_TYPE.ARGS] = Serialize.serialize(SerialProto.interface[data.serverName][data.funcName].outArgs, data.args);
	} else {
		packData[SERIAL_DATA_TYPE.ARGS] = [];
	}
	packData[SERIAL_DATA_TYPE.FUNCID] = data.funcId;
	packData[SERIAL_DATA_TYPE.RET_CODE] = data.retCode;
	tiny.log.error("....................sss", JSON.stringify(packData));
	} catch(e) {
		//tiny.log.error("..........test..........p", data.serverName, data.funcName, JSON.stringify(packData[SERIAL_DATA_TYPE.ARGS]), e);
		return null;
	}
	// console.log('(((((((((((((((((((((((');
	str = JSON.stringify(packData);
	// buffer = new Buffer(str.length);
	// buffer.write(str, 0);
	buffer = new Buffer(str);
	// console.log(str, str.length);
	// console.log(buffer);
	// console.log(buffer.toString());
	// console.log(buffer.toJSON());
	return buffer;
	} catch(e) {
		//tiny.log.error("..........test..........p")	;
	}
	return null;
};

module.exports.unpack = function(buffer) {
	/*
	var data,
		offset = 0,
		len = 0;
	len = buffer.readInt16BE(offset);
	offset += 2;
	data = buffer.toString('utf8', offset, offset + len);
	return JSON.parse(data);
	*/
	try {
	tiny.log.error("....", buffer);
	var data = {}, unpackData;
	unpackData  = JSON.parse(buffer);
	try {
	data.serverName = SerialProto.interface[unpackData[SERIAL_DATA_TYPE.SERVER_NAME]].serverName;
	data.funcName   = SerialProto.interface[unpackData[SERIAL_DATA_TYPE.SERVER_NAME]][unpackData[SERIAL_DATA_TYPE.FUNC_NAME]].funcName;
	data.args       = unpackData[SERIAL_DATA_TYPE.ARGS];
	data.funcId     = unpackData[SERIAL_DATA_TYPE.FUNCID];
	tiny.log.error("....................uuu", JSON.stringify(data.args));
	if (utils.jsonIsEmpty(data.args)) {
		data.args = {};
	} else {
		data.args = Serialize.unserialize(SerialProto.interface[data.serverName][data.funcName].inArgs, data.args);
	}
	} catch(e) {
		//tiny.log.error("..........test..........up", data.serverName, data.funcName, e);
		return null;
	}
	return data;
	} catch(e) {
		//tiny.log.error("..........test..........up", e);
	}
	return null;
};
