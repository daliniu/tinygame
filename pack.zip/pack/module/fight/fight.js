var tiny = require('../../tiny');
var Luanode = require('../../cmodule/luanode.node');
var utils = require('../utils');
var Chanllenge = require('../config/monsterchal');
var lua = require('../lua/lua');

lua.setGlobal('g_nWinner', 0);	// 设置服务器标记

//lua.doFile('script/core/fight/fight.lua');
// 战斗模块
exports.fightEnemy = function(monsterid, playerInfo, callback) {
	var result,
		playerRateHP = 0,
		seed;

	if (monsterid === undefined) {
		callback("don't match monsterid " + monsterid);
		return;
	}

	seed = utils.randomInt(1, 90071992);
	//seed = 76093291;

	result = 1;

	//lua.call('StartFightWithMonster', seed, playerInfo, monsterid, rewardid);
	try {
		 lua.setGlobal('_SERVER_nSeed', seed);
		 lua.setGlobal('_SERVER_player', playerInfo);
		 lua.setGlobal('_SERVER_nMBID', monsterid);
		 lua.doFile('script/core/fight/fight.lua');
		 //g_nWinner
		 result = lua.getGlobal('g_nWinner');
		 playerRateHP = lua.getGlobal('g_nMineHPRate');
		 tiny.log.trace("fightEnemy = ", playerRateHP);
		 callback(null, result, seed, playerRateHP);
		// callback(null, 0, 12343);
	} catch (err) {
		tiny.log.debug(err.stack);
		callback(err.stack);
	}

	tiny.log.error('....................', seed, result);
	return;
};

// pvp战斗
exports.fightPvp = function(playerInfo1, playerInfo2, callback) {
	var winner = 1, seed = 123;
	callback(null, winner, seed);
};
