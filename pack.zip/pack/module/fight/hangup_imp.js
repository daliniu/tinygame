var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var tiny = require('../../tiny');
var async = require('async');
var utils = require('../utils');
var eqStar = require("../config/eqStar");
var hangHandle = require('../dataprocess/hangup_handle');
var equipHandle = require('../dataprocess/equip_handle');
var playerHandle = require('../dataprocess/player_handle');
var mapHandle = require('../dataprocess/map_handle');
var afkHandle = require('../dataprocess/afk_handle');
var afk = require('../afk/afk');
var maxScoreTime = function(_afkReward) {
	var i, j, max = 0, afkReward = {};
	for (i in _afkReward) {
		if (_afkReward.hasOwnProperty(i)) {
			for (j in _afkReward[i].Score) {
				if (_afkReward[i].Score.hasOwnProperty(j)) {
					if (parseInt(j, 10) >= max) {
						max = parseInt(j, 10);
					}
				}
			}
			afkReward[i] = _afkReward[i];
			afkReward[i].MaxScoreTime = max;
			max = 0;
		}
	}
	return afkReward;
};
var Afkreward = maxScoreTime(require('../config/afkreward'));
var itemfunc = require('../item/item');
// 离线获取挂机收益
var offlineProfit = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;
	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取当前挂机点
		function(session, callback) {
			afkHandle.getAfkInfo(session.area, session.uuid, function(err, afkInfo) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, afkInfo);
				}
			});
		},
		// 获取地图信息
		function(session, afkInfo, callback) {
			mapHandle.getMapInfo(session.area, session.uuid, afkInfo.curAfker.mapid, function(err, mapInfo) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, afkInfo, mapInfo);
				}
			});
		},
		// 获取离线收益
		function(session, afkInfo, mapInfo, callback) {
			// 运行逻辑
			tiny.log.debug("guajiid", afkInfo.curAfker.guajiid);
			var result = afk.calProfit(true, afkInfo, mapInfo);
			tiny.log.debug("guajiid", JSON.stringify(afkInfo), JSON.stringify(mapInfo), JSON.stringify(result));
			if (!result) {
				callback(ErrCode.NO_NEED_TIPS, "cal offline afk fail", session);
			} else {
				callback(null, session, afkInfo, mapInfo, result);
			}
		},
		// 保存挂机信息
		function(session, afkInfo, mapInfo, result, callback) {
			afkHandle.setAfkInfo(session.area, session.uuid, afkInfo, function(err) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, mapInfo, result);
				}
			});
		},
		// 保存地图信息
		function(session, mapInfo, result, callback) {
			mapHandle.setMapInfo(session.area, session.uuid, mapInfo.mapid, mapInfo, function(err) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, result);
				}
			});
		},
		// 保存道具到背包中
		function(session, result, callback) {
			equipHandle.saveItemToBagList(session.area, session.uuid, result.splitList, function(err, bagItem, isEnough) {
				if (err) {
					callback(ErrCode.BAG_FREE_ROOM_LIMIT, err, session);
				} else {
					callback(null, session, bagItem, result, isEnough);
				}
			});
		},
		// 增加金钱提升等级
		function(session, bagItem, result, isEnough, callback) {
			playerHandle.updatePlayerInfo(session.area, session.uuid, result.gold, result.exp, result.action, function(err, playerInfo) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, null, session, bagItem, playerInfo, result, isEnough);
				}
			});
		}
	], function(errCode, errStr, session, bagItem, playerInfo, result, isEnough) {
		if (errCode) {
			tiny.log.error("offlineProfit", session.uuid, session.area, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.bagitem = bagItem;
			outArgs.playerInfo = playerInfo;
			outArgs.gold = result.gold;
			outArgs.exp = result.exp;
			outArgs.action = result.action;
			outArgs.offTime = result.offTime;
			if (isEnough) {
				onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
			} else {
				onResponse(ErrCode.FIGHT_BAG_FREE_ROOM_LIMIT, current, inArgs, outArgs);
			}
		}
	});
};

// 在线实时获取挂机收益
var onlineProfit = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 获取当前挂机点
		function(session, callback) {
			afkHandle.getAfkInfo(session.area, session.uuid, function(err, afkInfo) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, afkInfo);
				}
			});
		},
		// 获取地图信息
		function(session, afkInfo, callback) {
			mapHandle.getMapInfo(session.area, session.uuid, afkInfo.curAfker.mapid, function(err, mapInfo) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, afkInfo, mapInfo);
				}
			});
		},
		// 获取在线收益
		function(session, afkInfo, mapInfo, callback) {
			// 运行逻辑
			tiny.log.debug("guajiid", afkInfo.curAfker.guajiid);
			if (afkInfo.curAfker.guajiid === 0 && inArgs.pointId === 0) {
				inArgs.pointId = Const.DEFAULT_AFK_POINT;
			}
			var result = afk.calProfit(false, afkInfo, mapInfo, inArgs.pointId);
			tiny.log.debug("guajiid", JSON.stringify(afkInfo), JSON.stringify(mapInfo), JSON.stringify(result));
			if (!result) {
				callback(ErrCode.NOT_BEGIN_AFK_ERROR, "cal online afk fail", session);
			} else {
				callback(null, session, afkInfo, mapInfo, result);
			}
		},
		// 保存挂机信息
		function(session, afkInfo, mapInfo, result, callback) {
			afkHandle.setAfkInfo(session.area, session.uuid, afkInfo, function(err) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, mapInfo, result);
				}
			});
		},
		// 保存地图信息
		function(session, mapInfo, result, callback) {
			if (inArgs.pointId) {
				tiny.log.debug("new guideline equip", JSON.stringify(result));
				callback(null, session, result);
				return;
			}
			mapHandle.setMapInfo(session.area, session.uuid, mapInfo.mapid, mapInfo, function(err) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, session, result);
				}
			});
		},
		// 保存道具到背包中
		function(session, result, callback) {
			if (result.splitList) {
				equipHandle.saveItemToBagList(session.area, session.uuid, result.splitList, function(err, bagItem, isEnough) {
					if (err) {
						callback(ErrCode.BAG_FREE_ROOM_LIMIT, err, session);
					} else {
						callback(null, session, bagItem, result, isEnough);
					}
				});
			} else {
				callback(null, session, {itemList : {}, equipList : {}}, result, true);
			}
		},
		// 增加金钱提升等级
		function(session, bagItem, result, isEnough, callback) {
			playerHandle.updatePlayerInfo(session.area, session.uuid, result.gold, result.exp, result.action, function(err, playerInfo) {
				if (err) {
					callback(ErrCode.HANGUP_ONLINE_ERROR, err, session);
				} else {
					callback(null, null, session, bagItem, playerInfo, result, isEnough);
				}
			});
		}
	], function(errCode, errStr, session, bagItem, playerInfo, result, isEnough) {
		if (errCode) {
			tiny.log.error("onlineProfit", session.uuid, session.area, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.bagitem = bagItem;
			outArgs.playerInfo = playerInfo;
			outArgs.gold = result.gold;
			outArgs.exp = result.exp;
			outArgs.action = result.action;
			outArgs.rewardCount = result.rewardCount;
			if (isEnough) {
				onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
			} else {
				onResponse(ErrCode.FIGHT_BAG_FREE_ROOM_LIMIT, current, inArgs, outArgs);
			}
		}
	});
};

var setProAfkTime = function(area, uuid, callback) {
	afkHandle.getAfkInfo(area, uuid, function(err, afkInfo) {
		if (err) {
			callback(err);
		} else {
			afk.proAfkTimeChange(afkInfo, Date.now());
			afkHandle.setAfkInfo(area, uuid, afkInfo, function(err) {
				if (err) {
					callback(err);
				} else {
					callback(null);
				}
			});
		}
	});
};

// 获取宝箱
//var getPresent = function(dataValue, inArgs, dataKey) {
var getPresent = function(dataValue) {
	//tiny.log.debug("doing", JSON.stringify(inArgs), JSON.stringify(dataKey), JSON.stringify(dataValue));

	var outArgs = {}, victoryTime, guajiId, uid, count, bGold = dataValue.baseInfo.gold, bAction = dataValue.baseInfo.action;
	outArgs.bagitem = {};

	guajiId = dataValue.afkInfo.curAfker.guajiid;
	uid = dataValue.afkInfo.curAfker.uid;
	if (guajiId === 0 || !dataValue.hasOwnProperty("mapInfo")) {
		victoryTime = dataValue.afkInfo.afkVictoryTime;
		guajiId = Const.DEFAULT_AFK_POINT;
	} else {
		tiny.log.debug("doing", uid, dataValue.mapInfo.uidList[uid].afkVictoryTime);
		if (!dataValue.mapInfo.uidList[uid].afkVictoryTime) {
			dataValue.mapInfo.uidList[uid].afkVictoryTime = { rewardCount : 0, scoreTime : 1};
		}
		victoryTime = dataValue.mapInfo.uidList[uid].afkVictoryTime;
	}

	if (victoryTime.scoreTime >= Afkreward[guajiId].MaxScoreTime) {
		// 获取礼物
		count = Afkreward[guajiId].Score[Afkreward[guajiId].MaxScoreTime];
	} else {
		// 连胜次数在配置范围内
		count = Afkreward[guajiId].Score[victoryTime.scoreTime];
	}

	tiny.log.debug("get ScoreReward", guajiId, Afkreward[guajiId].ScoreReward, victoryTime.rewardCount, victoryTime.scoreTime, Afkreward[guajiId].MaxScoreTime, count);

	if (victoryTime.rewardCount >= count) {
		// 给礼物
		if (!itemfunc.dropPool(Afkreward[guajiId].ScoreReward, dataValue.baseInfo, dataValue.bagList, outArgs.bagitem)) {
			outArgs.retCode = ErrCode.AFK_GET_REWARD_ERROR;
		} else {
			victoryTime.scoreTime += 1;
			outArgs.playerInfo = dataValue.baseInfo;
			outArgs.gold = dataValue.baseInfo.gold - bGold;    //result.gold;
			outArgs.exp = 0;     //result.exp;
			outArgs.action = dataValue.baseInfo.action - bAction;  //result.action;
			outArgs.rewardCount = 0;
			outArgs.step = victoryTime.scoreTime;
			outArgs.retCode = ErrCode.SUCCESS;
			// 重新设置为0;
			victoryTime.rewardCount = 0;
		}
	} else {
		tiny.log.error("count not enough", victoryTime.rewardCount, count);
		outArgs.retCode = ErrCode.AFK_GET_REWARD_ERROR;
	}

	return outArgs;
};

// 获取奖励次数
//var getRewardTime = function(dataValue, inArgs, dataKey) {
var getRewardTime = function(dataValue) {
	//tiny.log.debug("doing", JSON.stringify(inArgs), JSON.stringify(dataKey), JSON.stringify(dataValue));

	var outArgs = {}, guajiId, uid;

	guajiId = dataValue.afkInfo.curAfker.guajiid;
	uid = dataValue.afkInfo.curAfker.uid;
	// 设置宝箱次数
	if (guajiId === 0 || !dataValue.hasOwnProperty("mapInfo")) {
		outArgs.rewardCount = dataValue.afkInfo.afkVictoryTime.rewardCount;
		outArgs.step = dataValue.afkInfo.afkVictoryTime.scoreTime;
	} else {
		if (!dataValue.mapInfo.uidList[uid].hasOwnProperty("afkVictoryTime")) {
			dataValue.mapInfo.uidList[uid].afkVictoryTime = { rewardCount : 0, scoreTime : 1};
		}
		outArgs.rewardCount = dataValue.mapInfo.uidList[uid].afkVictoryTime.rewardCount;
		outArgs.step = dataValue.mapInfo.uidList[uid].afkVictoryTime.scoreTime;
	}
	outArgs.retCode = ErrCode.SUCCESS;

	return outArgs;
};

module.exports = {
"offlineProfit" : offlineProfit,
"onlineProfit" : onlineProfit,
"setProAfkTime" : setProAfkTime,
"testNew" : {
	"getPresent" : getPresent,
	"getRewardTime" : getRewardTime,
},
};

