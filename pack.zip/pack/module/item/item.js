var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var UseType = Const.ITEM.USE_TYPE;
var ItemMainType = Const.ITEM.MAIN_TYPE;
var ItemDrop = Const.ITEM_DROP;
var tiny = require('../../tiny');
var playerHandle = require('../dataprocess/player_handle');
var equipHandle = require('../dataprocess/equip_handle');
var Item = require('../config/item');
var Compose = require('../config/compose');
var Drop = require('../config/drop');
var bag = require('../bag/bag');
var async = require('async');
var utils = require('../utils');

exports.getItemAward = function(itemID, itemNum, bagList, bagAdd) {
	var num,
		equip;
	if (Item.hasOwnProperty(itemID)) {
		if (parseInt(Item[itemID].itemTepy, 10) === ItemMainType.EQUIP) {
			// 创建装备
			for (num = 0; num < itemNum; ++num) {
				equip = equipHandle.createEquip(itemID);
				if (!bag.addEquip(equip.index, equip.equipInfo, bagList)) {
					return false;
				}
				if (!bagAdd.hasOwnProperty("equipList")) {
					bagAdd.equipList = {};
				}
				bagAdd.equipList[equip.index] = equip.equipInfo;
				bagAdd.equipList[equip.index].num = 1;
			}
		} else {
			if (!bag.addItem(itemID, itemNum, bagList)) {
				return false;
			}
			if (!bagAdd.hasOwnProperty("itemList")) {
				bagAdd.itemList = {};
			}
			if (!bagAdd.itemList.hasOwnProperty(itemID)) {
				bagAdd.itemList[itemID] = {};
				bagAdd.itemList[itemID].num = 0;
			}
			bagAdd.itemList[itemID].num = bagAdd.itemList[itemID].num + itemNum;
		}
		return true;
	}
	tiny.log.error('getItemAward', 'item id error', itemID);
	return false;
};

function getPoolThing(valueType, value, baseInfo, bagList, bagAdd) {
	if (valueType === ItemDrop.GOLD) {
		baseInfo.gold = utils.addValue(baseInfo.gold + value);
	} else if (valueType === ItemDrop.DIAMOND) {
		baseInfo.diamond = utils.addValue(baseInfo.diamond + value);
	} else if (valueType === ItemDrop.TEAM_EXP) {
		playerHandle.addPlayerExp(value, baseInfo);
	} else if (valueType === ItemDrop.ACTION) {
		playerHandle.addPlayerAction(value, baseInfo);
	} else if (valueType === ItemDrop.JJC_GOLD) {
		// 什么玩意
	} else if (valueType === ItemDrop.MAGIC_GOLD) {
		// 什么玩意
	} else {	// 道具
		if (!exports.getItemAward(valueType, value, bagList, bagAdd)) {
			return false;
		}
	}
	return true;
}

exports.dropPool = function(id, baseInfo, bagList, bagAdd) {
	var i, j, p, q,
		scope = [],
		ret,
		itemNum = 0,
		valueType,
		value;
		// plate = [];
	if (Drop.hasOwnProperty(id)) {
		// 处理必出掉落
		if (Drop[id].hasOwnProperty("foreverDrop")) {
			for (i in Drop[id].foreverDrop) {
				if (Drop[id].foreverDrop.hasOwnProperty(i)) {
					valueType = Drop[id].foreverDrop[i][1];
					value = utils.checkValue(Drop[id].foreverDrop[i][2]);
					tiny.log.debug('for', id, i, value, parseInt(value, 10),Drop[id].foreverDrop[i][2]);
					if (!getPoolThing(valueType, value, baseInfo, bagList, bagAdd)) {
						tiny.log.error('dropPool', 'get pool thing error', valueType, value);
						return false;
					}
				}
			}
		}

		if (!Drop[id].number) {
			return true;
		}

		// 计算出多少个道具
		for (j in Drop[id].number) {
			if (Drop[id].number.hasOwnProperty(j)) {
				scope.push([Drop[id].number[j][2], j]);
			}
		}
		ret = utils.randomScope(scope);
		if (!ret || ret < 0) {
			tiny.log.error('dropPool', 'calc item num error', ret);
			return false;
		}
		itemNum = Drop[id].number[ret][1];

		// 随机出掉落
		scope = [];
		for (q = 1; q <= ItemDrop.DROP_MAX_NUM; ++q) {
			if (Drop[id].hasOwnProperty(['tepy' + q])) {
				// plate.push(Drop[id]['tepy' + q]);
				scope.push([Drop[id]['tepy' + q][3], q]);
			}
		}
		for (p = 0; p < itemNum; ++p) {
			// tiny.log.trace("dropPool", plate, scope);
			ret = utils.randomScope(scope);
			tiny.log.trace("dropPool", scope, ret);
			if (!ret || ret < 0) {
				tiny.log.error('dropPool', 'calc random item error', ret);
				return false;
			}

			if (!Drop[id].hasOwnProperty(['tepy' + ret]) ||
				!Drop[id]['tepy' + ret].hasOwnProperty("2")) {
				tiny.log.error('dropPool', 'key error', ret, JSON.stringify(Drop[id]['tepy' + ret]));
				return false;
			}
			valueType = Drop[id]['tepy' + ret][1];
			value = utils.checkValue(Drop[id]['tepy' + ret][2]);
			if (!getPoolThing(valueType, value, baseInfo, bagList, bagAdd)) {
				tiny.log.error('dropPool', 'random get pool thing error', valueType, value);
				return false;
			}
			if (parseInt(Drop[id]['tepy' + ret][4], 10) === 0) {
				// plate.splice(ret, 1);
				scope.splice(ret, 1);
			}
		}
		return true;
	}
	tiny.log.error("dropPool", 'Item list have no id', id);
	return false;
};
