var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var UseType = Const.ITEM.USE_TYPE;
var ItemMainType = Const.ITEM.MAIN_TYPE;
var tiny = require('../../tiny');
var playerHandle = require('../dataprocess/player_handle');
var equipHandle = require('../dataprocess/equip_handle');
var heroHandle = require('../dataprocess/hero_handle');
var Item = require('../config/item');
var Compose = require('../config/compose');
var bag = require('../bag/bag');
var async = require('async');
var utils = require('../utils');
var itemfunc = require('./item');

var sellItemGroup = function(inArgs, onResponse, current) {
	var sellgroup = JSON.parse(inArgs.sellgroup),
		outArgs = {};

	outArgs.cost = 0;

	// 获取背包数据
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取背包数据
		function(session, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err);
				} else {
					callback(null, session, bagList);
				}
			});
		},
		// 获取baseinfo
		function(session, bagList, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					callback(null, session, bagList, baseInfo);
				}
			});
		},
		// 出售逻辑
		function(session, bagList, baseInfo, callback) {
			var itemID,
				num,
				index,
				cost = 0,
				price = 0,
				isEquip = false,
				itemNum;
			// 遍历检查道具是否均可以卖
			for (index in sellgroup) {
				if (sellgroup.hasOwnProperty(index)) {
					num = Number.parseInt(sellgroup[index]);
					if (isNaN(num) || num < 0) {
						callback(ErrCode.ITEM_SELL_NUM_ERROR, 'item num error ' + num);
						return;
					}
					// 索引转id
					if (bagList.equipList.hasOwnProperty(index)) {
						itemID = bagList.equipList[index].id;
						isEquip = true;
					} else {
						itemID = index;
					}
					if (!Item.hasOwnProperty(itemID) || Item[itemID].sell !== 1) {
						callback(ErrCode.ITEM_CANNOT_SELL, 'itemid error ' + itemID);
						return;
					}
					price = Number.parseInt(Item[itemID].price);
					if (isNaN(price) || price < 0) {
						callback(ErrCode.ITEM_SELL_PRICE_WRONG, 'price error ' + price);
						return;
					}
					// 检查背包内是否有这么多这种道具
					itemNum = bag.getItemNum(index, bagList);
					if (itemNum < num) {
						tiny.log.trace('sellItemGroup', 'itemnum less', index, itemNum, num, JSON.stringify(bagList));
						callback(ErrCode.ITEM_NUM_NOT_ENOUGH, itemNum + ' ' + num);
						return;
					}
					// 删除道具
					if (!bag.delItem(index, num, bagList)) {
						tiny.log.trace('sellItemGroup', 'del item fail', index, num, JSON.stringify(bagList));
						callback(ErrCode.ITEM_DEL_ERROR, index + ' ' + itemNum);
						return;
					}
					if (isEquip) {
						equipHandle.offEquip(baseInfo, index);
					}
					cost = cost + price * num;
				}
			}
			callback(null, session, bagList, baseInfo, cost);
		},
		// 保存背包信息
		function(session, bagList, baseInfo, cost, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err);
				} else {
					callback(null, session, baseInfo, cost);
				}
			});
		},
		// 保存baseinfo
		function(session, baseInfo, cost, callback) {
			playerHandle.addPlayerGold(cost, baseInfo);
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BASEINFO_ERROR, err);
				} else {
					callback(null, null, cost);
				}
			});
		}
	], function(err, errStr, cost) {
		if (err) {
			tiny.log.error("sellItemGroup", err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.cost = cost;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var compose = function(inArgs, onResponse, current) {
	var itemID = inArgs.item,
		num = inArgs.num,
		composeID = inArgs.composeid,
		outArgs = {};

	outArgs.target = 0;
	outArgs.num = 0;
	outArgs.costings = {};

	async.waterfall([
		// 检查合成ID是否正确
		function(callback) {
			if (!Item.hasOwnProperty(itemID)) {
				callback(ErrCode.ITEM_NO_THIS_ITEM);
			} else {
				if (Item[itemID].compose !== composeID || !Compose.hasOwnProperty(composeID)) {
					callback(ErrCode.ITEM_COMPOSE_ID_ERROR, Item[itemID].compose + ' ' + composeID);
				} else {
					callback(null);
				}
			}
		},
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取背包数据
		function(session, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err);
				} else {
					callback(null, session, bagList);
				}
			});
		},
		// 合成道具
		function(session, bagList, callback) {
			var i,
				targetID = Compose[composeID].itemId,
				demand = Compose[composeID].demandItemId,
				targetNum = 0,
				costings = {},
				itemNum = 0,
				deItem,
				demandOK = false,
				room = 0,
				delOK = false,
				composeOK = false,
				retCode;

			composeOK = true;
			for (i = 0; i < num; ++i) {
				// 检查背包内是否有此道具，并检查合成id是否正确
				itemNum = bag.getItemNum(itemID, bagList);
				if (itemNum <= 0) {
					tiny.log.debug('compose', itemID, itemNum);
					retCode = ErrCode.ITEM_COMPOSE_NOT_IN_BAG;
					break;
				}
				demandOK = true;
				// 检查背包内合成材料是否足够
				for (deItem in demand) {
					if (demand.hasOwnProperty(deItem)) {
						itemNum = bag.getItemNum(demand[deItem][1], bagList);
						if (itemNum < demand[deItem][2]) {
							demandOK = false;
							retCode = ErrCode.ITEM_COMPOSE_DEMAND_LESS;
							tiny.log.debug('compose', itemNum, demand[deItem][1], demand[deItem][2]);
							break;
						}
					}
				}
				if (!demandOK) {
					break;
				}
				// 检查背包空格够不够
				room = bag.getLeftRoom(bagList);
				if (room < 1) {
					tiny.log.debug('compose', 'no enough room', room);
					retCode = ErrCode.BAG_FREE_ROOM_LIMIT;
					break;
				}
				// 扣除合成材料并产生新道具添加进背包
				delOK = true;
				for (deItem in demand) {
					if (demand.hasOwnProperty(deItem)) {
						if (!bag.delItem(demand[deItem][1], demand[deItem][2], bagList)) {
							tiny.log.error('compose', 'delItem fail', demand[deItem][1], demand[deItem][2]);
							composeOK = false;
							delOK = false;
							retCode = ErrCode.BAG_FREE_ROOM_LIMIT;
							break;
						}
						if (costings.hasOwnProperty(demand[deItem][1])) {
							costings[demand[deItem][1]] = costings[demand[deItem][1]] + demand[deItem][2];
						} else {
							costings[demand[deItem][1]] = demand[deItem][2];
						}
					}
				}
				if (delOK && bag.addItem(targetID, 1, bagList)) {
					// 修改返回参数中的消耗和合成数量
					targetNum = targetNum + 1;
				} else {
					tiny.log.error('compose', 'addItem fail', targetID);
					composeOK = false;
					retCode = ErrCode.BAG_ADD_ERROR;
					break;
				}
			}
			if (composeOK) {
				callback(null, session, bagList, targetID, targetNum, costings);
			} else {
				callback(retCode, '');
			}
		},
		// 保存背包
		function(session, bagList, targetID, targetNum, costings, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err);
				} else {
					callback(null, null, targetID, targetNum, costings);
				}
			});
		}
	], function(err, errStr, targetID, targetNum, costings) {
		if (err) {
			tiny.log.error("compose", err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			outArgs.target = targetID;
			outArgs.num = targetNum;
			outArgs.costings = costings;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var useItem = function(inArgs, onResponse, current) {
	var itemID = inArgs.item,
		outArgs = {},
		useType,
		bagAdd = {};

	outArgs.item = itemID;
	outArgs.heroInfoList = {};

	async.waterfall([
		// 检查合成ID是否正确
		function(callback) {
			if (!Item.hasOwnProperty(itemID)) {
				callback(ErrCode.ITEM_NO_THIS_ITEM);
			} else {
				if (Item[itemID].hasOwnProperty('userTeyp')) {
					useType = Item[itemID].userTeyp;
					callback(null);
				} else {
					callback(ErrCode.ITEM_USE_NO_EFFECT, itemID + ' ' + 'have no effect userTeyp');
				}
			}
		},
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取玩家baseinfo
		function(session, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					callback(null, session, baseInfo);
				}
			});
		},
		// 获取背包数据
		function(session, baseInfo, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err);
				} else {
					callback(null, session, baseInfo, bagList);
				}
			});
		},
		// 使用道具
		function(session, baseInfo, bagList, callback) {
			var i,
				exp = 0,
				gold = 0,
				diamond = 0,
				action = 0,
				itemNum = 0;

			// 检查背包内是否有此道具，并检查合成id是否正确
			itemNum = bag.getItemNum(itemID, bagList);
			if (itemNum <= 0) {
				callback(ErrCode.ITEM_COMPOSE_NOT_IN_BAG, 'bag have no this item ' + itemID);
				return;
			}
			// 扣除道具并保存效果
			if (!bag.delItem(itemID, 1, bagList)) {
				callback(ErrCode.ITEM_DEL_ERROR, 'delItem fail ' + itemID);
			} else {
				// 检查道具效果是否能产生
				for (i in useType) {
					if (useType.hasOwnProperty(i)) {
						tiny.log.debug("useType", useType[i][1]);
						if (useType[i][1] === UseType.ADD_ACTION) {
							action = utils.checkValue(useType[i][2]);
							baseInfo.action = utils.addValue(baseInfo.action + action);
						} else if (useType[i][1] === UseType.ADD_TEAM_EXP) {
							exp = utils.checkValue(useType[i][2]);
							playerHandle.addPlayerExp(exp, baseInfo);
						} else if (useType[i][1] === UseType.ADD_GOLD) {
							gold = utils.checkValue(useType[i][2]);
							baseInfo.gold = utils.addValue(baseInfo.gold + gold);
						} else if (useType[i][1] === UseType.ADD_DIAMOND) {
							diamond = utils.checkValue(useType[i][2]);
							baseInfo.diamond = utils.addValue(baseInfo.diamond + diamond);
						} else if (useType[i][1] === UseType.OPEN_BOX) {
							if (!itemfunc.dropPool(useType[i][2], baseInfo, bagList, bagAdd)) {
								callback(ErrCode.DROP_POLL_ERROR, useType[i][2]);
								return;
							}
						} else if (useType[i][1] === UseType.ADD_HERO_EXP) {
							// 增加英雄经验
							if (!inArgs.hasOwnProperty("heroId") || inArgs.heroId <= 0) {
								callback(ErrCode.FAILURE, "useItemHeroExp heroId is error " + inArgs.heroId);
								return;
							}
							exp = utils.checkValue(useType[i][2]);
							heroHandle.getHeroInfo(session.area, session.uuid, inArgs.heroId, function(err, heroInfo) {
								if (err) {
									callback(ErrCode.FAILURE, "useItemHeroExp fail get");
									return;
								}
								heroHandle.addHeroExp(exp, heroInfo);
								heroHandle.setHeroInfo(session.area, session.uuid, inArgs.heroId, heroInfo, function(err) {
									if (err) {
										callback(ErrCode.FAILURE, "useItemHeroExp fail get");
										return;
									}
									outArgs.heroInfoList[inArgs.heroId] = heroInfo;
									callback(null, session, baseInfo, bagList);
								});
							});
						} else if (useType[i][1] === UseType.ADD_HERO) {
							// 临时创建英雄，道具爆英雄逻辑
							outArgs.heroInfoList = heroHandle.createHeroTmp(session.area, session.uuid, useType[i][2]);
						}
					}
				}
				callback(null, session, baseInfo, bagList);
			}
		},
		// 保存baseinfo
		function(session, baseInfo, bagList, callback) {
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BASEINFO_ERROR, err);
				} else {
					outArgs.baseInfo = baseInfo;
					/*
					outArgs.baseinfo = {};
					outArgs.baseinfo.gold = baseInfo.gold;
					outArgs.baseinfo.action = baseInfo.action;
					outArgs.baseinfo.diamond = baseInfo.diamond;
					outArgs.baseinfo.curExp = baseInfo.curExp;
					outArgs.baseinfo.level = baseInfo.level;
					*/
					callback(null, session, bagList);
				}
			});
		},
		// 保存背包
		function(session, bagList, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err);
				} else {
					outArgs.bagItem = bagAdd;
					callback(null, null);
				}
			});
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error("useItem", err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var test_addItem = function(inArgs, onResponse, current) {
	var itemID = inArgs.itemid,
		outArgs = {},
		equip,
		item;
	outArgs.item = {};

	async.waterfall([
		// 检查道具ID是否正确
		function(callback) {
			if (!Item.hasOwnProperty(itemID)) {
				callback(ErrCode.ITEM_NO_THIS_ITEM);
			} else {
				callback(null);
			}
		},
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取背包数据
		function(session, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err);
				} else {
					callback(null, session, bagList);
				}
			});
		},
		// 增加道具
		function(session, bagList, callback) {
			var room, temp;
			// 检查背包空格够不够
			room = bag.getLeftRoom(bagList);
			if (room < 1) {
				tiny.log.debug('test_addItem', 'no enough room', room);
				callback(ErrCode.BAG_FREE_ROOM_LIMIT);
				return;
			}
			if (parseInt(Item[itemID].itemTepy, 10) === ItemMainType.EQUIP) {
				temp = equipHandle.createEquip(itemID);
				if (!bag.addEquip(temp.index, temp.equipInfo, bagList)) {
					callback(ErrCode.BAG_ADD_ERROR);
					return;
				}
				equip = {};
				// equip[temp.index] = JSON.stringify(temp.equipInfo);
				equip[temp.index] = temp.equipInfo;
				callback(null, session, bagList, equip);
			} else {
				if (!bag.addItem(itemID, 1, bagList)) {
					callback(ErrCode.BAG_ADD_ERROR);
					return;
				}
				item = {};
				// item[itemID] = JSON.stringify({"num": 1});
				item[itemID] = {"num": 1};
				callback(null, session, bagList, item);
			}
		},
		// 保存背包
		function(session, bagList, thing, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err);
				} else {
					outArgs.item = thing;
					callback(null, null);
				}
			});
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error("test_addItem", err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var test_addValue = function(inArgs, onResponse, current) {
	var type = inArgs.type,
		value = inArgs.value,
		outArgs = {};
	outArgs.type = type;
	outArgs.value = 0;

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取玩家baseinfo
		function(session, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					callback(null, session, baseInfo);
				}
			});
		},
		// 增加数值
		function(session, baseInfo, callback) {
			var action, gold, diamond;
			if (type === UseType.ADD_ACTION) {
				action = utils.checkValue(value);
				baseInfo.action = utils.addValue(baseInfo.action + action);
				callback(null, session, baseInfo, baseInfo.action);
			} else if (type === UseType.ADD_GOLD) {
				gold = utils.checkValue(value);
				baseInfo.gold = utils.addValue(baseInfo.gold + gold);
				callback(null, session, baseInfo, baseInfo.gold);
			} else if (type=== UseType.ADD_DIAMOND) {
				diamond = utils.checkValue(value);
				baseInfo.diamond = utils.addValue(baseInfo.diamond + diamond);
				callback(null, session, baseInfo, baseInfo.diamond);
			} else {
				callback(null, session, baseInfo, 0);
			}
		},
		// 保存baseinfo
		function(session, baseInfo, value, callback) {
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BASEINFO_ERROR, err);
				} else {
					outArgs.value = value;
					callback(null, null);
				}
			});
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error("test_addValue", err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

module.exports = {
"sellItemGroup" : sellItemGroup,
"compose" : compose,
"useItem" : useItem,
"test_addItem" : test_addItem,
"test_addValue" : test_addValue
};
