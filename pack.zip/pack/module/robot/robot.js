var heroHandle =   require('../dataprocess/hero_handle');
var playerHandle = require('../dataprocess/player_handle');
var equipHandle =  require('../dataprocess/equip_handle');
var tiny = require('../../tiny');
var utils = require('../utils');

var convertRobotHeroInfo = function(RobotHero) {
	var robotHeroList = {}, i;
	for (i in RobotHero) {
		if (RobotHero.hasOwnProperty(i)) {
			robotHeroList[i] = heroHandle.createHero(RobotHero[i].HeroId);
			robotHeroList[i].level = RobotHero[i].Level;
			robotHeroList[i].star = RobotHero[i].Star;
			robotHeroList[i].quality = RobotHero[i].Quality;
			robotHeroList[i].skillSlotList = {
				1 : {level : RobotHero[i].SkillLv[1]},
				2 : {level : RobotHero[i].SkillLv[2]},
				3 : {level : RobotHero[i].SkillLv[3]},
				4 : {level : RobotHero[i].SkillLv[4]},
				5 : {level : RobotHero[i].SkillLv[5]},
				6 : {level : RobotHero[i].SkillLv[6]}
			};
		}
	}
	return robotHeroList;
};

var convertRobotEquip = function(RobotEquip) {
	var robotEquipList = {}, i, tmp;
	for (i in RobotEquip) {
		if (RobotEquip.hasOwnProperty(i)) {
			//tiny.log.error("......heroHandle", JSON.stringify(heroHandle.createHero(10012)));
			tmp = equipHandle.createEquip(RobotEquip[i].EquipId);
			//tiny.log.debug("createEquip", JSON.stringify(tmp));
			robotEquipList[i] = tmp.equipInfo;
			//robotEquipList[i] = {};
			robotEquipList[i].star = RobotEquip[i].star;
		}
	}
	return robotEquipList;
};

var convertRobot = function(Robot) {
	var robotInfo = [], i, tmpRobot, RobotHero, RobotEquip;
	RobotEquip = convertRobotEquip(require('../config/RobotEquip'));
	RobotHero = convertRobotHeroInfo(require('../config/RobotHero'));
	for (i in Robot) {
		if (Robot.hasOwnProperty(i)) {
			tmpRobot = {};
			tmpRobot.uuid = i;
			tmpRobot.area = 0;
			tmpRobot.teamList = {
				1 :  RobotHero[Robot[i].Hero1],
				2 :  RobotHero[Robot[i].Hero2],
				3 :  RobotHero[Robot[i].Hero3],
			};
			tmpRobot.teamList[1].pos = 4;
			tmpRobot.teamList[2].pos = 5;
			tmpRobot.teamList[3].pos = 6;
			tmpRobot.equipList = {
				1 : {
					1 : RobotEquip[Robot[i].Equip1[1]],
					2 : RobotEquip[Robot[i].Equip1[2]],
					3 : RobotEquip[Robot[i].Equip1[3]],
					4 : RobotEquip[Robot[i].Equip1[4]],
					5 : RobotEquip[Robot[i].Equip1[5]],
					6 : RobotEquip[Robot[i].Equip1[6]],
				},
				2 : {
					1 : RobotEquip[Robot[i].Equip2[1]],
					2 : RobotEquip[Robot[i].Equip2[2]],
					3 : RobotEquip[Robot[i].Equip2[3]],
					4 : RobotEquip[Robot[i].Equip2[4]],
					5 : RobotEquip[Robot[i].Equip2[5]],
					6 : RobotEquip[Robot[i].Equip2[6]],
				},
				3 : {
					1 : RobotEquip[Robot[i].Equip3[1]],
					2 : RobotEquip[Robot[i].Equip3[2]],
					3 : RobotEquip[Robot[i].Equip3[3]],
					4 : RobotEquip[Robot[i].Equip3[4]],
					5 : RobotEquip[Robot[i].Equip3[5]],
					6 : RobotEquip[Robot[i].Equip3[6]],
				},
			};
			tmpRobot.power = heroHandle.getHeroPower(tmpRobot.teamList[1]) +
			heroHandle.getHeroPower(tmpRobot.teamList[2]) + heroHandle.getHeroPower(tmpRobot.teamList[3]);
			robotInfo.push(tmpRobot);
		}
	}
	return robotInfo;
};

var Robot;
var getRobot = function() {
	if (!Robot) {
		Robot = convertRobot(require('../config/Robot'));
	}
};

exports.getRobotInfoByPower = function(id) {
	var i;
	getRobot();
	for (i in Robot) {
		if (Robot.hasOwnProperty(i)) {
			if (Robot[i].power === id) {
				return Robot[i];
			}
		}
	}
	tiny.log.error("Robot getRobotInfoByPower error", id);
	return utils.randomArray(Robot);
};

exports.getReadRobot = function(robot) {
	var tmpRobot = {};
	tmpRobot.uuid = robot.uuid;
	tmpRobot.area = robot.area;
	tmpRobot.teamList = robot.teamList;
	tmpRobot.equipList = robot.equipList;
	tmpRobot.power = robot.power;
	return tmpRobot;
};

exports.getRobotPlayerInfo = function(ua) {
	var i = ua.uuid % Robot.length, tmpRobot;
	getRobot();
	if (ua.id) {
		tmpRobot = exports.getRobotInfoByPower(ua.id);
	} else {
		if (!Robot.hasOwnProperty(i)) {
			tiny.log.error("Robot getPlayerInfo error", ua.uuid);
			tmpRobot = utils.randomArray(Robot);
		} else {
			tmpRobot = Robot[i];
		}
	}
	tmpRobot = exports.getReadRobot(tmpRobot);
	tmpRobot.uuid = ua.uuid;
	tmpRobot.area = ua.area;
	return tmpRobot;
};

exports.getPvpDayReward = function(pos, num) {
	getRobot();
	return { diamand : 100, ticketWeek : 100 };
};

exports.checkIsRobot = function(uuid) {
	getRobot();
	if (uuid < 200) {
		return true;
	}
	return false;
};

exports.displayRobot = function() {
	var i;
	getRobot();
	for (i = 0; i < Robot.length; i++) {
		tiny.log.debug("Robot", i, JSON.stringify(Robot[i]));
	}
};
