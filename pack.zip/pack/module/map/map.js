var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var ConstMap = Const.MAP;
var MapElement = ConstMap.ELEMENT_STATE;
var tiny = require('../../tiny');
var mapHandle = require('../dataprocess/map_handle');
var playerHandle = require('../dataprocess/player_handle');
var heroHandle = require('../dataprocess/hero_handle');
var equipHandle = require('../dataprocess/equip_handle');
var utils = require('../utils');
var fight = require('../fight/fight');
var bag = require('../bag/bag');
// 配置表
var Reward = require('../config/reward');
var Drop = require('../config/drop');
var MapInfo = require('../config/mapinfo');
var BuffExp = require('../config/buffexp');
var ElementType = require('../config/elementtype');
var Chest = require('../config/chest');
var Monsterchal = require('../config/monsterchal');
var Unknow = require('../config/unknow');
var BuffStation = require('../config/buffstation');
var Shop = require('../config/shop');
var WatchTower = require('../config/watchtower');
var Sellgroup = require('../config/sellgroup');
var Exit = require('../config/exit');
var LObstacle = require('../config/lobstacle');
var ChestChoo = require('../config/chestchoo');
var GuaJi = require('../config/guaji');
var Mission = require('../config/mission');
var BattleResult = require('../config/battleresult');
var Supply = require('../config/supply');
var LSurface = require('../config/lsurface');

var itemfunc = require('../item/item');
var afkfunc = require('../afk/afk');

function formatMapJson(mapJson) {
	var build, surface, i, j, id, name, type, x, y, sx, sy;
	if (utils.isObject(mapJson)) {
		mapJson.element = {};
		mapJson.surface = {};
		mapJson.obsMap = {};
		mapJson.obsMap.width = 0;
		mapJson.obsMap.data = {};
		if (mapJson.hasOwnProperty("layers")) {
			for (i = 0; i < mapJson.layers.length; ++i) {
				if (mapJson.layers[i].name === ConstMap.MAP_LAYER_NAME.BUILDING_LAYER) {
					build = mapJson.layers[i].objects;
					if (utils.isArray(build)) {
						for (j = 0; j < build.length; ++j) {
							if (utils.isObject(build[j]) &&
								build[j].hasOwnProperty("id")) {
								id = build[j].id;
								name = build[j].name;
								type = build[j].type;
								x = build[j].gridx;
								y = build[j].gridy;
								mapJson.element[id] = {};
								mapJson.element[id].name = name;
								mapJson.element[id].type = type;
								mapJson.element[id].x = x;
								mapJson.element[id].y = y;
							}
						}
					}
				}
				if (mapJson.layers[i].name === ConstMap.MAP_LAYER_NAME.SURFACE) {
					surface = mapJson.layers[i].objects;
					if (utils.isArray(surface)) {
						for (j = 0; j < surface.length; ++j) {
							if (utils.isObject(surface[j]) &&
								surface[j].hasOwnProperty("id")) {
								name = surface[j].name;
								id = surface[j].id;
								type = surface[j].type;
								tiny.log.trace('sx, sy 1', name, id, type, LSurface.hasOwnProperty(name));
								if (LSurface.hasOwnProperty(name) && LSurface[name].hasOwnProperty('Area')) {
									tiny.log.trace('sx, sy2', sx, sy, surface[j].gridx + LSurface[name].Area[1], surface[j].gridy + LSurface[name].Area[2]);
									for (sx = surface[j].gridx; sx < (surface[j].gridx + LSurface[name].Area[1]); ++sx) {
										for (sy = surface[j].gridy; sy < (surface[j].gridy + LSurface[name].Area[2]); ++sy) {
											if (!mapJson.surface.hasOwnProperty(sx)) {
												mapJson.surface[sx] = {};
											}
											mapJson.surface[sx][sy] = {};
											mapJson.surface[sx][sy].id = id;
											mapJson.surface[sx][sy].name = name;
											mapJson.surface[sx][sy].type = type;
											tiny.log.trace('sx, sy', name);
										}
									}
								}
							}
						}
					}
					tiny.log.trace('sx, sy', JSON.stringify(mapJson.surface));
				}
				if (mapJson.layers[i].name === ConstMap.MAP_LAYER_NAME.OBS_LAYER) {
					mapJson.obsMap.data = mapJson.layers[i].data;
					mapJson.obsMap.width = mapJson.layers[i].width;
				}
			}
		}
	}
}

function getFormatSellgroup() {
	var i, group, pro;
	Sellgroup.formatGroup = {};
	for (i in Sellgroup) {
		if (Sellgroup.hasOwnProperty(i)) {
			group = Sellgroup[i].Group;
			pro = Sellgroup[i].Pro;
			tiny.log.trace("getFormatSellgroup$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ = ", group);
			if (!Sellgroup.formatGroup.hasOwnProperty(group)) {
				Sellgroup.formatGroup[group] = [];
			}
			Sellgroup.formatGroup[group].push([pro, i]);
		}
	}
	tiny.log.trace("getFormatSellgroup = ", JSON.stringify(Sellgroup.formatGroup));
}
getFormatSellgroup();

// // 对地图json文件的预处理
// var map_01 = require('../config/map/01.json');
// var map_02 = require('../config/map/02.json');
// formatMapJson(map_01);
// formatMapJson(map_02);
// var mapJsonMap = {
// 	"01.json" : map_01,
// 	"02.json" : map_02,
// };


function getReward(rewardid, mapInfo, baseInfo, bagList, bagAdd) {
	var gold,
		exp,
		action,
		drop,
		sign;

	if (Reward.hasOwnProperty(rewardid)) {
		// 给奖励
		gold = parseInt(Reward[rewardid].Money, 10);
		exp = parseInt(Reward[rewardid].Experience, 10);
		action = parseInt(Reward[rewardid].AP, 10);
		drop = parseInt(Reward[rewardid].Drop, 10);
		sign = parseInt(Reward[rewardid].Sign, 10);
		if (exp) {
			playerHandle.addPlayerExp(exp, baseInfo);
			// 增加英雄经验
			// 升级英雄经验
			heroHandle.updateHerosExpInHeroList(baseInfo.area, baseInfo.uuid, playerHandle.getHeroIdsFromPosList(baseInfo.posList), exp, function(err) {
				if (err) {
					tiny.log.debug('updateHerosExpInHeroList error', err);
				}
			});
		}
		if (gold) {
			playerHandle.addPlayerGold(gold, baseInfo);
		}
		if (action) {
			playerHandle.addPlayerAction(action, baseInfo);
		}
		tiny.log.trace("mapInfo.sign = ", JSON.stringify(mapInfo.sign), sign, mapInfo.sign.hasOwnProperty(sign));
		if (mapInfo.sign.hasOwnProperty(sign)) {
			mapInfo.sign[sign] = 1;
		}
		if (Drop.hasOwnProperty(drop)) {
			if (!itemfunc.dropPool(drop, baseInfo, bagList, bagAdd)) {
				return false;
			}
		}
	}

	return true;
}

function getRelStep(bufflist, pos, step) {
	var relStep;
	if (bufflist[pos].value > step) {
		relStep = step;
		bufflist[pos].value = bufflist[pos].value - step;
	} else {
		relStep = bufflist[pos].value;
		bufflist.splice(pos, 1);
	}
	return relStep;
}

exports.calcBuffAction = function(costObj, bufflist) {
	tiny.log.trace("calcBuffAction start", bufflist, JSON.stringify(bufflist), costObj);
	var step = costObj.length,
		i, j, k, buffStep, arg, newCost = 0, buffid;
	for (i = 0; i < bufflist.length; ++i) {
		buffid = bufflist[i].id;
		tiny.log.trace("calcBuffAction bufflist.length = ", bufflist.length);
		if (BuffExp.hasOwnProperty(buffid)) {
			if (BuffExp[buffid].hasOwnProperty("Effecttype")) {
				if (BuffExp[buffid].Effecttype === ConstMap.BUFFTYPE.WALK_COST_PERCENT_MINUS) {
					tiny.log.trace("calcBuffAction clac = ", step);
					arg = BuffExp[buffid].EffectArg;
					buffStep = getRelStep(bufflist, i, step);
					for (j = 0; j < buffStep; ++j) {
						costObj[j] = costObj[j] - Math.ceil(arg * costObj[j] / 100);
					}
					// newCost = costObj[0] - Math.ceil(buffStep * arg * walkPerCost / 100);
					tiny.log.trace("calcBuffAction clac end = ", step, buffStep, arg);
				}
				if (BuffExp[buffid].Effecttype === ConstMap.BUFFTYPE.WALK_COST_EVERY_MINUS) {
					tiny.log.trace("calcBuffAction clac = ", step);
					arg = BuffExp[buffid].EffectArg;
					buffStep = getRelStep(bufflist, i, step);
					for (j = 0; j < buffStep; ++j) {
						costObj[j] = costObj[j] - arg;
					}
					// newCost = costObj[0] - Math.floor(buffStep * arg);
					tiny.log.trace("calcBuffAction clac end = ", step, buffStep, arg);
				}
				if (BuffExp[buffid].Effecttype === ConstMap.BUFFTYPE.WALK_COST_PERCENT_ADD) {
					tiny.log.trace("calcBuffAction clac = ", step);
					arg = BuffExp[buffid].EffectArg;
					buffStep = getRelStep(bufflist, i, step);
					for (j = 0; j < buffStep; ++j) {
						costObj[j] = costObj[j] + Math.floor(arg * costObj[j] / 100);
					}
					// newCost = costObj[0] + Math.floor(buffStep * arg * walkPerCost / 100);
					tiny.log.trace("calcBuffAction clac end = ", step, buffStep, arg);
				}
			}
		}
	}
	for (k = 0; k < costObj.length; ++k) {
		if (costObj[k] > 0) {
			newCost = newCost + costObj[k];
		}
	}
	tiny.log.trace("calcBuffAction end", newCost);
	return newCost;
};

function checkPosInArea(posX, posY, x, y, area) {
	if (posX >= x && (posX < x + area[1]) &&
		posY >= y && (posY <= y + area[2])) {
		return true;
	}
	return false;
}

function checkPosAroundArea(posX, posY, x, y, area) {
	if ((posY >= y && (posY < y + area[2]) &&
		(x - posX === 1 || posX - x === area[1])) ||
		(posX >= x && (posX < x + area[1]) &&
		(y - posY === 1 || posY - y === area[2]))) {
		return true;
	}
	return false;
}

// 验证两点是否紧邻
function checkNearPoint(x1, y1, x2, y2) {
	if ((Math.abs(x1 - x2) === 1 && y1 === y2) ||
		((Math.abs(y1 - y2) === 1) && x1 === x2)) {
		return true;
	}
	return false;
}

function getElementSheet(type) {
	var sheetName, sheet;
	if (ElementType.hasOwnProperty(type)) {
		sheetName = ElementType[type].SheetName;
		if (sheetName) {
			tiny.log.trace('getElementSheet', sheetName);
			try {
				sheet = require('../config/' + sheetName);
			} catch (e) {
				tiny.log.error('getElementSheet', sheetName);
				return null;
			}
		}
	}
	return sheet;
}

function checkUidEffectArea(uidObject, px, py) {
	var name = parseInt(uidObject.name, 10),
		type = uidObject.type,
		x = uidObject.x,
		y = uidObject.y,
		sheet, area, obstacle;

	tiny.log.trace('checkUidEffectArea', name, type, x, y, px, py);
	if (!name || !type) {
		tiny.log.trace('checkUidEffectArea', 1);
		return false;
	}

	sheet = getElementSheet(type);
	if (sheet) {
		if (!sheet.hasOwnProperty(name)) {
			tiny.log.trace('checkUidEffectArea', 3, name, sheet.hasOwnProperty(name), sheet.hasOwnProperty(parseInt(name, 10)));
			return false;
		}
		area = sheet[name].Area;
		obstacle = sheet[name].Obstacle;
		tiny.log.trace('checkUidEffectArea', JSON.stringify(area), obstacle);
		if (parseInt(obstacle, 10) === ConstMap.OBSTACLE.AROUND) {
			return checkPosAroundArea(px, py, x, y, area);
		}
		if (parseInt(obstacle, 10) === ConstMap.OBSTACLE.IN) {
			return checkPosInArea(px, py, x, y, area);
		}
		if (parseInt(obstacle, 10) === ConstMap.OBSTACLE.DIS) {
			return true;
		}
	}

	tiny.log.trace('checkUidEffectArea', 4);
	return false;
}


function getUidPreCondition(type, name) {
	if (type === ConstMap.MAP_UID_TYPE.CHEST) {	// 资源宝箱
		return Chest[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.MONSTERCHAL) { // 挑战怪
		return Monsterchal[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.UNKNOW) { // 未知建筑
		return Unknow[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.BUFFSTATION) { // buff点
		return BuffStation[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.SHOP) { // 商店
		return Shop[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.WATCHTOWER) { // 瞭望塔
		return WatchTower[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.EXIT) { // exit
		return Exit[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.LOBSTACLE) { // 可移除障碍
		return LObstacle[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.LOBSTACLE) { // 选择资源
		return ChestChoo[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.NOR_AFK ||
		type === ConstMap.MAP_UID_TYPE.TIME_AFK ||
		type === ConstMap.MAP_UID_TYPE.TIME_BOSS_AFK) { // 挂机点
		return GuaJi[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.MISSION) { // 选择资源
		return Mission[name].Precondition;
	}
	if (type === ConstMap.MAP_UID_TYPE.SUPPLY) {
		return Supply[name].Precondition;
	}
	return undefined;
}

function getUidInitState(type) {
	type = parseInt(type, 10);
	if (type === ConstMap.MAP_UID_TYPE.CHEST) {
		return MapElement.CHEST.NO_PICKING;
	}
	if (type === ConstMap.MAP_UID_TYPE.MONSTERCHAL) {
		return MapElement.MONSTERCHAL.NO_FIGHTING;
	}
	if (type === ConstMap.MAP_UID_TYPE.UNKNOW) {
		return MapElement.UNKNOW.NO_TOUCHING;
	}
	if (type === ConstMap.MAP_UID_TYPE.BUFFSTATION) {
		return MapElement.BUFFSTATION.NO_PICKING;
	}
	if (type === ConstMap.MAP_UID_TYPE.SHOP) {
		return MapElement.SHOP.NO_TOUCHING;
	}
	if (type === ConstMap.MAP_UID_TYPE.WATCHTOWER) {
		return MapElement.WATCHTOWER.NO_PICKING;
	}
	if (type === ConstMap.MAP_UID_TYPE.EXIT) {
		return MapElement.EXIT.NO_FIGHTING;
	}
	if (type === ConstMap.MAP_UID_TYPE.LOBSTACLE) {
		return MapElement.LOBSTACLE.EXIST;
	}
	if (type === ConstMap.MAP_UID_TYPE.CHESTCHOO) {
		return MapElement.CHESTCHOO.NO_CHOO;
	}
	if (type === ConstMap.MAP_UID_TYPE.NOR_AFK) {
		return MapElement.NOR_AFK.NORMAL;
	}
	if (type === ConstMap.MAP_UID_TYPE.TIME_AFK) {
		return MapElement.TIME_AFK.OPEN;
	}
	if (type === ConstMap.MAP_UID_TYPE.TIME_BOSS_AFK) {
		return MapElement.TIME_BOSS_AFK.OPEN;
	}
	if (type === ConstMap.MAP_UID_TYPE.MISSION) {
		return MapElement.MISSION.OPEN;
	}
	if (type === ConstMap.MAP_UID_TYPE.SUPPLY) {
		return MapElement.SUPPLY.OPEN;
	}
	return 0;
}

function checkFinalState(type, state) {
	type = parseInt(type, 10);
	if (type === ConstMap.MAP_UID_TYPE.CHEST) {
		return state === MapElement.CHEST.PICKED;
	}
	if (type === ConstMap.MAP_UID_TYPE.MONSTERCHAL) {
		return state === MapElement.MONSTERCHAL.FIGHTED;
	}
	if (type === ConstMap.MAP_UID_TYPE.UNKNOW) {
		return state === MapElement.UNKNOW.GOT;
	}
	if (type === ConstMap.MAP_UID_TYPE.BUFFSTATION) {
		return state === MapElement.BUFFSTATION.PICKED;
	}
	if (type === ConstMap.MAP_UID_TYPE.SHOP) {
		return state === MapElement.SHOP.TOUCHED;
	}
	if (type === ConstMap.MAP_UID_TYPE.WATCHTOWER) {
		return state === MapElement.WATCHTOWER.PICKED;
	}
	if (type === ConstMap.MAP_UID_TYPE.EXIT) {
		return state === MapElement.EXIT.CAN_OUT;
	}
	if (type === ConstMap.MAP_UID_TYPE.LOBSTACLE) {
		return state === MapElement.LOBSTACLE.REMOVE;
	}
	if (type === ConstMap.MAP_UID_TYPE.CHESTCHOO) {
		return state === MapElement.CHESTCHOO.CHOOD;
	}
	if (type === ConstMap.MAP_UID_TYPE.NOR_AFK) {
		return state === MapElement.NOR_AFK.ADDITION;
	}
	if (type === ConstMap.MAP_UID_TYPE.TIME_AFK) {
		return state === MapElement.TIME_AFK.CLOSE;
	}
	if (type === ConstMap.MAP_UID_TYPE.TIME_BOSS_AFK) {
		return state === MapElement.TIME_BOSS_AFK.CLOSE;
	}
	if (type === ConstMap.MAP_UID_TYPE.MISSION) {
		return state === MapElement.MISSION.END;
	}
	if (type === ConstMap.MAP_UID_TYPE.SUPPLY) {
		return false;
	}
	return false;
}

function checkAreaName(name) {
	var i;
	for (i = 1; i <= ConstMap.MAX_DEATH_AREA; ++i) {
		if (name === ('area' + i)) {
			return i;
		}
	}
	return 0;
}

function apProc(mapid, hpRate, ap, out, mapInfo, afklist) {
	var cost = 0, i, j, sheet, file, initX, initY, pos,
		areaPos, bArea = false, bornUid, bChange = false,
		x, y, afkuid, width;
	tiny.log.trace('apProc', hpRate, ap);
	if (!MapInfo.hasOwnProperty(mapid)) {
		return false;
	}

	if (hpRate !== undefined && hpRate !== null) {
		hpRate = parseInt(hpRate * 100, 10);
		for (j in BattleResult) {
			if (BattleResult.hasOwnProperty(j) &&
				BattleResult[j].hasOwnProperty("RemainingBlood") &&
				BattleResult[j].RemainingBlood.hasOwnProperty("1") &&
				BattleResult[j].RemainingBlood.hasOwnProperty("2")) {
				if (hpRate > BattleResult[j].RemainingBlood[1] &&
					hpRate <= BattleResult[j].RemainingBlood[2]) {
					cost = parseInt(BattleResult[j].SupplyDeduction, 10);
				}
			}
		}
		if (!cost) {
			cost = 0;
		}
		tiny.log.trace('apProc11111', hpRate, cost);
	}
	out.args.cost = cost;
	ap = ap - cost;
	if (ap <= 0) {
		if (MapInfo[mapid].hasOwnProperty("InfoFile")) {
			sheet = MapInfo[mapid].InfoFile;
		}
		if (MapInfo[mapid].hasOwnProperty("InitPos")) {
			initX = MapInfo[mapid].InitPos['1'];
			initY = MapInfo[mapid].InitPos['2'];
		}
		file = exports.getMapJson(sheet);
		if (file && file.hasOwnProperty("layers")) {
			for (i = 0; i < file.layers.length; ++i) {
				areaPos = checkAreaName(file.layers[i].name);
				if (areaPos !== 0) {
					// 将玩家转移到指定的afk点去
					width = file.layers[i].width;
					pos = mapInfo.x + mapInfo.y * width;
					if (file.layers[i].data[pos] !== 0) {
						bArea = true;
						break;
					}
				}
			}
		}
		if (bArea && MapInfo[mapid].hasOwnProperty("Area" + areaPos)) {
			bornUid = MapInfo[mapid]["Area" + areaPos];
			if (file && file.hasOwnProperty("element")) {
				if (file.element.hasOwnProperty(bornUid)) {
					// 优先选择指定的afk点，如果没有开启就随便找一个开启的
					// 如果都没有开启，就传回初始点
					if (afklist.hasOwnProperty(mapid)) {
						if (afklist[mapid].hasOwnProperty(bornUid)) {
							afkuid = bornUid;
						}
						// for (j = 0; j < afklist[mapid].length; ++j) {
						// 	afkuid = afklist[mapid][j];
						// 	if (afklist[mapid][j] === bornUid) {
						// 		break;
						// 	}
						// }
					}
				}
				if (afkuid && file.element.hasOwnProperty(afkuid)) {
					x = file.element[afkuid].x;
					y = file.element[afkuid].y;
					if (x && y) {
						mapInfo.x = x;
						mapInfo.y = y;
						out.args.x = x;
						out.args.y = y;
						bChange = true;
					}
				}
			}
		}

		if (!bChange) {
			// 没有转移成功就把玩家丢回地图初始点
			mapInfo.x = initX;
			mapInfo.y = initY;
			out.args.x = initX;
			out.args.y = initY;
			out.args.ap = ConstMap.MAX_AP_VALUE;
		} else {
			out.args.ap = 0;
		}
		out.args.bChange = 1;
		return true;
	}
	out.args.ap = ap;
	tiny.log.trace('apProc222222222', JSON.stringify(out));
	return false;
}

function fightProc(mapid, monsterid, playerInfo, rewardid,
	uid, mapInfo, baseInfo, bagList, bagAdd, out, nextstate,
	uidContent, type, ap, afklist) {
	var bChange = false;
	fight.fightEnemy(monsterid, playerInfo, function(err, result, seed, hpRate) {
		if (!err) {
			if (parseInt(result, 10) === Const.FIGHT_RESULT.SUCCESS) { // 成功改变状态
				if (getReward(rewardid, mapInfo, baseInfo, bagList, bagAdd)) {
					// getReward(rewardid, mapInfo, baseInfo, bagList, bagAdd);
					out.state = nextstate;
					out.args.bagAdd = bagAdd;
					uidContent.state = nextstate;
					tiny.log.trace("fightProc", JSON.stringify(out));
					apProc(mapid, hpRate, ap, out, mapInfo, uid, afklist);
				} else {
					out.errCode = ErrCode.BAG_FREE_ROOM_LIMIT;
					tiny.log.trace("fightProc111111", JSON.stringify(out));
					return;
				}
			} else { // 失败不改状态
				out.state = uidContent.state;
				out.args.bagAdd = {};
				// 把玩家回退到前一格
				tiny.log.trace("fightProc22222222", type, mapInfo.lastX, mapInfo.lastY);
				bChange = apProc(mapid, hpRate, ap, out, mapInfo, uid, afklist);
				// if (parseInt(type, 10) === ConstMap.MAP_UID_TYPE.MONSTERCHAL && !bChange &&
				// 	mapInfo.lastX && mapInfo.lastY) {
				// 	// 对玩家前一格做检查
				// 	mapInfo.x = mapInfo.lastX;
				// 	mapInfo.y = mapInfo.lastY;
				// 	out.args.x = mapInfo.x;
				// 	out.args.y = mapInfo.y;
				// }
				tiny.log.trace("fightProc3333333333", JSON.stringify(out));
			}

			out.args.monsterid = monsterid;
			out.args.rewardid = rewardid;
			out.args.result = result;
			out.args.seed = seed;

			mapInfo.uidList[uid] = uidContent;
			tiny.log.trace('fightProc44444444444', JSON.stringify(out));
		} else {
			tiny.log.trace('fightProc error', err);
		}
	});
}

function checkUidPos(mapid, x, y, uid, uidList, out) {
	var sheet, file;
	// 取对应地图的element
	if (MapInfo.hasOwnProperty(mapid)) {
		if (MapInfo[mapid].hasOwnProperty("InfoFile")) {
			sheet = MapInfo[mapid].InfoFile;
		}
	}
	tiny.log.trace('checkUidPos', sheet, mapid, x, y, uid, uidList, out);
	file = exports.getMapJson(sheet);
	if (file && file.hasOwnProperty("element")) {
		if (file.element.hasOwnProperty(uid)) {
			// 检查玩家是否在uid有效范围内
			if (checkUidEffectArea(file.element[uid], x, y)) {
				out.type = file.element[uid].type;
				out.name = file.element[uid].name;
				tiny.log.trace('checkUidPos', uid, sheet, out.type, out.name);
				if (uidList.hasOwnProperty(uid)) {
					out.uidContent = uidList[uid];
				} else {
					out.uidContent = {};
					out.uidContent.state = getUidInitState(out.type);
					out.uidContent.args = {};
				}
				return true;
			}
		}
	}
	tiny.log.trace('checkUidPos fail');
	return false;
}

function checkPreContion(type, name, mapInfo, baseInfo, condArgs) {
	var condition, i, conType, conValue;
	condition = getUidPreCondition(type, name);
	if (condition) {
		for (i in condition) {
			if (condition.hasOwnProperty(i)) {
				conType = parseInt(condition[i][1], 10);
				conValue = parseInt(condition[i][2], 10);
				tiny.log.trace("checkPreContion", i, JSON.stringify(condition[i]), conType, conValue);
				if (conType === ConstMap.PRE_CONDITION.TEAM_LVL) {
					if (baseInfo.level < conValue) {
						if (!condArgs.hasOwnProperty("unpass")) {
							condArgs.unpass = {};
						}
						condArgs.unpass[conType] = conValue;
					} else {
						if (!condArgs.hasOwnProperty("pass")) {
							condArgs.pass = {};
						}
						condArgs.pass[conType] = conValue;
					}
				}
				if (conType === ConstMap.PRE_CONDITION.FIGHT_POWER) {
					// 战斗力公式
				}
				if (conType === ConstMap.PRE_CONDITION.SIGN) {
					if (!mapInfo.sign.hasOwnProperty(conValue) ||
						mapInfo.sign[conValue] <= 0) {
						if (!condArgs.hasOwnProperty("unpass")) {
							condArgs.unpass = {};
						}
						condArgs.unpass[conType] = conValue;
					} else {
						if (!condArgs.hasOwnProperty("pass")) {
							condArgs.pass = {};
						}
						condArgs.pass[conType] = conValue;
					}
				}
			}
		}
	}
	return condArgs;
}

function processChest(uidContent, uid, name, mapInfo, baseInfo, bagList, out, nextstate) {
	var bagAdd = {};
	if (parseInt(uidContent.state, 10) === MapElement.CHEST.NO_PICKING &&
		nextstate === MapElement.CHEST.PICKED) {
		if (Chest.hasOwnProperty(name) && Chest[name].hasOwnProperty('Reward')) {
			if (getReward(parseInt(Chest[name].Reward, 10), mapInfo, baseInfo, bagList, bagAdd)) {
				out.state = MapElement.CHEST.PICKED;
				out.args.rewardid = Chest[name].Reward;
				out.args.bagAdd = bagAdd;
				uidContent.state = MapElement.CHEST.PICKED;
				mapInfo.uidList[uid] = uidContent;
				tiny.log.trace('processUid555', JSON.stringify(out));
			} else {
				out.errCode = ErrCode.BAG_FREE_ROOM_LIMIT;
			}
		}
	}
}

function processMonsterchal(mapid, uidContent, uid, name, mapInfo, baseInfo,
	bagList, playerInfo, out, type, ap, afklist, nextstate) {
	var monsterid, rewardid;
	if (parseInt(uidContent.state, 10) === MapElement.MONSTERCHAL.NO_FIGHTING &&
		nextstate === MapElement.MONSTERCHAL.FIGHTED) {
		if (Monsterchal.hasOwnProperty(name) &&
			Monsterchal[name].hasOwnProperty('Monster') &&
			Monsterchal[name].hasOwnProperty('Reward')) {
			monsterid = Monsterchal[name].Monster;
			rewardid = Monsterchal[name].Reward;
			// 开始战斗
			fightProc(mapid, monsterid, playerInfo, rewardid,
				uid, mapInfo, baseInfo, bagList, {}, out,
				nextstate, uidContent, type, ap, afklist);
		}
	}
}

function processUnknow(mapid, uidContent, uid, name, mapInfo, baseInfo,
	bagList, playerInfo, out, type, ap, afklist, nextstate) {
	var sum = 0, ret, pro1, pro2, monster, reward, bagAdd = {};
	tiny.log.trace("processUnknow", uidContent.state, name, JSON.stringify(out), JSON.stringify(out.args), nextstate);
	// out.args.aa = 1;
	// tiny.log.trace("processUnknow", JSON.stringify(out), JSON.stringify(out.args));

	if (parseInt(uidContent.state, 10) === MapElement.UNKNOW.NO_TOUCHING &&
		nextstate === MapElement.UNKNOW.TOUCHED) {
		if (Unknow.hasOwnProperty(name)) {
			pro1 = Unknow[name].Probability1;	// 奖励概率
			pro2 = Unknow[name].Probability2;	// 打怪概率
			monster = Unknow[name].Monster;
			reward = Unknow[name].Reward;
			tiny.log.trace("processUnknow1111", pro1, pro2, monster, reward, utils.isNumber(pro1), utils.isNumber(pro2), pro1 >= 0, pro2 >= 0);
			if (utils.isNumber(pro1) && utils.isNumber(pro2) &&
				pro1 >= 0 && pro2 >= 0) {
				sum = pro1 + pro2;
				ret = utils.randomInt(1, sum);
				tiny.log.trace("processUnknow222", sum, ret);
				if (ret <= pro1) { // 给奖励
					out.args.randRet = ConstMap.UNKNOW_STATE.AWARD;
					// out.args["test"] = ConstMap.UNKNOW_STATE.AWARD;
					tiny.log.trace("processUnknow22211111", JSON.stringify(out), JSON.stringify(out.args));
				} else { // 打怪
					out.args.randRet = ConstMap.UNKNOW_STATE.FIGHT;
					uidContent.args.monster = monster;
					tiny.log.trace("processUnknow2221112222", JSON.stringify(out));
				}
				out.state = MapElement.UNKNOW.TOUCHED;
				uidContent.state = MapElement.UNKNOW.TOUCHED;
				uidContent.args.randRet = out.args.randRet;
				uidContent.args.reward = reward;
				mapInfo.uidList[uid] = uidContent;
			}
			tiny.log.trace("processUnknow3333333", JSON.stringify(out));
		}
	} else if (parseInt(uidContent.state, 10) === MapElement.UNKNOW.TOUCHED &&
			   nextstate === MapElement.UNKNOW.GOT) {
		ret = uidContent.args.randRet;
		tiny.log.trace("processUnknow44444444", ret);
		if (parseInt(ret, 10) === ConstMap.UNKNOW_STATE.AWARD) {
			reward = uidContent.args.reward;
			tiny.log.trace("processUnknow5555555", reward);
			if (getReward(reward, mapInfo, baseInfo, bagList, bagAdd)) {
				out.state = MapElement.UNKNOW.GOT;
				out.args.rewardid = reward;
				out.args.bagAdd = bagAdd;
				uidContent.state = MapElement.UNKNOW.GOT;
				mapInfo.uidList[uid] = uidContent;
			} else {
				out.errCode = ErrCode.BAG_FREE_ROOM_LIMIT;
			}
			tiny.log.trace("processUnknow66666666", JSON.stringify(out));
		}
		if (parseInt(ret, 10) === ConstMap.UNKNOW_STATE.FIGHT) {
			monster = uidContent.args.monster;
			reward = uidContent.args.reward;
			// 开始战斗
			tiny.log.trace("processUnknow777777", monster, reward);
			fightProc(mapid, monster, playerInfo, reward,
				uid, mapInfo, baseInfo, bagList, {},
				out, MapElement.UNKNOW.GOT, uidContent, type, ap, afklist);
			tiny.log.trace("processUnknow8888888", JSON.stringify(out));
		}
	}
}

function processBuffStation(uidContent, uid, name, mapInfo, bufflist, out, nextstate) {
	var buffid, value, newBuff = {};
	if (parseInt(uidContent.state, 10) === MapElement.BUFFSTATION.NO_PICKING &&
		nextstate === MapElement.BUFFSTATION.PICKED) {
		if (BuffStation.hasOwnProperty(name)) {
			buffid = BuffStation[name].Buff;
			if (BuffExp.hasOwnProperty(buffid)) {
				value = BuffExp[buffid].TimeArg;
				newBuff.id = buffid;
				newBuff.value = value;
				bufflist.push(newBuff);
				tiny.log.trace('processBuffStation', JSON.stringify(newBuff), JSON.stringify(bufflist));
				out.state = MapElement.BUFFSTATION.PICKED;
				out.args.buffid = buffid;
				uidContent.state = MapElement.BUFFSTATION.PICKED;
				mapInfo.uidList[uid] = uidContent;
				tiny.log.trace('processBuffStation111', JSON.stringify(out));
			}
		}
	}
}

function processShop(uidContent, uid, name, mapInfo, out, nextstate) {
	var sellgroup, i, rand, num, shopInfo = {};
	tiny.log.trace('processShop', uid, name, uidContent.state);
	if (parseInt(uidContent.state, 10) === MapElement.SHOP.NO_TOUCHING &&
		nextstate === MapElement.SHOP.TOUCHED) {
		if (Shop.hasOwnProperty(name)) {
			sellgroup = Shop[name].SellGroup;
			tiny.log.trace('processShop22', JSON.stringify(sellgroup), JSON.stringify(Sellgroup.formatGroup));
			if (sellgroup) {
				for (i in sellgroup) {
					if (sellgroup.hasOwnProperty(i)) {
						if (Sellgroup.formatGroup.hasOwnProperty(sellgroup[i])) {
							tiny.log.trace('processShop33', sellgroup[i], JSON.stringify(Sellgroup.formatGroup[sellgroup[i]]));
							rand = utils.randomScope(Sellgroup.formatGroup[sellgroup[i]]);
							if (Sellgroup.hasOwnProperty(rand)) {
								num = Sellgroup[rand].Num;
								if (utils.isNumber(num) && num > 0) {
									shopInfo[rand] = num;
								}
							}
						}
					}
				}
				out.state = MapElement.SHOP.TOUCHED;
				out.args.shopInfo = shopInfo;
				uidContent.state = MapElement.SHOP.TOUCHED;
				uidContent.args.shopInfo = shopInfo;
				mapInfo.uidList[uid] = uidContent;

				tiny.log.trace('processShop', JSON.stringify(out));
			}
		}
	}

}

function processWatchTower(uidContent, uid, name, mapInfo, out, nextstate) {
	if (parseInt(uidContent.state, 10) === MapElement.WATCHTOWER.NO_PICKING &&
		nextstate === MapElement.WATCHTOWER.PICKED) {	// 第一次进瞭望塔
		if (WatchTower.hasOwnProperty(name)) {
			out.state = MapElement.WATCHTOWER.PICKED;
			uidContent.state = MapElement.WATCHTOWER.PICKED;
			mapInfo.uidList[uid] = uidContent;
		}
	}
	if (parseInt(uidContent.state, 10) === MapElement.WATCHTOWER.PICKED) {	// 重复进入瞭望塔
		if (WatchTower.hasOwnProperty(name)) {
			out.state = MapElement.WATCHTOWER.PICKED;
			uidContent.state = MapElement.WATCHTOWER.PICKED;
			mapInfo.uidList[uid] = uidContent;
		}
	}
}

function processExit(mapid, uidContent, uid, name, mapInfo,
	playerInfo, baseInfo, bagList, out, type, ap, afklist, nextstate) {
	var nextMap, monsterid, rewardid;
	tiny.log.trace('processExit name=', name, utils.getValueType(name), nextstate);
	if (!Exit.hasOwnProperty(name)) {
		tiny.log.trace('processExit name=', name);
		return;
	}
	monsterid = Exit[name].Monster;
	nextMap = Exit[name].Map;
	rewardid = Exit[name].Reward;
	tiny.log.trace('processExit uidContent.state =', monsterid, nextMap, rewardid, uidContent.state);
	if (parseInt(uidContent.state, 10) === MapElement.EXIT.NO_FIGHTING &&
		nextstate === MapElement.EXIT.CAN_OUT) {
		// 打怪成功转移状态
		fightProc(mapid, monsterid, playerInfo, rewardid,
			uid, mapInfo, baseInfo, bagList, {}, out,
			nextstate, uidContent, type, ap, afklist);
		tiny.log.trace("processExit1111", JSON.stringify(out));
	} else if (parseInt(uidContent.state, 10) === MapElement.EXIT.CAN_OUT &&
		 	   nextstate === MapElement.EXIT.CAN_OUT) {
		tiny.log.trace('processExit nextMap=', nextMap, utils.getValueType(nextMap));
		if (MapInfo.hasOwnProperty(nextMap)) {
			out.state = MapElement.EXIT.CAN_OUT;
			out.args.nextmap = nextMap;
			uidContent.state = MapElement.EXIT.CAN_OUT;
			mapInfo.uidList[uid] = uidContent;
		}
		tiny.log.trace("processExit22222", JSON.stringify(out));
	}
}

function processLObstacle(uidContent, uid, name, mapInfo, bagList, out, nextstate) {
	var item;
	tiny.log.trace('processLObstacle name=', name, utils.getValueType(name), nextstate);
	if (!LObstacle.hasOwnProperty(name)) {
		tiny.log.trace('processLObstacle name=', name);
		return;
	}
	item = LObstacle[name].ToItem;
	tiny.log.trace('processLObstacle = ', item, uidContent.state, parseInt(uidContent.state, 10), MapElement.LOBSTACLE.EXIST);
	if (parseInt(uidContent.state, 10) === MapElement.LOBSTACLE.EXIST &&
		nextstate === MapElement.LOBSTACLE.REMOVE) {
		out.args.ok = 0;
		out.args.costItem = item;
		if (!bag.delItem(item, 1, bagList)) {
			out.state = uidContent.state;
			tiny.log.trace('processLObstacle', 'del item fail', item, JSON.stringify(bagList));
			return;
		}

		out.state = MapElement.LOBSTACLE.REMOVE;
		out.args.ok = 1;
		uidContent.state = MapElement.LOBSTACLE.REMOVE;
		mapInfo.uidList[uid] = uidContent;
		tiny.log.trace("processLObstacle", JSON.stringify(out));
	}
}

function processChestChoo(uidContent, uid, name, mapInfo,
	baseInfo, bagList, out, in_args, nextstate) {
	var choo = parseInt(in_args.choo, 10), reward, prop, propStr, rewardStr, rand, bagAdd = {};
	tiny.log.trace('processChestChoo name=', name, utils.getValueType(name), nextstate);
	if (!ChestChoo.hasOwnProperty(name)) {
		tiny.log.trace('processChestChoo name1=', name);
		return;
	}
	tiny.log.trace('processChestChoo name2=', uidContent.state);
	if (choo && (parseInt(uidContent.state, 10) === MapElement.CHESTCHOO.NO_CHOO) &&
		nextstate === MapElement.CHESTCHOO.CHOOD) {
		propStr = 'Probability' + choo;
		rewardStr = 'Reward' + choo;
		tiny.log.trace('processChestChoo name3=', ChestChoo[name].hasOwnProperty(propStr), propStr);
		if (ChestChoo[name].hasOwnProperty(propStr)) {
			prop = parseInt(ChestChoo[name][propStr], 10);
			reward = parseInt(ChestChoo[name][rewardStr], 10);
			rand = utils.randomInt(1, 100);
			tiny.log.trace('processChestChoo rand', prop, reward, rand);
			if (rand <= prop) {
				if (getReward(reward, mapInfo, baseInfo, bagList, bagAdd)) {
					out.state = MapElement.CHESTCHOO.CHOOD;
					out.args.choo = choo;
					out.args.reward = reward;
					out.args.bagAdd = bagAdd;
					uidContent.state = MapElement.CHESTCHOO.CHOOD;
					mapInfo.uidList[uid] = uidContent;
					tiny.log.trace("processChestChoo getReward succes ", JSON.stringify(out));
				} else {
					out.errCode = ErrCode.BAG_FREE_ROOM_LIMIT;
				}
				tiny.log.trace("processChestChoo getReward fail ", JSON.stringify(out));
				return;
			}

			tiny.log.trace('processChestChoo rand fail');
			out.state = MapElement.CHESTCHOO.CHOOD;
			out.args.choo = choo;
			uidContent.state = MapElement.CHESTCHOO.CHOOD;
			mapInfo.uidList[uid] = uidContent;
		}
	}
}

function processSupply(uidContent, uid, name, mapInfo, baseInfo, out, in_args) {
	tiny.log.trace('processSupply', 111, uid, name, JSON.stringify(mapInfo),
		JSON.stringify(baseInfo), JSON.stringify(in_args));
	var point = parseInt(in_args.point, 10), price = 0, gold = 0;
	if (!Supply.hasOwnProperty(name)) {
		tiny.log.trace('processSupply name=', name);
		return;
	}
	if (point < 0) {
		tiny.log.trace('processSupply point < 0 =', point);
		return;
	}
	if (parseInt(uidContent.state, 10) === MapElement.SUPPLY.OPEN) {
		price = parseInt(Supply[name].Price, 10);
		gold = point * price * (-1);
		tiny.log.trace('processSupply gold', gold, point, price, baseInfo.gold);
		if (playerHandle.addPlayerGold(gold, baseInfo)) {
			out.state = MapElement.SUPPLY.OPEN;
			out.args.ok = 1;
			out.args.ap = utils.addAPValue(out.args.ap + point);
			out.args.gold = baseInfo.gold;
		} else {
			out.state = MapElement.SUPPLY.OPEN;
			out.args.ok = 0;
		}
	}
}

function processAfk(uidContent, uid, name, mapid, mapInfo,
	curAkfMapInfo, afkObj, playerInfo, baseInfo, bagList,
	ap, type, out, nextstate) {
	var monster;
	tiny.log.trace('processAfk =', uid, name, type, JSON.stringify(afkObj));

	if (!GuaJi.hasOwnProperty(name)) {
		tiny.log.trace('processAfk name=', name);
		return;
	}

	// normal挂机点
	if (type === ConstMap.MAP_UID_TYPE.NOR_AFK) {
		tiny.log.trace('processAfk type1=', type, parseInt(uidContent.state, 10), nextstate);
		if (parseInt(uidContent.state, 10) === MapElement.NOR_AFK.NORMAL &&
			nextstate === MapElement.NOR_AFK.NORMAL) { // 挂机点迁移
			// 判断挂机点是否是限时挂机点4，5，如果是则设置上一挂机点状态
			if (afkfunc.changeAfk(afkObj, mapid, uid, name, curAkfMapInfo)) {
				out.state = MapElement.NOR_AFK.NORMAL;
				out.args.curAfker = afkObj.curAfker;
				tiny.log.trace('processAfk JSON out', JSON.stringify(out));
				uidContent.state = MapElement.NOR_AFK.NORMAL;
				mapInfo.uidList[uid] = uidContent;
			}
		}
		if (parseInt(uidContent.state, 10) === MapElement.NOR_AFK.NORMAL &&
			nextstate === MapElement.NOR_AFK.ADDITION &&
			afkObj.curAfker.mapid === mapid &&
			afkObj.curAfker.uid === uid) { // buff怪挑战
			monster = GuaJi[name].Boss;
			fightProc(mapid, monster, playerInfo, 0,
				uid, mapInfo, baseInfo, bagList, {},
				out, nextstate, uidContent, type, ap, afkObj.afklist);
		}
		if (parseInt(uidContent.state, 10) === MapElement.NOR_AFK.ADDITION) {
			// 判断挂机点是否是限时挂机点4，5，如果是则设置上一挂机点状态
			if (afkfunc.changeAfk(afkObj, mapid, uid, name, curAkfMapInfo)) {
				out.state = MapElement.NOR_AFK.ADDITION;
				out.args.curAfker = afkObj.curAfker;
				uidContent.state = MapElement.NOR_AFK.ADDITION;
				mapInfo.uidList[uid] = uidContent;
			}
		}
	}

	// 限时挂机点4
	if (type === ConstMap.MAP_UID_TYPE.TIME_AFK) {
		tiny.log.trace('processAfk type2=', type, parseInt(uidContent.state, 10), nextstate);
		if (parseInt(uidContent.state, 10) === MapElement.TIME_AFK.OPEN &&
			nextstate === MapElement.TIME_AFK.OPEN) { // 挂机点迁移
			// 判断挂机点是否是限时挂机点4，5，如果是则设置上一挂机点状态
			if (afkfunc.changeAfk(afkObj, mapid, uid, name, curAkfMapInfo)) {
				out.state = MapElement.TIME_AFK.OPEN;
				out.args.curAfker = afkObj.curAfker;
				uidContent.state = MapElement.TIME_AFK.OPEN;
				mapInfo.uidList[uid] = uidContent;
			}
		}
	}

	// 限时挂机点5
	if (type === ConstMap.MAP_UID_TYPE.TIME_BOSS_AFK) {
		tiny.log.trace('processAfk type3=', type, parseInt(uidContent.state, 10), nextstate);
		if (parseInt(uidContent.state, 10) === MapElement.TIME_BOSS_AFK.OPEN &&
			nextstate === MapElement.TIME_BOSS_AFK.OPEN) { // 挂机点迁移
			// 判断挂机点是否是限时挂机点4，5，如果是则设置上一挂机点状态
			if (afkfunc.changeAfk(afkObj, mapid, uid, name, curAkfMapInfo)) {
				out.state = MapElement.TIME_BOSS_AFK.OPEN;
				out.args.curAfker = afkObj.curAfker;
				uidContent.state = MapElement.TIME_BOSS_AFK.OPEN;
				mapInfo.uidList[uid] = uidContent;
			}
		}
		if (parseInt(uidContent.state, 10) === MapElement.TIME_BOSS_AFK.OPEN &&
			nextstate === MapElement.TIME_BOSS_AFK.CLOSE) { // 挑战结束怪
			monster = GuaJi[name].BossLimit;
			fightProc(mapid, monster, playerInfo, 0,
				uid, mapInfo, baseInfo, bagList, {},
				out, nextstate, uidContent, type, ap, afkObj.afklist);
			if (out.state > 0 &&
				out.args.result === Const.FIGHT_RESULT.SUCCESS) { // 成功了切换挂机点回上一个nor的
				// 给剩余奖励

				afkfunc.backLastNormalAfk(afkObj, curAkfMapInfo);
				out.args.curAfker = afkObj.curAfker;
			}
		}
	}
}

function processMission(uidContent, uid, name, mapid, mapInfo, playerInfo,
	baseInfo, bagList, type, ap, out, in_args, afklist) {
	tiny.log.trace('processMission =', uid, name, JSON.stringify(in_args));
	var floor = parseInt(in_args.floor, 10), maxFloor, monster, monsterList,
		reward = 0, nextstate = MapElement.MISSION.OPEN;
	if (!Mission.hasOwnProperty(name)) {
		tiny.log.trace('processMission name=', name);
		return;
	}

	if (parseInt(uidContent.state, 10) === MapElement.MISSION.OPEN) {

		monsterList = Mission[name].Monster;
		maxFloor = parseInt(Mission[name].Floors, 10);
		if (!maxFloor || floor > maxFloor ||
			!monsterList || !monsterList.hasOwnProperty(floor)) {
			tiny.log.trace('processMission floor=', floor, maxFloor, monsterList);
			return;
		}
		monster = monsterList[floor];
		if (floor === maxFloor) {
			reward = Mission[name].Reward;
			nextstate = MapElement.MISSION.END;
		}
		fightProc(mapid, monster, playerInfo, reward,
				uid, mapInfo, baseInfo, bagList, {},
				out, nextstate, uidContent, type, ap, afklist);
		if (out.state > 0 &&
			out.args.result === Const.FIGHT_RESULT.SUCCESS) { // 成功了记录层数
			mapInfo.uidList[uid].args.floor = floor;
		}
	}
}

// 修正地形影响消耗
function updateTerrain(cost, x, y, surface) {
	var surid = 0, apTime = 1;
	tiny.log.trace('updateTerrain 1', cost, x, y, JSON.stringify(surface));
	if (surface.hasOwnProperty(x) && surface[x].hasOwnProperty(y)) {
		surid = surface[x][y].name;
		tiny.log.trace('updateTerrain 2', surid);
		if (LSurface.hasOwnProperty(surid)) {
			if (LSurface[surid].hasOwnProperty("APCostTimes")) {
				apTime = LSurface[surid].APCostTimes;
				tiny.log.trace('updateTerrain 3', apTime);
			}
		}
	}
	tiny.log.trace('updateTerrain 4', cost * apTime);
	return cost * apTime;
}


//
// 如果是限时的判断挂机点状态，如果是关闭状态不给奖励
// 如果是在线类型

// ===================================================以下为导出函数===================================================

exports.getMapJson = function(name) {
	try {
		var map = require('../config/map/' + name);
		// 对地图json文件的预处理
		formatMapJson(map);
		return map;
	} catch(e) {
		tiny.log.error('getMapJson', 'no this map', name);
		return undefined;
	}
};

exports.checkMapid = function(mapid) {
	if (mapid === undefined || mapid <= 0) {
		return false;
	}
	return true;
};

exports.getAfkID = function(mapid, uid) {
	var sheet, file;
	if (!MapInfo.hasOwnProperty(mapid)) {
		return undefined;
	}

	if (MapInfo[mapid].hasOwnProperty("InfoFile")) {
		sheet = MapInfo[mapid].InfoFile;
	}

	file = exports.getMapJson(sheet);
	if (file && file.hasOwnProperty("element")) {
		if (file.element.hasOwnProperty(uid)) {
			return file.element[uid].name;
		}
	}
	return undefined;
};


// exports.checkAfk = function(area, uuid, afkid, callback) {
// 	var i;
// 	mapHandle.getAfkList(area, uuid, function(err, list) {
// 		if (err) {
// 			callback(err);
// 		} else {
// 			for (i = 0; i < list.length; ++i) {
// 				if (list[i] == afkid) {
// 					callback(null);
// 					return;
// 				}
// 			}
// 			callback('no this afk id in list');
// 		}
// 	});
// };

exports.createNewMap = function(session, mapid, cb) {
	var info = {}, i;
	info.mapid = mapid;
	info.x = 0;
	info.y = 0;
	info.lastX = 0;
	info.lastY = 0;
	info.uidList = {};
	info.sign = {};
	if (MapInfo.hasOwnProperty(mapid)) {
		if (MapInfo[mapid].hasOwnProperty("InitPos")) {
			info.x = MapInfo[mapid].InitPos['1'];
			info.y = MapInfo[mapid].InitPos['2'];
			info.lastX = info.x;
			info.lastY = info.y;
		}
		if (MapInfo[mapid].hasOwnProperty("MapSign")) {
			for (i in MapInfo[mapid].MapSign) {
				if (MapInfo[mapid].MapSign.hasOwnProperty(i)) {
					info.sign[MapInfo[mapid].MapSign[i]] = 0;
				}
			}
		}
	}

	mapHandle.setMapInfo(session.area, session.uuid, mapid, info, function(err, data) {
		if (err) {
			cb(ErrCode.CREATE_MAPINFO_FAILURE, err);
		} else {
			cb(null, utils.getObject(data));
		}
	});
};


/*
uidObject = {
	name = 配置表key
	type = 配置表类型
	x =
	y =
}
px,py 为玩家起点坐标
start = { 为开始走的起点
	x =
	y =
}
验证玩家是否在建筑内，验证起点坐标是否紧贴建筑
*/
exports.checkPathUID = function(uidObject, px, py, start) {
	var name = parseInt(uidObject.name, 10),
		type = uidObject.type,
		x = uidObject.x,
		y = uidObject.y,
		sheet, area;

	tiny.log.trace('checkPathUID', name, type, x, y, px, py);
	if (!name || !type) {
		tiny.log.trace('checkPathUID', 1);
		return false;
	}

	sheet = getElementSheet(type);
	if (sheet) {
		if (!sheet.hasOwnProperty(name)) {
			tiny.log.trace('checkPathUID', 3);
			return false;
		}
		area = sheet[name].Area;
		tiny.log.trace('checkPathUID', JSON.stringify(area));
		if (checkPosInArea(px, py, x, y, area)) {
			return checkPosAroundArea(start.x, start.y, x, y, area);
		}
	}

	tiny.log.trace('checkPathUID', 4);
	return false;
};

// 计算路径消耗
exports.calcPathCost = function(walkPerCost, mapInfo, mapJson, path, uid) {
	var cost = [], j = 0, pos,
		lastX = mapInfo.lastX,
		lastY = mapInfo.lastY,
		x = mapInfo.x,
		y = mapInfo.y;

	tiny.log.info('walk1111111111', lastX, lastY, path.length);
	if (uid >= 0) {
		// cost = cost + updateTerrain(walkPerCost, path[0].x, path[0].y, mapJson.surface);
		cost.push(updateTerrain(walkPerCost, path[0].x, path[0].y, mapJson.surface));
		lastX = x;
		lastY = y;
		x = path[0].x;
		y = path[0].y;
		j = 1;
	}

	while (j < path.length) {
		if (path[j].hasOwnProperty('x') && path[j].hasOwnProperty('y')) {
			tiny.log.info('walk22222222', path[j].x, path[j].y);
			if (checkNearPoint(x, y, path[j].x, path[j].y)) {
				pos = path[j].x + path[j].y * mapJson.obsMap.width;
				if (mapJson.obsMap.data.hasOwnProperty(pos) && mapJson.obsMap.data[pos] === 0) {
					lastX = x;
					lastY = y;
					x = path[j].x;
					y = path[j].y;
					// cost = cost + updateTerrain(walkPerCost, x, y, mapJson.surface);
					cost.push(updateTerrain(walkPerCost, x, y, mapJson.surface));
				} else {
					break;
				}
			} else {
				break;
			}
		} else {
			break;
		}
		++j;
	}

	tiny.log.info('walk enddddddddddddddd', x, y, lastX, lastY, cost, j);
	mapInfo.x = x;
	mapInfo.y = y;
	mapInfo.lastX = lastX;
	mapInfo.lastY = lastY;

	return cost;
};

// 处理uid事件
exports.processUid = function(mapid, mapInfo, curAkfMapInfo, baseInfo, bagList,
	fightInfo, bufflist, uid, nextstate, in_args, out, ap, afkObj) {
	var checkState = false, check = {},
		uidContent, type, name;

	out.state = -1;
	out.errCode = ErrCode.MAP_UID_PROCESS_ERROR;
	out.args = {};
	out.args.ap = ap;
	out.args.condition = {};

	// 检查玩家当前位置是否在uid的有效范围内
	if (checkUidPos(mapid, mapInfo.x, mapInfo.y, uid, mapInfo.uidList, check)) {
		uidContent = check.uidContent;
		type = parseInt(check.type, 10);
		name = parseInt(check.name, 10);
		// 判断uid下一状态是否一致
		if (uidContent) {
			tiny.log.trace('processUid222', uidContent.state, nextstate, type);
			if (ElementType.hasOwnProperty(type)) {
				if (ElementType[type].hasOwnProperty("State")) {
					if (ElementType[type].State.hasOwnProperty(uidContent.state)) {
						checkState = true;
						tiny.log.trace('processUid222 3333');
						// if (ElementType[type].State.hasOwnProperty(uidContent.state + 1)) {
						// 	tiny.log.trace('processUid333', ElementType[type].State[uidContent.state + 1]);
						// 	if (parseInt(ElementType[type].State[uidContent.state + 1], 10) === parseInt(nextstate, 10)) {
						// 		tiny.log.trace('processUid444', nextstate);
						// 		checkState = true;
						// 	}
						// } else {
						// 	if (parseInt(ElementType[type].State[uidContent.state], 10) === parseInt(nextstate, 10)) {
						// 		tiny.log.trace('processUid444', nextstate);
						// 		checkState = true;
						// 	}
						// }
					}
				}
			}
		}

		// 处理状态改变逻辑
		if (checkState) {
			checkPreContion(type, name, mapInfo, baseInfo, out.args.condition);
			if (out.args.condition.hasOwnProperty("unpass")) {
				out.state = uidContent.state;
				tiny.log.info('processUid', 'check pre contion fail', JSON.stringify(out.args.condition));
				return;
			}

			if (type === ConstMap.MAP_UID_TYPE.CHEST) {	// 资源宝箱
				processChest(uidContent, uid, name, mapInfo,
					baseInfo, bagList, out, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.MONSTERCHAL) { // 挑战怪
				processMonsterchal(mapid, uidContent, uid, name, mapInfo,
					baseInfo, bagList, fightInfo, out, type, ap, afkObj.afklist, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.UNKNOW) { // 未知建筑
				tiny.log.trace("processUid", out, JSON.stringify(out), out.args, JSON.stringify(out.args));
				processUnknow(mapid, uidContent, uid, name, mapInfo,
					baseInfo, bagList, fightInfo, out, type, ap, afkObj.afklist, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.BUFFSTATION) { // buff点
				processBuffStation(uidContent, uid, name, mapInfo,
					bufflist, out, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.SHOP) { // 商店
				processShop(uidContent, uid, name, mapInfo, out, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.WATCHTOWER) { // 瞭望塔
				processWatchTower(uidContent, uid, name, mapInfo, out, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.EXIT) { // exit
				processExit(mapid, uidContent, uid, name, mapInfo,
					fightInfo, baseInfo, bagList, out, type, ap,
					afkObj.afklist, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.LOBSTACLE) { // 可除障碍
				processLObstacle(uidContent, uid, name, mapInfo, bagList, out, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.CHESTCHOO) { // 选择资源
				processChestChoo(uidContent, uid, name, mapInfo, baseInfo, bagList, out, in_args, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.SUPPLY) { // 补给站
				processSupply(uidContent, uid, name, mapInfo, baseInfo, out, in_args);
			} else if (type === ConstMap.MAP_UID_TYPE.NOR_AFK ||
					   type === ConstMap.MAP_UID_TYPE.TIME_AFK ||
					   type === ConstMap.MAP_UID_TYPE.TIME_BOSS_AFK) { // 挂机点
				processAfk(uidContent, uid, name, mapid, mapInfo,
					curAkfMapInfo, afkObj, fightInfo, baseInfo, bagList,
					ap, type, out, nextstate);
			} else if (type === ConstMap.MAP_UID_TYPE.MISSION) { // 连续挑战
				processMission(uidContent, uid, name, mapid, mapInfo, fightInfo,
					baseInfo, bagList, type, ap, out, in_args, afkObj.afklist);
			} else {
				tiny.log.error("processUid", "not support", type);
			}
		}
	}

	tiny.log.trace('processUid', 'check end', JSON.stringify(out));
};

exports.buyMapThings = function(mapid, key, uid, mapInfo, baseInfo, bagList) {
	var check = {}, uidContent, type, name, price, num, cost, item;
	// 检查玩家当前位置否在uid范围内
	if (checkUidPos(mapid, mapInfo.x, mapInfo.y, uid, mapInfo.uidList, check)) {
		uidContent = check.uidContent;
		type = check.type;
		name = check.name;
		tiny.log.trace('buyMapThings', key, type, name, JSON.stringify(uidContent));
		if (parseInt(type, 10) === ConstMap.MAP_UID_TYPE.SHOP &&
			Shop.hasOwnProperty(name) &&
			parseInt(uidContent.state, 10) === MapElement.SHOP.TOUCHED &&
			uidContent.args.shopInfo.hasOwnProperty(key)) {
			// 购买
			price = Sellgroup[key].Price;
			num = Sellgroup[key].Num;
			cost = price * num;
			item = Sellgroup[key].ItemID;
			tiny.log.trace('buyMapThings', key, price, num, cost, item, baseInfo.gold);
			if (baseInfo.gold >= cost) {
				if (bag.addItem(item, num, bagList)) {
					baseInfo.gold = baseInfo.gold - cost;
					delete uidContent.args.shopInfo[key];
					mapInfo.uidList[uid] = uidContent;

					tiny.log.trace('buyMapThings', baseInfo.gold, JSON.stringify(uidContent));
					return ErrCode.SUCCESS;
				}
				return ErrCode.MAP_BUY_NO_MONEY;
			}
			return ErrCode.MAP_BUY_NO_BAG_ROOM;
		}
	}
	return ErrCode.MAP_BUY_ERROR;
};

exports.getAfkState = function(afkObj, mapInfo) {
	var uid = afkObj.curAfker.uid;
	if (mapInfo.uidList.hasOwnProperty(uid)) {
		return mapInfo.uidList[uid].state;
	}
	return undefined;
};
