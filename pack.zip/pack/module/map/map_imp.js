var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var ConstMap = Const.MAP;
var tiny = require('../../tiny');
var mapHandle = require('../dataprocess/map_handle');
var playerHandle = require('../dataprocess/player_handle');
var equipHandle = require('../dataprocess/equip_handle');
var afkHandle = require('../dataprocess/afk_handle');
var async = require('async');
var utils = require('../utils');
// 配置表
var MapInfo = require('../config/mapinfo');
var GuaJi = require('../config/guaji');

var mapfunc = require('./map');

var enterMap = function(inArgs, onResponse, current) {
	// 根据地图id返回此地图的信息
	var outArgs = {}, mapid = inArgs.mapid;

	outArgs.mapid = 0;
	outArgs.x = 0;
	outArgs.y = 0;
	outArgs.uidlist = {};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err + '|' + current.sessionId);
				} else {
					callback(null, session);
				}
			});
		},
		// 检查目标地图是否存在
		function(session, callback) {
			if (MapInfo.hasOwnProperty(mapid)) {
				callback(null, session);
			} else {
				callback(ErrCode.TARGET_MAP_NOT_EXIST, mapid);
			}
		},
		// 获取baseinfo
		function(session, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, info) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					callback(null, session, info);
				}
			});
		},
		// 检查是否满足进入条件1
		function(session, baseInfo, callback) {
			if (parseInt(MapInfo[mapid].UnlockCondition1, 10) !== 0) {
				// 检查所需地图是否已经解锁
				mapHandle.checkMapInfoExist(session.area, session.uuid, MapInfo[mapid].UnlockCondition1, function(err, ret) {
					if (err) {
						callback(ErrCode.CHECK_MAPINFO_ERROR, err + "|" + MapInfo[mapid].UnlockCondition1);
					} else {
						if (ret === 0) {
							callback(ErrCode.BEFORE_MAP_NOT_UNLOCK, MapInfo[mapid].UnlockCondition1);
						} else {
							callback(null, session, baseInfo);
						}
					}
				});
			} else {
				callback(null, session, baseInfo);
			}
		},
		// 检查是否满足进入条件2
		function(session, baseInfo, callback) {
			if (parseInt(MapInfo[mapid].UnlockCondition2, 10) !== 0) {
				// 检查团队等级是否达到指定级别
				if (baseInfo.level < MapInfo[mapid].UnlockCondition2) {
					callback(ErrCode.TEAM_LEVEL_LOW, 'team level low:' + baseInfo.level + "|" + MapInfo[mapid].UnlockCondition2);
				} else {
					callback(null, session);
				}
			} else {
				callback(null, session);
			}
		},
		// 检查是否满足进入条件3
		function(session, callback) {
			if (parseInt(MapInfo[mapid].UnlockCondition3, 10) !== 0) {
				// 检查探索度是否达到
				callback(null, session);
			} else {
				callback(null, session);
			}
		},
		// 获取所求进入的地图信息
		function(session, callback) {
			if (mapfunc.checkMapid(mapid)) {
				mapHandle.getMapInfo(session.area, session.uuid, mapid, function(err, mapInfo) {
					if (err) {
						callback(ErrCode.GET_MAPINFO_FAILURE, err + '|' + mapid);
					} else {
						if (!mapInfo) {
							// 创建新的地图信息
							mapfunc.createNewMap(session, mapid, function(err, mapInfo) {
								if (err) {
									callback(err, mapid);
								} else {
									callback(null, session, mapInfo);
								}
							});
						} else {
							callback(null, session, mapInfo);
						}
					}
				});
			} else {
				callback(ErrCode.MAPID_ERROR, "mapid error:" + mapid);
			}
		},
		// 切换当前地图到新地图
		function(session, mapInfo, callback) {
			mapHandle.changeMap(session.area, session.uuid, mapid, function(err) {
				if (err) {
					callback(ErrCode.CHANGE_MAP_FAILURE, err);
				} else {
					callback(null, mapInfo);
				}
			});
		},
		// 处理进入地图的事件和状态
		function(mapInfo, callback) {
			tiny.log.info("ErrCode.SUCCESS123 = ", mapid, JSON.stringify(mapInfo));
			outArgs.mapid = mapid;
			outArgs.x = mapInfo.x;
			outArgs.y = mapInfo.y;
			outArgs.uidlist = mapInfo.uidList;
			outArgs.sign = mapInfo.sign;
			callback(null);
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error('enterMap', err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			tiny.log.info("ErrCode.SUCCESS = ", ErrCode.SUCCESS, JSON.stringify(outArgs));
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var walkPath = function(inArgs, onResponse, current) {
	tiny.log.info('walkffffffffffff', utils.getValueType(inArgs.path), inArgs.path);

	var outArgs = {},
		mapid = inArgs.mapid,
		uid = inArgs.uid,
		path = JSON.parse(inArgs.path),
		cost = 0;

	tiny.log.info('walkffffffffffff', utils.getValueType(path), JSON.stringify(path));

	outArgs.mapid = 0;
	outArgs.x = 0;
	outArgs.y = 0;
	outArgs.cost = 0;
	outArgs.buff = [];

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err + '|' + current.sessionId);
				} else {
					callback(null, session);
				}
			});
		},
		// 检查path是否是数组
		function(session, callback) {
			if (utils.isArray(path) && path.length > 0) {
				callback(null, session);
			} else {
				callback(ErrCode.WALK_PATH_ERROR, path);
			}
		},
		// 检查地图是否是当前地图
		function(session, callback) {
			mapHandle.getCurMapID(session.area, session.uuid, function(err, curID) {
				if (err) {
					callback(ErrCode.GET_CUR_MAPID_FAILURE, err);
				} else {
					if (parseInt(curID, 10) === parseInt(mapid, 10)) {
						callback(null, session);
					} else {
						callback(ErrCode.CURRENT_MAP_WRONG, 'player current not in this map:' + mapid + '|' + curID);
					}
				}
			});
		},
		// 获取当前地图
		function(session, callback) {
			mapHandle.getMapInfo(session.area, session.uuid, mapid, function(err, data) {
				if (err) {
					callback(ErrCode.GET_MAPINFO_FAILURE, err);
				} else {
					if (data) {
						tiny.log.info('walk33333333333333', data, JSON.stringify(data));
						callback(null, session, data);
					} else {
						callback(ErrCode.WALK_NO_THIS_MAP, mapid);
					}
				}
			});
		},
		// 计算行走消耗行动力并进行行走验证
		function(session, mapInfo, callback) {
			var mapFileName,
				mapFileInfo,
				walkPerCost = 0,
				costObj;

			// 取对应地图的障碍数据层
			if (MapInfo.hasOwnProperty(mapid)) {
				if (MapInfo[mapid].hasOwnProperty("InfoFile")) {
					mapFileName = MapInfo[mapid].InfoFile;
				}
				if (MapInfo[mapid].hasOwnProperty("APCost")) {
					walkPerCost = MapInfo[mapid].APCost;
				}
			}
			mapFileInfo = mapfunc.getMapJson(mapFileName);
			// 计算消耗
			if (mapFileInfo.obsMap && walkPerCost > 0) {
				// 验证玩家是否在建筑内，验证起点坐标是否紧贴建筑
				if (uid >= 0) {
					if (mapFileInfo && mapFileInfo.hasOwnProperty("element")) {
						if (mapFileInfo.element.hasOwnProperty(uid)) {
							if (mapfunc.checkPathUID(mapFileInfo.element[uid], mapInfo.x, mapInfo.y, path[0])) {
								costObj = mapfunc.calcPathCost(walkPerCost, mapInfo, mapFileInfo, path, uid);
								callback(null, session, mapInfo, costObj);
								return;
							}
						}
						tiny.log.trace("walkPath", 'mapFileInfo.element not found uid', uid);
					}
					callback(ErrCode.MAP_UID_ERROR, uid);
					return;
				}
				costObj = mapfunc.calcPathCost(walkPerCost, mapInfo, mapFileInfo, path, uid);
				callback(null, session, mapInfo, costObj);
				return;
			}
			callback(ErrCode.GET_OBS_LAYER_ERROR);
		},
		// 获取buff并叠加buff消耗
		function(session, mapInfo, costObj, callback) {
			tiny.log.trace('walkPath costObj = ', JSON.stringify(costObj));
			mapHandle.getMapBuff(session.area, session.uuid, function(err, bufflist) {
				if (err) {
					callback(ErrCode.GET_MAP_BUFF_FAILURE, err);
				} else {
					// 计算新消耗并更新buff
					tiny.log.trace("walkPath", "getMapBuff 1", costObj);
					cost = mapfunc.calcBuffAction(costObj, bufflist);
					tiny.log.trace("walkPath", "getMapBuff 2", cost);
					callback(null, session, mapInfo, bufflist);
				}
			});
		},
		// 减少玩家行动力
		function(session, mapInfo, bufflist, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, info) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					if (info.action < cost) {
						callback(ErrCode.ACTION_POINT_LESS, 'action not enough');
						return;
					}
					tiny.log.trace("walkPath", "getBaseInfo 3", info.action);
					info.action = info.action - cost;
					tiny.log.trace("walkPath", "getBaseInfo 4", info.action);
					callback(null, session, mapInfo, bufflist, info);
				}
			});
		},
		// 保存地图信息
		function(session, mapInfo, bufflist, baseInfo, callback) {
			mapHandle.setMapInfo(session.area, session.uuid, mapid, mapInfo, function(err) {
				if (err) {
					callback(err, mapid + "|" + mapInfo);
				} else {
					outArgs.x = mapInfo.x;
					outArgs.y = mapInfo.y;
					callback(null, session, bufflist, baseInfo);
				}
			});
		},
		// 保存buff
		function(session, bufflist, baseInfo, callback) {
			mapHandle.setMapBuff(session.area, session.uuid, bufflist, function(err) {
				if (err) {
					callback(err, mapid + "|" + bufflist);
				} else {
					outArgs.buff = bufflist;
					callback(null, session, baseInfo);
				}
			});
		},
		// 保存baseinfo
		function(session, baseInfo, callback) {
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BASEINFO_ERROR, err);
				} else {
					outArgs.mapid = mapid;
					outArgs.cost = baseInfo.action;
					callback(null);
				}
			});
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error('walkPath', err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var changeState = function(inArgs, onResponse, current) {
	var outArgs = {},
		mapid = inArgs.mapid,
		uid = inArgs.uid,
		nextstate = parseInt(inArgs.nextstate, 10),
		in_args = JSON.parse(inArgs.args), out = {},
		curAfkMapid = 0;

	outArgs.mapid = 0;
	outArgs.uid = 0;
	outArgs.state = 0;
	outArgs.args = {};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err + '|' + current.sessionId);
				} else {
					callback(null, session);
				}
			});
		},
		// 检查地图是否是当前地图
		function(session, callback) {
			mapHandle.getCurMapID(session.area, session.uuid, function(err, curID) {
				if (err) {
					callback(ErrCode.GET_CUR_MAPID_FAILURE, err);
				} else {
					if (parseInt(curID, 10) === parseInt(mapid, 10)) {
						callback(null, session);
					} else {
						callback(ErrCode.CURRENT_MAP_WRONG, 'player current not in this map:' + mapid + '|' + curID);
					}
				}
			});
		},
		// 获取当前地图
		function(session, callback) {
			mapHandle.getMapInfo(session.area, session.uuid, mapid, function(err, data) {
				if (err) {
					callback(ErrCode.GET_MAPINFO_FAILURE, err);
				} else {
					if (data) {
						// tiny.log.info('walk33333333333333', data, JSON.stringify(data));
						callback(null, session, data);
					} else {
						callback(ErrCode.MAPID_ERROR, mapid);
					}
				}
			});
		},
		// 获取baseinfo
		function(session, mapInfo, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					callback(null, session, mapInfo, baseInfo);
				}
			});
		},
		// 获取背包数据
		function(session, mapInfo, baseInfo, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err);
				} else {
					callback(null, session, mapInfo, baseInfo, bagList);
				}
			});
		},
		// 获取战斗信息
		function(session, mapInfo, baseInfo, bagList, callback) {
			playerHandle.getPlayerInfo(session.area, session.uuid, function(err, playerInfo) {
				if (err) {
					callback(ErrCode.NEVER_CREATE_PLAYER, err);
				} else {
					if (playerInfo !== undefined) {
						callback(null, session, mapInfo, baseInfo, bagList, playerInfo);
					} else {
						callback(ErrCode.NEVER_CREATE_PLAYER, err);
					}
				}
			});
		},
		// 获取buff并叠加buff消耗
		function(session, mapInfo, baseInfo, bagList, playerInfo, callback) {
			mapHandle.getMapBuff(session.area, session.uuid, function(err, bufflist) {
				if (err) {
					callback(ErrCode.GET_MAP_BUFF_FAILURE, err);
				} else {
					callback(null, session, mapInfo, baseInfo, bagList, playerInfo, bufflist);
				}
			});
		},
		// 获取ap值
		function(session, mapInfo, baseInfo, bagList, fightInfo, bufflist, callback) {
			mapHandle.getMapAP(session.area, session.uuid, function(err, ap) {
				if (err) {
					callback(ErrCode.MAP_GET_AP_ERROR, err);
				} else {
					tiny.log.trace("!!!!!!!!!!!!!!!!!ap = ", ap, JSON.stringify(ap));
					callback(null, session, mapInfo, baseInfo, bagList, fightInfo, bufflist, ap);
				}
			});
		},
		// 获取挂机信息
		function(session, mapInfo, baseInfo, bagList, fightInfo, bufflist, ap, callback) {
			afkHandle.getAfkInfo(session.area, session.uuid, function(err, afkObj) {
				if (err) {
					callback(ErrCode.GET_AFK_LIST_ERROR);
				} else {
					tiny.log.trace("!!!!!!!!!!afkObj = ", JSON.stringify(afkObj));
					if (afkObj && afkObj.curAfker && GuaJi.hasOwnProperty(afkObj.curAfker.guajiid)) {
						curAfkMapid = afkObj.curAfker.mapid;
						mapHandle.getMapInfo(session.area, session.uuid, curAfkMapid, function(err, data) {
							if (err) {
								callback(ErrCode.GET_MAPINFO_FAILURE, err);
							} else {
								callback(null, session, mapInfo, data, baseInfo, bagList, fightInfo, bufflist, ap, afkObj);
							}
						});
						return;
					}
					callback(null, session, mapInfo, undefined, baseInfo, bagList, fightInfo, bufflist, ap, afkObj);
				}
			});
		},
		// 获取uid的数据并处理uid逻辑
		function(session, mapInfo, curAfkMapInfo, baseInfo, bagList, fightInfo, bufflist, ap, afkObj, callback) {
			mapfunc.processUid(mapid, mapInfo, curAfkMapInfo, baseInfo, bagList, fightInfo, bufflist, uid, nextstate, in_args, out, ap, afkObj);
			if (out.state > 0) {
				callback(null, session, mapInfo, curAfkMapInfo, baseInfo, bagList, bufflist, afkObj);
			} else {
				callback(out.errCode);
			}
		},
		// 保存挂机信息
		function(session, mapInfo, curAfkMapInfo, baseInfo, bagList, bufflist, afkObj, callback) {
			afkHandle.setAfkInfo(session.area, session.uuid, afkObj, function(err) {
				if (err) {
					callback(ErrCode.SAVE_AFK_ERROR, err);
				} else {
					callback(null, session, mapInfo, curAfkMapInfo, baseInfo, bagList, bufflist);
				}
			});
		},
		// 保存上一挂机地图状态
		function(session, mapInfo, curAfkMapInfo, baseInfo, bagList, bufflist, callback) {
			if (curAfkMapInfo && curAfkMapid !== 0) {
				mapHandle.setMapInfo(session.area, session.uuid, curAfkMapid, curAfkMapInfo, function(err) {
					if (err) {
						callback(ErrCode.SAVE_MAP_INFO_ERROR, err + "|" + curAfkMapid + "|" + curAfkMapInfo);
					} else {
						callback(null, session, mapInfo, baseInfo, bagList, bufflist);
					}
				});
				return;
			}
			callback(null, session, mapInfo, baseInfo, bagList, bufflist);
		},
		// 保存ap
		function(session, mapInfo, baseInfo, bagList, bufflist, callback) {
			if (out.args.ap) {
				mapHandle.setMapAP(session.area, session.uuid, out.args.ap, function(err) {
					if (err) {
						callback(ErrCode.SAVE_MAP_AP_ERROR, err + "|" + mapid + "|" + out.args.ap);
					} else {
						callback(null, session, mapInfo, baseInfo, bagList, bufflist);
					}
				});
			} else {
				callback(ErrCode.CALC_AP_ERROR);
			}
		},
		// 保存buff
		function(session, mapInfo, baseInfo, bagList, bufflist, callback) {
			mapHandle.setMapBuff(session.area, session.uuid, bufflist, function(err) {
				if (err) {
					callback(ErrCode.SAVE_MAP_BUFF_ERROR, err + "|" + mapid + "|" + bufflist);
				} else {
					callback(null, session, mapInfo, baseInfo, bagList);
				}
			});
		},
		// 保存baseinfo
		function(session, mapInfo, baseInfo, bagList, callback) {
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BASEINFO_ERROR, err);
				} else {
					callback(null, session, mapInfo, bagList);
				}
			});
		},
		// 保存背包
		function(session, mapInfo, bagList, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err);
				} else {
					callback(null, session, mapInfo);
				}
			});
		},
		// 保存地图信息
		function(session, mapInfo, callback) {
			mapHandle.setMapInfo(session.area, session.uuid, mapid, mapInfo, function(err) {
				tiny.log.trace("$$$$$$$$$$$$$$$$$$$$$$$", JSON.stringify(mapInfo));
				if (err) {
					callback(ErrCode.SAVE_MAP_INFO_ERROR, err + "|" + mapid + "|" + mapInfo);
				} else {
					outArgs.mapid = mapid;
					outArgs.uid = uid;
					outArgs.state = out.state;
					outArgs.args = out.args;
					callback(null);
				}
			});
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error('changeState', err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var mapBuy = function(inArgs, onResponse, current) {
	var outArgs = {},
		mapid = inArgs.mapid,
		uid = inArgs.uid,
		key = inArgs.key;

	outArgs.mapid = 0;
	outArgs.uid = 0;
	outArgs.key = 0;

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err + '|' + current.sessionId);
				} else {
					callback(null, session);
				}
			});
		},
		// 检查地图是否是当前地图
		function(session, callback) {
			mapHandle.getCurMapID(session.area, session.uuid, function(err, curID) {
				if (err) {
					callback(ErrCode.GET_CUR_MAPID_FAILURE, err);
				} else {
					if (parseInt(curID, 10) === parseInt(mapid, 10)) {
						callback(null, session);
					} else {
						callback(ErrCode.CURRENT_MAP_WRONG, 'player current not in this map:' + mapid + '|' + curID);
					}
				}
			});
		},
		// 获取当前地图
		function(session, callback) {
			mapHandle.getMapInfo(session.area, session.uuid, mapid, function(err, data) {
				if (err) {
					callback(ErrCode.GET_MAPINFO_FAILURE, err);
				} else {
					if (data) {
						// tiny.log.info('walk33333333333333', data, JSON.stringify(data));
						callback(null, session, data);
					} else {
						callback(ErrCode.MAPID_ERROR, mapid);
					}
				}
			});
		},
		// 获取baseinfo
		function(session, mapInfo, callback) {
			playerHandle.getBaseInfo(session.area, session.uuid, function(err, baseInfo) {
				if (err) {
					callback(ErrCode.GET_BASEINFO_ERROR, err);
				} else {
					callback(null, session, mapInfo, baseInfo);
				}
			});
		},
		// 获取背包数据
		function(session, mapInfo, baseInfo, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err);
				} else {
					callback(null, session, mapInfo, baseInfo, bagList);
				}
			});
		},
		// 处理购买逻辑
		function(session, mapInfo, baseInfo, bagList, callback) {
			var ret = mapfunc.buyMapThings(mapid, key, uid, mapInfo, baseInfo, bagList);
			if (ret === 0) {
				callback(null, session, mapInfo, baseInfo, bagList);
			} else {
				callback(ret);
			}
		},
		// 保存baseinfo
		function(session, mapInfo, baseInfo, bagList, callback) {
			playerHandle.setBaseInfo(session.area, session.uuid, baseInfo, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BASEINFO_ERROR, err);
				} else {
					callback(null, session, mapInfo, bagList);
				}
			});
		},
		// 保存背包
		function(session, mapInfo, bagList, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err);
				} else {
					callback(null, session, mapInfo);
				}
			});
		},
		// 保存地图信息
		function(session, mapInfo, callback) {
			mapHandle.setMapInfo(session.area, session.uuid, mapid, mapInfo, function(err) {
				if (err) {
					callback(err, mapid + "|" + mapInfo);
				} else {
					outArgs.mapid = mapid;
					outArgs.uid = uid;
					outArgs.key = key;
					callback(null);
				}
			});
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error('mapBuy', err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var getMapInfo = function(inArgs, onResponse, current) {
	var outArgs = {};

	outArgs.mapinfo = {};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err + '|' + current.sessionId);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取buff
		function(session, callback) {
			tiny.log.trace('getMapInfo session = ', JSON.stringify(session));
			mapHandle.getMapBuff(session.area, session.uuid, function(err, bufflist) {
				if (err) {
					callback(ErrCode.GET_MAP_BUFF_FAILURE, err);
				} else {
					callback(null, session, bufflist);
				}
			});
		},
		// 获取ap值
		function(session, bufflist, callback) {
			mapHandle.getMapAP(session.area, session.uuid, function(err, ap) {
				if (err) {
					callback(ErrCode.MAP_GET_AP_ERROR, err);
				} else {
					callback(null, session, bufflist, ap);
				}
			});
		},
		// 获取当前挂机点
		function(session, bufflist, ap, callback) {
			afkHandle.getAfkInfo(session.area, session.uuid, function(err, afkObj) {
				if (err) {
					callback(ErrCode.GET_CUR_AFK_ERROR, err);
				} else {
					callback(null, bufflist, ap, afkObj);
				}
			});
		},
		function(bufflist, ap, afkObj, callback) {
			outArgs.mapinfo.bufflist = bufflist;
			outArgs.mapinfo.ap = ap;
			outArgs.mapinfo.afkObj = afkObj.curAfker;
			callback(null, null);
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error('getMapInfo', err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

var getMapBaseInfo = function(inArgs, onResponse, current) {
	var outArgs = {};

	outArgs.curMapId = 0;
	outArgs.supply = 0;
	outArgs.buffList = [];
	outArgs.curAfker = {
		"mapid" : 0,
		"uid" : 0,
		"guajiid" : 0
	};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err + '|' + current.sessionId);
				} else {
					callback(null, session);
				}
			});
		},
		// 获取当前地图
		function(session, callback) {
			tiny.log.trace('getMapBaseInfo session 1');
			mapHandle.getCurMapID(session.area, session.uuid, function(err, curID) {
				if (err) {
					callback(ErrCode.GET_CUR_MAPID_FAILURE, err);
				} else {
					callback(null, session, parseInt(curID, 10));
				}
			});
		},
		// 获取bufflist
		function(session, curMapId, callback) {
			tiny.log.trace('getMapBaseInfo session 2');
			mapHandle.getMapBuff(session.area, session.uuid, function(err, bufflist) {
				if (err) {
					callback(ErrCode.GET_MAP_BUFF_FAILURE, err);
				} else {
					callback(null, session, curMapId, bufflist);
				}
			});
		},
		// 获取ap值
		function(session, curMapId, bufflist, callback) {
			mapHandle.getMapAP(session.area, session.uuid, function(err, ap) {
				if (err) {
					callback(ErrCode.MAP_GET_AP_ERROR, err);
				} else {
					callback(null, session, curMapId, bufflist, ap);
				}
			});
		},
		// 获取当前挂机点
		function(session, curMapId, bufflist, ap, callback) {
			afkHandle.getAfkInfo(session.area, session.uuid, function(err, afkObj) {
				if (err) {
					callback(ErrCode.GET_CUR_AFK_ERROR, err);
				} else {
					callback(null, curMapId, bufflist, ap, afkObj);
				}
			});
		},
		function(curMapId, bufflist, ap, afkObj, callback) {
			outArgs.curMapId = curMapId;
			outArgs.supply = ap;
			outArgs.buffList = bufflist;
			outArgs.curAfker = afkObj.curAfker;
			callback(null, null);
		}
	], function(err, errStr) {
		if (err) {
			tiny.log.error('getMapBaseInfo', err, errStr);
			onResponse(err, current, inArgs, outArgs);
		} else {
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

module.exports = {
"enterMap" : enterMap,
"walkPath" : walkPath,
"changeState" : changeState,
"mapBuy" : mapBuy,
"getMapInfo" : getMapInfo,
"getMapBaseInfo" : getMapBaseInfo
};
