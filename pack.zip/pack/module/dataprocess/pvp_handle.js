var util = require('util');
var EventEmitter = require('events').EventEmitter;
var nodeUUID = require('node-uuid');
var async = require('async');

var tiny = require('../../tiny');
var utils = require('../utils');
var Const = require('../const');
var Lru = require('../lru');
var PowerMatch = require('../config/powermatch');
var playerHandle = require('./player_handle');
var Robot = require('../robot/robot');
var lru = require('../lru');

/*
MyPvp = {
	ticketN;                         // sng门票
	ticketDay;                       // 积分
	ticketWeek;                      // 周赛门票
	fightCount;                      // 战斗次数
	startMark;                       // 开始战斗标志
	boxRewardCount;                  // 宝箱奖励进度
	fightInfoListSng;                // sng数据
	fightInfoListDay;                // 日赛数据
	fightInfoListWeek;               // 周赛数据
}
PvpSng = {
	id : 0,
	data1 : {
		keys : [],
		map : {},
	},
	data2 : {
		keys : [],
		map : {},
	},
	data3 : {
		keys : [],
		map : {},
	},
}
*/
var robotPvpInfoCache = {};

var getPowerId = function(power) {
	var id, p = parseInt(power, 10);
	for (id in PowerMatch) {
		if (PowerMatch.hasOwnProperty(id)) {
			if (PowerMatch[id].MyPower[1] <= p
				&& p <= PowerMatch[id].MyPower[2]) {
				return id;
			}
		}
	}
	tiny.log.error("PowerMatch don't match", p);
	return 1;
};

var checkJsonValue = function(_json, value) {
	var i;
	for (i in _json) {
		if (_json.hasOwnProperty(i)
			&& _json[i] === value) {
			return true;
		}
	}
	return false;
};

// 获取PvpSng
exports.getPvpSng = function(baseInfo, callback) {
	var id = getPowerId(baseInfo.power), i, ids = [], pvpSng = {}, tmp = {}, ids2 =[], ua = {area : baseInfo.area, uuid : baseInfo.uuid};
	for (i in PowerMatch[id].Power1) {
		if (PowerMatch[id].Power1.hasOwnProperty(i)) {
			ids.push(PowerMatch[id].Power1[i]);
		}
	}
	tiny.log.debug("power1", JSON.stringify(ids));
	for (i in PowerMatch[id].Power2) {
		if (PowerMatch[id].Power2.hasOwnProperty(i)) {
			ids.push(PowerMatch[id].Power2[i]);
		}
	}
	tiny.log.debug("power2", JSON.stringify(ids));
	for (i in PowerMatch[id].Power3) {
		if (PowerMatch[id].Power3.hasOwnProperty(i)) {
			ids.push(PowerMatch[id].Power3[i]);
		}
	}
	// 去重
	for (i = 0; i < ids.length; i++) {
		if (!tmp.hasOwnProperty(ids[i])){
			tmp[ids[i]] = ids[i];
			ids2.push(ids[i]);
		}
	}
	ids = ids2;
	tiny.log.debug("power3", JSON.stringify(ids));
	tiny.redis.hmget(utils.redisKeyGen("all", "power", "match"), ids, function(err, pvpSngList) {
		var pvpPower;
		if (err) {
			callback(err);
		} else {
			pvpSng.id = id;
			pvpSng.data1 = {
				id : PowerMatch[id].Power1[1],
				reward : PowerMatch[id].Reward1,
				uuids : [],
			};
			pvpSng.data2 = {
				id : PowerMatch[id].Power2[1],
				reward : PowerMatch[id].Reward2,
				uuids : [],
			};
			pvpSng.data3 = {
				id : PowerMatch[id].Power3[1],
				reward : PowerMatch[id].Reward3,
				uuids : [],
			};
			pvpSng.uuids1 = [];
			pvpSng.uuids2 = [];
			pvpSng.uuids3 = [];
			for (i = 0; i < pvpSngList.length; i++) {
				pvpPower = utils.getObject(pvpSngList[i]);
				if (pvpPower) {
					tiny.log.error("pvpPower", JSON.stringify(pvpPower));
					if (pvpPower.keys.length > 0) {
						if (checkJsonValue(PowerMatch[id].Power1, pvpPower.id)) {
							pvpSng.data1.uuids = pvpSng.data1.uuids.concat(pvpPower.keys);
						}
						if (checkJsonValue(PowerMatch[id].Power2, pvpPower.id)) {
							pvpSng.data2.uuids = pvpSng.data2.uuids.concat(pvpPower.keys);
						}
						if (checkJsonValue(PowerMatch[id].Power3, pvpPower.id)) {
							pvpSng.data3.uuids = pvpSng.data3.uuids.concat(pvpPower.keys);
						}
					}
				}
			}
			// 把自己的排除掉
			lru.aRemove(ua, pvpSng.data1.uuids);
			lru.aRemove(ua, pvpSng.data2.uuids);
			lru.aRemove(ua, pvpSng.data3.uuids);
			tiny.log.error("pvpSngb:", JSON.stringify(ua), JSON.stringify(pvpSng));
			// 1个1
			if (pvpSng.data1.uuids.length >= 1) {
				pvpSng.uuids1.push(utils.randomArray(pvpSng.data1.uuids));
			} else {
				// 机器人
				pvpSng.uuids1.push({area : baseInfo.area, uuid : 1, id : pvpSng.data1.id});
			}
			// 2个2
			if (pvpSng.data2.uuids.length >= 2) {
				pvpSng.uuids2 = utils.randomArrayN(pvpSng.data2.uuids, 2);
			} else {
				// 机器人
				pvpSng.uuids2.push({area : baseInfo.area, uuid : 2, id : pvpSng.data2.id});
				pvpSng.uuids2.push({area : baseInfo.area, uuid : 3, id : pvpSng.data2.id});
			}
			// 3个3
			if (pvpSng.data3.uuids.length >= 3) {
				pvpSng.uuids3 = utils.randomArrayN(pvpSng.data3.uuids, 3);
			} else {
				// 机器人
				pvpSng.uuids3.push({area : baseInfo.area, uuid : 4, id : pvpSng.data3.id});
				pvpSng.uuids3.push({area : baseInfo.area, uuid : 5, id : pvpSng.data3.id});
				pvpSng.uuids3.push({area : baseInfo.area, uuid : 6, id : pvpSng.data3.id});
			}
			tiny.log.error("pvpSnga:", JSON.stringify(ua), JSON.stringify(pvpSng));
			// 取玩家数据
			exports.getPlayerPvpSng(pvpSng, function(err, newPvpSng) {
				if (err) {
					callback(err);
				} else {
					callback(null, newPvpSng);
				}
			});
		}
	});
};

var newFighter = function(playerInfo, reward) {
	var t = {};
	t.enemy = playerInfo;
	t.result = 0;
	t.ticketDay = reward;
	return t;
};

var getPlayerInfoN = function(newPvpSng, pvpSng, seq, i, end, callback) {
	// 1个1
	// 2个2
	// 3个3
	if (i < end) {
		tiny.log.debug("getPlayerInfoN", seq, i, end);
		exports.getPvpPlayerInfo(pvpSng["uuids" + seq][i], function(err, playerInfo) {
			if (err) {
				callback(err);
			} else {
				newPvpSng["fighterList" + seq].push(newFighter(playerInfo, PowerMatch[pvpSng.id]["Reward" + seq]));
				i = i + 1;
				getPlayerInfoN(newPvpSng, pvpSng, seq, i, end, callback);
			}
		});
	} else {
		tiny.log.debug("getPlayerInfoN end");
		callback(null);
	}
};

exports.getPlayerPvpSng = function(pvpSng, callback) {
	// 1个1
	// 2个2
	// 3个3
	var newPvpSng = {};
	newPvpSng.id = pvpSng.id;
	newPvpSng.fighterList1 = [];
	newPvpSng.fighterList2 = [];
	newPvpSng.fighterList3 = [];
	getPlayerInfoN(newPvpSng, pvpSng, 1, 0, 1, function(err) {
		if (err) {
			callback(err);
		} else {
			getPlayerInfoN(newPvpSng, pvpSng, 2, 0, 2, function(err) {
				if (err) {
					callback(err);
				} else {
					getPlayerInfoN(newPvpSng, pvpSng, 3, 0, 3, function(err) {
						if (err) {
							callback(err);
						} else {
							callback(null, newPvpSng);
						}
					});
				}
			});
		}
	});
};

// 设置PvpSng
exports.setPvpSng = function(baseInfo, callback) {
	var id = getPowerId(baseInfo.power), dataMap;
	tiny.redis.hget(utils.redisKeyGen("all", "power", "match"), id, function(err, data) {
		if (err) {
			callback(err);
		} else {
			if (data) {
				dataMap = utils.getObject(data);
			} else {
				dataMap = Lru.lruCreate(id);
			}
			Lru.lruSet({area : baseInfo.area, uuid : baseInfo.uuid}, dataMap);
			tiny.redis.hset(utils.redisKeyGen("all", "power", "match"), id, utils.setObject(dataMap), function(err) {
				if (err) {
					callback(err);
				} else {
					if (callback) {
						callback(null, dataMap);
					}
				}
			});
		}
	});
};

// 移除pvpSng
exports.removePvpSng = function(baseInfo, callback) {
	var id = getPowerId(baseInfo.power), dataMap;
	tiny.redis.hget(utils.redisKeyGen("all", "power", "match"), id, function(err, data) {
		if (err) {
			callback(err);
		} else {
			if (data) {
				dataMap = data;
			} else {
				dataMap = Lru.lruCreate(id);
			}
			Lru.lruRemove({area : baseInfo.area, uuid : baseInfo.uuid}, dataMap);
			tiny.redis.hset(utils.redisKeyGen("all", "power", "match"), id, dataMap, function(err) {
				if (err) {
					callback(err);
				} else {
					if (callback) {
						callback(null, dataMap);
					}
				}
			});
		}
	});
};

// 获取pvpday
exports.getPvpDay = function(area, callback) {
	tiny.redis.get(utils.redisKeyGen(area, "pvp", "day"), function(err, pvpDay) {
		if (err) {
			callback(err);
		} else {
			callback(null, pvpDay);
		}
	});
};

// 获取pvpWeek
exports.getPvpWeek = function(callback) {
	tiny.redis.get(utils.redisKeyGen("all", "pvp", "week"), function(err, pvpWeek) {
		if (err) {
			callback(err);
		} else {
			callback(null, pvpWeek);
		}
	});
};

// 获取globalInfo
exports.getGlobalInfo = function(callback) {
	tiny.redis.get(utils.redisKeyGen("all", "pvp", "global"), function(err, globalInfo) {
		if (err) {
			callback(err);
		} else {
			callback(null, globalInfo);
		}
	});
};

// 获取PvpInfo
exports.getPvpInfo = function(area, uuid, callback) {
	var key = utils.userAreaKey2(area, uuid);
	if (Robot.checkIsRobot(uuid)) {
		if (robotPvpInfoCache.hasOwnProperty(key)) {
			callback(null, robotPvpInfoCache[key]);
		} else {
			callback(null, exports.createRobotPvpInfo());
		}
	} else {
		tiny.redis.get(utils.redisKeyGen(area, uuid, "pvp"), function(err, pvpInfo) {
			if (err) {
				callback(err);
			} else {
				callback(null, pvpInfo);
			}
		});
	}
};

// 设置pvpday
exports.setPvpDay = function(area, pvpDay, callback) {
	tiny.redis.set(utils.redisKeyGen(area, "pvp", "day"), pvpDay, function(err) {
		if (err) {
			callback(err);
		} else {
			callback(null, pvpDay);
		}
	});
};

// 设置pvpWeek
exports.setPvpWeek = function(pvpWeek, callback) {
	tiny.redis.set(utils.redisKeyGen("all", "pvp", "week"), pvpWeek, function(err) {
		if (err) {
			callback(err);
		} else {
			callback(null, pvpWeek);
		}
	});
};

// 设置PvpInfo
exports.setPvpInfo = function(area, uuid, pvpInfo, callback) {
	var key = utils.userAreaKey2(area, uuid);
	if (Robot.checkIsRobot(uuid)) {
		// 保存到缓存里面
		robotPvpInfoCache[key] = pvpInfo;
		callback(null, pvpInfo);
	} else {
		tiny.redis.set(utils.redisKeyGen(area, uuid, "pvp"),  pvpInfo, function(err) {
			if (err) {
				callback(err);
			} else {
				callback(null, pvpInfo);
			}
		});
	}
};

// 设置globalInfo
exports.setGlobalInfo = function(globalInfo, callback) {
	tiny.redis.set(utils.redisKeyGen("all", "pvp", "global"), globalInfo, function(err) {
		if (err) {
			callback(err);
		} else {
			callback(null, globalInfo);
		}
	});
};

// 设置pvpdayNx
exports.setPvpDayNx = function(area, pvpDay, callback) {
	tiny.redis.setnx(utils.redisKeyGen(area, "pvp", "day"), pvpDay, function(err) {
		if (err) {
			callback(err);
		} else {
			callback(null, pvpDay);
		}
	});
};

// 设置pvpWeekNx
exports.setPvpWeekNx = function(pvpWeek, callback) {
	tiny.redis.setnx(utils.redisKeyGen("all", "pvp", "week"), pvpWeek, function(err) {
		if (err) {
			callback(err);
		} else {
			callback(null, pvpWeek);
		}
	});
};

// 设置globalInfoNx
exports.setGlobalInfoNx = function(globalInfo, callback) {
	tiny.redis.setnx(utils.redisKeyGen("all", "pvp", "global"), globalInfo, function(err) {
		if (err) {
			callback(err);
		} else {
			callback(null, globalInfo);
		}
	});
};

// 添加取机器人步骤
exports.getPvpPlayerInfo = function(ua, callback) {
	var robot;
	if (Robot.checkIsRobot(ua.uuid)) {
		robot = Robot.getRobotPlayerInfo(ua);
		tiny.log.debug("get Robot", robot.area, robot.uuid);
		callback(null, robot);
	} else {
		playerHandle.getPlayerInfo(ua.area, ua.uuid, function(err, playerInfo) {
			if (err) {
				callback(err);
			} else {
				callback(null, playerInfo);
			}
		});
	}
};

exports.get1V1PlayerInfoS = function(ua1, ua2, callback) {
	exports.getPvpPlayerInfo(ua1, function(err, playerInfo1) {
		if (err) {
			callback(err);
		} else {
			exports.getPvpPlayerInfo(ua2, function(err, playerInfo2) {
				if (err) {
					callback(err);
				} else {
					callback(null, playerInfo1, playerInfo2);
				}
			});
		}
	});
};

exports.get1V1PlayerInfo = function(ua1, ua2, callback) {
	exports.getPvpPlayerInfo(ua1, function(err, playerInfo1) {
		if (err) {
			callback(err);
		} else {
			exports.getPvpInfo(ua1.area, ua1.uuid, function(err, pvpInfo1) {
				if (err) {
					callback(err);
				} else {
					exports.getPvpPlayerInfo(ua2, function(err, playerInfo2) {
						if (err) {
							callback(err);
						} else {
							exports.getPvpInfo(ua2.area, ua2.uuid, function(err, pvpInfo2) {
								if (err) {
									callback(err);
								} else {
									//tiny.log.debug("...", JSON.stringify(ua1), JSON.stringify(ua2), JSON.stringify(playerInfo1), JSON.stringify(playerInfo2));
									callback(null, playerInfo1, pvpInfo1, playerInfo2, pvpInfo2);
								}
							});
						}
					});
				}
			});
		}
	});
};

exports.set1V1PlayerInfo = function(ua1, ua2, pvpInfo1, pvpInfo2, callback) {
	exports.setPvpInfo(ua1.area, ua1.uuid, pvpInfo1, function(err) {
		if (err) {
			callback(err);
		} else {
			exports.setPvpInfo(ua2.area, ua2.uuid, pvpInfo2, function(err) {
				if (err) {
					callback(err);
				} else {
					callback(null);
				}
			});
		}
	});
};

// 创建机器人pvpInfo
exports.createRobotPvpInfo = function() {
	var pvpInfo = {};
	pvpInfo.ticketN = 4;
 	pvpInfo.ticketDay = 100;
	pvpInfo.ticketWeek = 0;
	pvpInfo.fightCount = 4;
	pvpInfo.startMark = Const.PVP_SNG_END;
	pvpInfo.box1 = 0;
	pvpInfo.box2 = 0;
	pvpInfo.box3 = 0;
	pvpInfo.myTime = utils.getDate();
	pvpInfo.dayMark = 0;
	pvpInfo.weekMark = 0;
	pvpInfo.fightInfoListSng = [];
	pvpInfo.fightInfoListDay = [];
	pvpInfo.fightInfoListWeek = [];
	return pvpInfo;
};

// 创建PvpInfo
exports.createPvpInfo = function(area, uuid, callback) {
	var pvpInfo = exports.createRobotPvpInfo();
	pvpInfo.ticketN = 4;
	exports.setPvpInfo(area, uuid, pvpInfo, callback);
};

// 创建PvpDay
exports.createPvpDay = function(area, callback) {
	var pvpDay = {};

	pvpDay.uuids = [];
	pvpDay.area = area;
	//pvpDay.rewardPool = 0;
	//pvpDay.nums = 0;
	//pvpDay.updateTime = utils.getDate();
 	pvpDay.pvpF8Result = {
 		playerInfoList : [],
 		fightList8 : [],
 		fightList4 : [],
 		fightList2 : [],
 		fightList1 : [],
 	};
	pvpDay.finalSort = [];
	exports.setPvpDayNx(area, pvpDay, callback);
};

// 创建PvpWeek
exports.createPvpWeek = function(callback) {
	var pvpWeek = {};

	pvpWeek.userArea = [];
	//pvpWeek.rewardPool = 0;
	//pvpWeek.nums = 0;
 	pvpWeek.pvpF8Result = {
 		playerInfoList : [],
 		fightList8 : [],
 		fightList4 : [],
 		fightList2 : [],
 		fightList1 : [],
 	};
	pvpWeek.finalSort = [];
	exports.setPvpWeekNx(pvpWeek, callback);
};

// 创建GlobalInfo
exports.createGlobalInfo = function(areas, callback) {
	var globalInfo = {}, i;

	globalInfo.pvpDay = {};
	for (i = 0; i < areas.length; i++) {
		globalInfo.pvpDay[areas[i]] = {
			rewardPool : 0,
			nums : 0,
			area : areas[i],
			maxCount : 0,
			updateTime : utils.getDate(),
		};
	}
	globalInfo.pvpWeek = {};
	globalInfo.pvpWeek.rewardPool = 0;
	globalInfo.pvpWeek.nums = 0;
	globalInfo.pvpWeek.maxCount = 0;
	exports.setGlobalInfoNx(globalInfo, callback);
};
