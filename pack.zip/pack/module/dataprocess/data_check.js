var utils = require('../utils');
var tiny = require('../../tiny');

var convertDataConfig = function(_data) {
	var i, dataConfig = {};
	for (i in _data) {
		if (_data.hasOwnProperty(i)) {
			dataConfig[_data[i].funcName] = _data[i];
		}
	}
	return dataConfig;
};

var DataConfig = convertDataConfig(require('../config/DataConfig'));
var DataKey = function(_area, _uuid) {
	this.area = _area;
	this.uuid = _uuid;
};

var bindReadFunc = function(funcName) {
	var func = this;
	return DataConfig[funcName]["is" +func] && DataConfig[funcName]["is" +func][1];
};

var bindWriteFunc = function(funcName) {
	var func = this;
	return DataConfig[funcName]["is" +func] && DataConfig[funcName]["is" +func][2];
};

var convertDataCheck = function() {
	var i, j, func;
	for (i in DataConfig) {
		if (DataConfig.hasOwnProperty(i)) {
			for (j in DataConfig[i]) {
				if (DataConfig[i].hasOwnProperty(j)) {
					if (j !== "isSession") {
						func = j.substring(2);
						console.log("func", i, j, func);
						// 生成函数
						DataKey.prototype["r" + func] = bindReadFunc.bind(func);
						DataKey.prototype["w" + func] = bindWriteFunc.bind(func);
					}
				}
			}
			break;
		}
	}
};
/*
// 读判断接口
DataKey.prototype.rBaseInfo = function(funcName) {
	return DataConfig[funcName].isBaseInfo && DataConfig[funcName].isBaseInfo[1];
};

DataKey.prototype.rHeroInfo = function(funcName) {
	return DataConfig[funcName].isHeroInfo && DataConfig[funcName].isHeroInfo[1];
};

DataKey.prototype.rBagList = function(funcName) {
	return DataConfig[funcName].isBagList && DataConfig[funcName].isBagList[1];
};

DataKey.prototype.rAfkInfo = function(funcName) {
	return DataConfig[funcName].isAfkInfo && DataConfig[funcName].isAfkInfo[1];
};

DataKey.prototype.rMapInfo = function(funcName) {
	return DataConfig[funcName].isMapInfo && DataConfig[funcName].isMapInfo[1];
};

DataKey.prototype.rTeamHeroList = function(funcName) {
	return DataConfig[funcName].isTeamHeroList && DataConfig[funcName].isTeamHeroList[1];
};

DataKey.prototype.rEquipList = function(funcName) {
	return DataConfig[funcName].isEquipList && DataConfig[funcName].isEquipList[1];
};

DataKey.prototype.rPvpInfo = function(funcName) {
	return DataConfig[funcName].isPvpInfo && DataConfig[funcName].isPvpInfo[1];
};

DataKey.prototype.rPvpSng = function(funcName) {
	return DataConfig[funcName].isPvpSng && DataConfig[funcName].isPvpSng[1];
};

DataKey.prototype.rPvpDay = function(funcName) {
	return DataConfig[funcName].isPvpDay && DataConfig[funcName].isPvpDay[1];
};

DataKey.prototype.rPvpWeek = function(funcName) {
	return DataConfig[funcName].isPvpWeek && DataConfig[funcName].isPvpWeek[1];
};

DataKey.prototype.rGlobalInfo = function(funcName) {
	return DataConfig[funcName].isGlobalInfo && DataConfig[funcName].isGlobalInfo[1];
};


// 写判断接口
DataKey.prototype.wBaseInfo = function(funcName) {
	return DataConfig[funcName].isBaseInfo && DataConfig[funcName].isBaseInfo[2];
};

DataKey.prototype.wHeroInfo = function(funcName) {
	return DataConfig[funcName].isHeroInfo && DataConfig[funcName].isHeroInfo[2];
};

DataKey.prototype.wBagList = function(funcName) {
	return DataConfig[funcName].isBagList && DataConfig[funcName].isBagList[2];
};

DataKey.prototype.wAfkInfo = function(funcName) {
	return DataConfig[funcName].isAfkInfo && DataConfig[funcName].isAfkInfo[2];
};

DataKey.prototype.wMapInfo = function(funcName) {
	return DataConfig[funcName].isMapInfo && DataConfig[funcName].isMapInfo[2];
};

DataKey.prototype.wTeamHeroList = function(funcName) {
	return DataConfig[funcName].isTeamHeroList && DataConfig[funcName].isTeamHeroList[2];
};

DataKey.prototype.wEquipList = function(funcName) {
	return DataConfig[funcName].isEquipList && DataConfig[funcName].isEquipList[2];
};

DataKey.prototype.wPvpInfo = function(funcName) {
	return DataConfig[funcName].isPvpInfo && DataConfig[funcName].isPvpInfo[2];
};

DataKey.prototype.wPvpSng = function(funcName) {
	return DataConfig[funcName].isPvpSng && DataConfig[funcName].isPvpSng[2];
};

DataKey.prototype.wPvpDay = function(funcName) {
	return DataConfig[funcName].isPvpDay && DataConfig[funcName].isPvpDay[2];
};

DataKey.prototype.wPvpWeek = function(funcName) {
	return DataConfig[funcName].isPvpWeek && DataConfig[funcName].isPvpWeek[2];
};

DataKey.prototype.wGlobalInfo = function(funcName) {
	return DataConfig[funcName].isGlobalInfo && DataConfig[funcName].isGlobalInfo[2];
};
*/
// 不同接口需要的key
DataKey.prototype.heroIds = function(_heroId) {
	this.vHeroIds = _heroId;
};

DataKey.prototype.heroId = function(_heroId) {
	this.iHeroId = _heroId;
};

DataKey.prototype.mapId = function(_mapId) {
	this.iMapId = _mapId;
};

// 检查是否有session
exports.isSession = function(funcName) {
	return DataConfig[funcName].isSession;
};

// 检查是否合法函数
exports.isFunction = function(func) {
	return DataConfig.hasOwnProperty(func);
};

// 设置前端获取到的key值
exports.getSingleKey = function(inArgs, dataKey, func) {
	var i, config = DataConfig[func];
	for (i in config) {
		if (config.hasOwnProperty(i)) {
			if (utils.isObject(config[i])) {
				if (config[i][3] && dataKey.hasOwnProperty(config[i][3])) {
					tiny.log.debug("getSingleKey", config[i][3]);
					dataKey[config[i][3]](inArgs[config[i][3]]);
				}
			}
		}
	}
	return dataKey;
};

exports.DataKey = DataKey;

convertDataCheck();
