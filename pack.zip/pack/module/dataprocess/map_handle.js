var async = require('async');
var nodeUUID = require('node-uuid');

var tiny = require('../../tiny');
var utils = require('../utils');
var Const = require('../const');

/*
// 地图信息
MapInfo
{
	curMapId: 101	// 当前地图id
	buffList: [{id = , value = }, {}]
	ap: 100
	[mapId]
	{
		mapid
		x
		y
		uidList: {
			[uid]: { state, args }
			[uid]: { state, args }
			例如商店
			[uid]: { state, args = { 2:1, 3:1, 7:1, shopInfo = {} } }
		}
		lastX
		lastY
		sign = { signid1 = num1, signid2 = num2 }
	}
}
*/

/*
buffList : {
	id:
	value:   / number
}
*/

// 创建默认地图列表
var defaultMapInfo = function() {
	var map = {
		"curMapId" : utils.setObject(0),
		"ap" : utils.setObject(100),
		"buffList" : utils.setObject([])
	};
	return map;
};

exports.createMapInfo = function(area, uuid, callback) {
	var map = defaultMapInfo();
	tiny.redis.hmset(utils.redisKeyGen(area, uuid, 'map'), map, callback);
};

exports.getMapInfo = function(area, uuid, mapid, callback) {
	tiny.redis.hget(utils.redisKeyGen(area, uuid, 'map'), mapid, function(err, data) {
		if (err) {
			callback(err);
		} else {
			if (data) {
				data = utils.getObject(data);
			}
			callback(null, data);
		}
	});
};

exports.setMapInfo = function(area, uuid, mapid, info, callback) {
	tiny.redis.hset(utils.redisKeyGen(area, uuid, 'map'), mapid, utils.setObject(info), callback);
};

exports.changeMap = function(area, uuid, mapid, callback) {
	tiny.redis.hset(utils.redisKeyGen(area, uuid, 'map'), 'curMapId', utils.setObject(mapid), callback);
};

exports.getCurMapID = function(area, uuid, callback) {
	tiny.redis.hget(utils.redisKeyGen(area, uuid, 'map'), 'curMapId', function(err, curID) {
		if (err) {
			callback(err);
		} else {
			if (curID) {
				curID = utils.getObject(curID);
			}
			callback(null, curID);
		}
	});
};

exports.getMapAP = function(area, uuid, callback) {
	tiny.redis.hget(utils.redisKeyGen(area, uuid, 'map'), 'ap', function(err, data) {
		if (err) {
			callback(err);
		} else {
			if (data) {
				data = utils.getObject(data);
			}
			callback(null, data);
		}
	});
};

exports.setMapAP = function(area, uuid, ap, callback) {
	tiny.redis.hset(utils.redisKeyGen(area, uuid, 'map'), "ap", utils.setObject(ap), callback);
};

exports.getMapBuff = function(area, uuid, callback) {
	tiny.redis.hget(utils.redisKeyGen(area, uuid, 'map'), 'buffList', function(err, data) {
		if (err) {
			callback(err);
		} else {
			if (data) {
				tiny.log.trace("getMapBuff", utils.getValueType(data));
				data = utils.getObject(data);
			}
			callback(null, data);
		}
	});
};

exports.setMapBuff = function(area, uuid, buffList, callback) {
	tiny.redis.hset(utils.redisKeyGen(area, uuid, 'map'), "buffList", utils.setObject(buffList), callback);
};

exports.checkMapInfoExist = function(area, uuid, mapid, cb) {
	tiny.redis.hexists(utils.redisKeyGen(area, uuid, 'map'), mapid, cb);
};
