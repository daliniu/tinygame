var playerHandle = require('./player_handle');
var equipHandle = require('./equip_handle');
var heroHandle = require('./hero_handle');
var afkHandle = require('./afk_handle');
var mapHandle = require('./map_handle');
var pvpHandle = require('./pvp_handle');
var util = require('util');
var async = require('async');

var tiny = require('../../tiny');
var utils = require('../utils');
var Const = require('../const');
var ErrCode = Const.CLIENT_ERROR_CODE;
var DataCheck = require('./data_check');
/*
dataKey
{
uuid : 1234,
area : 1,
bagList  : key,
baseInfo : key,
}

dataValue
{
bagList  : value,
baseInfo : value,
heroInfo : value,
}
getDataInfo(dataKey, callback)

*/

var getBaseInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rBaseInfo(funcName)) {
		tiny.log.debug("getBaseInfo");
		playerHandle.getBaseInfo(dataKey.area, dataKey.uuid, function(err, baseInfo) {
			if (err) {
				callback(ErrCode.DATA_GET_BASEINFO_ERROR);
			} else {
				dataValue.baseInfo = baseInfo;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getTeamHeroList = function(funcName, dataKey, dataValue, callback) {
	var heroIds;
	if (dataKey.rTeamHeroList(funcName) && dataValue.baseInfo) {
		// 转换上阵英雄列表
		heroIds = playerHandle.getHeroIdsFromPosList(dataValue.baseInfo.posList);
		// 取上阵英雄列表
		heroHandle.getTeamHeroList(dataKey.area, dataKey.uuid, heroIds, function(err, teamHeroList) {
			if (err) {
					callback(ErrCode.DATA_GET_TEAM_HERO_ERROR);
			} else {
				// 设置teamList数据position
				dataValue.teamHeroList = playerHandle.transPosListToTeamList(dataValue.baseInfo.posList, teamHeroList);
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getHeroInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rHeroInfo(funcName)) {
		tiny.log.debug("getHeroInfo", dataKey.rHeroInfo(funcName));
		heroHandle.getHeroInfo(dataKey.area, dataKey.uuid, dataKey.iHeroId, function(err, heroInfo) {
			if (err) {
				callback(ErrCode.DATA_GET_HEROINFO_ERROR);
			} else {
				dataValue.heroInfo = heroInfo;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getBagList = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rBagList(funcName)) {
		tiny.log.debug("getBagList");
		equipHandle.getBagList(dataKey.area, dataKey.uuid, function(err, bagList) {
			if (err) {
				callback(ErrCode.DATA_GET_BAGLIST_ERROR);
			} else {
				dataValue.bagList = bagList;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getAfkInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rAfkInfo(funcName)) {
		tiny.log.debug("getAfkInfo");
		afkHandle.getAfkInfo(dataKey.area, dataKey.uuid, function(err, afkInfo) {
			if (err) {
				callback(ErrCode.DATA_GET_AFKINFO_ERROR);
			} else {
				dataValue.afkInfo = afkInfo;
				dataKey.mapId(afkInfo.curAfker.mapid);
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getMapInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rMapInfo(funcName) && dataKey.iMapId) {
		tiny.log.debug("getMapInfo");
		mapHandle.getMapInfo(dataKey.area, dataKey.uuid, dataKey.iMapId, function(err, mapInfo) {
			if (err) {
				callback(ErrCode.DATA_GET_MAPINFO_ERROR);
			} else {
				dataValue.mapInfo = mapInfo;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getPvpInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rPvpInfo(funcName)) {
		tiny.log.debug("getPvpInfo");
		pvpHandle.getPvpInfo(dataKey.area, dataKey.uuid, function(err, pvpInfo) {
			if (err) {
				callback(ErrCode.DATA_GET_PVPINFO_ERROR);
			} else {
				dataValue.pvpInfo = pvpInfo;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getPvpSng = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rPvpSng(funcName) && dataValue.baseInfo) {
		tiny.log.debug("getPvpSng");
		pvpHandle.getPvpSng(dataValue.baseInfo, function(err, pvpSng) {
			if (err) {
				callback(ErrCode.DATA_GET_PVPSNG_ERROR);
			} else {
				dataValue.pvpSng = pvpSng;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getPvpDay = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rPvpDay(funcName)) {
		tiny.log.debug("getPvpDay");
		pvpHandle.getPvpDay(dataKey.area, function(err, pvpDay) {
			if (err) {
				callback(ErrCode.DATA_GET_PVPDAY_ERROR);
			} else {
				dataValue.pvpDay = pvpDay;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getPvpWeek = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rPvpWeek(funcName)) {
		tiny.log.debug("getPvpWeek");
		pvpHandle.getPvpWeek(function(err, pvpWeek) {
			if (err) {
				callback(ErrCode.DATA_GET_PVPWEEK_ERROR);
			} else {
				dataValue.pvpWeek = pvpWeek;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var getGlobalInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.rGlobalInfo(funcName)) {
		tiny.log.debug("getGlobalInfo");
		pvpHandle.getGlobalInfo(function(err, globalInfo) {
			if (err) {
				callback(ErrCode.DATA_GET_GLOBALINFO_ERROR);
			} else {
				dataValue.globalInfo = globalInfo;
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setBaseInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wBaseInfo(funcName)
		&& dataValue.baseInfo) {
		tiny.log.debug("setBaseInfo");
		playerHandle.setBaseInfo(dataKey.area, dataKey.uuid, dataValue.baseInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_BASEINFO_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setHeroInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wHeroInfo(funcName)
		&& dataValue.heroInfo) {
		tiny.log.debug("setHeroInfo");
		heroHandle.setHeroInfo(dataKey.area, dataKey.uuid, dataKey.iHeroId, dataValue.heroInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_HEROINFO_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setBagList = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wBagList(funcName)
		&& dataValue.bagList) {
		tiny.log.debug("setBagList");
		equipHandle.setBagList(dataKey.area, dataKey.uuid, dataValue.bagList, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_BAGLIST_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setAfkInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wAfkInfo(funcName)) {
		tiny.log.debug("setAfkInfo");
		afkHandle.setAfkInfo(dataKey.area, dataKey.uuid, dataValue.afkInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_AFKINFO_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setMapInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wMapInfo(funcName) && dataKey.iMapId) {
		tiny.log.debug("setMapInfo");
		mapHandle.setMapInfo(dataKey.area, dataKey.uuid, dataKey.iMapId, dataValue.mapInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_MAPINFO_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setPvpInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wPvpInfo(funcName) && dataValue.pvpInfo) {
		tiny.log.debug("setPvpInfo");
		pvpHandle.setPvpInfo(dataKey.area, dataKey.uuid, dataValue.pvpInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_PVPINFO_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setPvpSng = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wPvpSng(funcName) && dataValue.baseInfo) {
		tiny.log.debug("setPvpSng");
		pvpHandle.setPvpSng(dataValue.baseInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_PVPSNG_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setPvpDay = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wPvpDay(funcName)) {
		tiny.log.debug("setPvpDay");
		pvpHandle.setPvpDay(dataKey.area, dataValue.pvpDay, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_PVPDAY_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setPvpWeek = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wPvpWeek(funcName)) {
		tiny.log.debug("setPvpWeek");
		pvpHandle.setPvpWeek(dataValue.pvpWeek, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_PVPWEEK_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

var setGlobalInfo = function(funcName, dataKey, dataValue, callback) {
	if (dataKey.wGlobalInfo(funcName)) {
		tiny.log.debug("setGlobalInfo");
		pvpHandle.setGlobalInfo(dataValue.globalInfo, function(err) {
			if (err) {
				callback(ErrCode.DATA_SET_GLOBALINFO_ERROR);
			} else {
				callback(null);
			}
		});
	} else {
		callback(null);
	}
};

exports.getDataValue = function(funcName, dataKey, callback) {
	var dataValue = {};
	tiny.log.debug("getDataValue", JSON.stringify(dataKey));
	async.waterfall([
		function(cb) {
			getBaseInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getBagList(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getHeroInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getAfkInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getMapInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getTeamHeroList(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getPvpInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getPvpSng(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getPvpDay(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getPvpWeek(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			getGlobalInfo(funcName, dataKey, dataValue, cb);
		},
	], function(err) {
		if (err) {
			callback(err);
		} else {
			//tiny.log.debug("getDataValue", JSON.stringify(dataValue));
			callback(null, dataValue);
		}
	});
};

exports.setDataValue = function(funcName, dataKey, dataValue, callback) {
	async.waterfall([
		function(cb) {
			setBaseInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setBagList(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setHeroInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setAfkInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setMapInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setPvpInfo(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setPvpSng(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setPvpDay(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setPvpWeek(funcName, dataKey, dataValue, cb);
		},
		function(cb) {
			setGlobalInfo(funcName, dataKey, dataValue, cb);
		},
	], function(err) {
		if (err) {
			callback(err);
		} else {
			//tiny.log.debug("setDataValue", JSON.stringify(dataValue));
			callback(null, dataValue);
		}
	});
};

var bindFunCallback = function(inArgs, onResponse, current) {
	var outArgs, dataKey, obj = this;

	// 验证配置表是否正确
	if (!DataCheck.isFunction(obj.objFunc)) {
		tiny.log.error("DataConfig error",obj.objFunc);
		onResponse(ErrCode.DATA_CONFIG_ERROR, current, inArgs, {});
		return;
	}

	async.waterfall([
		// 获取session
		function(callback) {
			// 判断是否需要取session
			if (DataCheck.isSession(obj.objFunc)) {
				tiny.log.debug("getSession");
				tiny.redis.getSession(current.sessionId, function(err, session) {
					if (err) {
						callback(ErrCode.GET_SESSION_ERROR, err);
					} else {
						dataKey = new DataCheck.DataKey(session.area, session.uuid);
						inArgs.uuid = session.uuid;
						inArgs.area = session.area;
						dataKey = DataCheck.getSingleKey(inArgs, dataKey, obj.objFunc);
						callback(null);
					}
				});
			} else {
				dataKey = new DataCheck.DataKey();
				callback(null);
			}
		},
		// 取数据
		function(callback) {
			tiny.log.debug("get");
			exports.getDataValue(obj.objFunc, dataKey, function(errCode, dataValue) {
				if (errCode) {
					tiny.log.error(obj.objFunc, "getDataValue", errCode);
					callback(errCode);
				} else {
					callback(null, dataValue);
				}
			});
		},
		// 业务逻辑
		function(dataValue, callback) {
			tiny.log.debug("do");
			dataValue.area = inArgs.area;
			dataValue.uuid = inArgs.uuid;
			outArgs = obj.objImp[obj.objFunc](dataValue, inArgs, dataKey);
			if (!outArgs.retCode) {
				outArgs.retCode = ErrCode.SUCCESS;
			}
			if (outArgs.retCode === ErrCode.SUCCESS || outArgs.retCode > ErrCode.RETCODE_NEED_UNPACK) {
				//tiny.log.debug("logic", JSON.stringify(outArgs));
				callback(null, dataValue);
			} else {
				callback(outArgs.retCode);
			}
		},
		// 保存数据
		function(dataValue, callback) {
			tiny.log.debug("set");
			exports.setDataValue(obj.objFunc, dataKey, dataValue, function(errCode) {
				if (errCode) {
					tiny.log.error(obj.objFunc, "setDataValue", errCode);
					callback(errCode);
				} else {
					callback(null);
				}
			});
		},
	], function(errCode) {
		if (errCode) {
			tiny.log.error(obj.objFunc, dataKey.uuid, dataKey.area, errCode);
			if (outArgs.retCode) {
				outArgs = {};
			}
			outArgs.retCode = errCode;
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			if (!outArgs.retCode) {
				outArgs.retCode = ErrCode.SUCCESS;
			}
			onResponse(outArgs.retCode, current, inArgs, outArgs);
		}
	});
};

exports.bindImp = function(obj, imp) {
	var funcName;
	if (obj && imp) {
		for (funcName in imp) {
			if (imp.hasOwnProperty(funcName)) {
				obj[funcName] = bindFunCallback.bind({objImp : imp, objFunc : funcName});
			}
		}
	}
};

