var Const = require("../const");
var ErrCode = Const.CLIENT_ERROR_CODE;
var tiny = require('../../tiny');
var heroHandle = require('../dataprocess/hero_handle');
var playerHandle = require('../dataprocess/player_handle');
var equipHandle = require('../dataprocess/equip_handle');
var async = require('async');
var utils = require('../utils');
var eqStar = require("../config/eqStar");
var async = require('async');

// 换装备
var changeEquip = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, sign, seq, ids = {};

	// 获取输入参数
	sign = inArgs.sign;
	seq  = inArgs.seq;

	ids[1] = inArgs.id1;
	ids[2] = inArgs.id2;
	ids[3] = inArgs.id3;
	ids[4] = inArgs.id4;
	ids[5] = inArgs.id5;
	ids[6] = inArgs.id6;

	outArgs = {};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 换装备
		function(session, callback) {
			equipHandle.changeEquip(session.area, session.uuid, sign, seq, ids, function(err, equipList) {
				if (err || !equipList) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, equipList);
				}
			});
		}
	], function(errCode, errStr, session, equipList) {
		if (errCode) {
			tiny.log.error("changeEquip", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.equipList = equipList;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});

	//返回
	return ErrCode.SUCCESS;
};

// 装备升星
var upgradeEquipStar = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, ids = {}, equipId;

	// 获取输入参数
	equipId = inArgs.equipId;
	ids[1] = inArgs.id1;
	ids[2] = inArgs.id2;
	ids[3] = inArgs.id3;
	ids[4] = inArgs.id4;
	ids[5] = inArgs.id5;

	outArgs = {};

	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 装备升星
		function(session, callback) {
			equipHandle.upgradeEquipStar(session.area, session.uuid, equipId, ids, function(err, equip) {
				if (err || !equip) {
					callback(ErrCode.EQUIP_UPGRADE_STAR_ERROR, err, session);
				} else {
					callback(null, null, session, equip);
				}
			});
		}
	], function(errCode, errStr, session, equip) {
		if (errCode) {
			tiny.log.error("upgradeEquipStar", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.equip = equip;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 装备拆分
var splitEquip = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, equipIdList;

	// 获取输入参数
	equipIdList = JSON.parse(inArgs.equipIdList);

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 装备拆分
		function(session, callback) {
			equipHandle.splitEquip(session.area, session.uuid, equipIdList, function(err, splitList, gold) {
				if (err || !splitList) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, splitList, gold);
				}
			});
		}
	], function(errCode, errStr, session, splitList, gold) {
		if (errCode) {
			tiny.log.error("splitEquip", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.splitList = splitList;
			outArgs.gold = gold;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 装备淬炼
var meltingEquip = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, lequipId, requipId, attr;

	// 获取输入参数
	lequipId = inArgs.lequipId;
	requipId = inArgs.requipId;
	attr = inArgs.attr;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 装备淬炼
		function(session, callback) {
			equipHandle.meltingEquip(session.area, session.uuid, lequipId, requipId, attr, function(err, equip, splitList, gold) {
				if (err || !equip || !splitList) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, equip, splitList, gold);
				}
			});
		}
	], function(errCode, errStr, session, equip, splitList, gold) {
		if (errCode) {
			tiny.log.error("meltingEquip", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.splitList = splitList;
			outArgs.equip = equip;
			outArgs.gold = gold;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 反装备淬炼
var rvmeltingEquip = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, equipId;

	// 获取输入参数
	equipId = inArgs.equipId;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 反装备淬炼
		function(session, callback) {
			equipHandle.rvmeltingEquip(session.area, session.uuid, equipId, function(err, equip) {
				if (err || !equip) {
					callback(ErrCode.FAILURE, err, session);
				} else {
					callback(null, null, session, equip);
				}
			});
		}
	], function(errCode, errStr, session, equip) {
		if (errCode) {
			tiny.log.error("rvmeltingEquip", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.equip = equip;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 打造装备
var makeEquip = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs, scrollList;
	// 获取输入参数
	scrollList = JSON.parse(inArgs.scrollList);

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 制造装备
		function(session, callback) {
			equipHandle.makeEquip(session.area, session.uuid, scrollList, function(err, equipList) {
				if (err) {
					callback(ErrCode.EQUIP_CREATE_ERROR, err, session);
				} else {
					callback(null, null, session, equipList);
				}
			});
		}
	], function(errCode, errStr, session, equipList) {
		if (errCode) {
			tiny.log.error("makeEquip", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.equipList = equipList;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

// 开启背包格子
var unlockBag = function(inArgs, onResponse, current) {
	// 定义变量
	var outArgs;

	outArgs = {};
	async.waterfall([
		// 获取session
		function(callback) {
			tiny.redis.getSession(current.sessionId, function(err, session) {
				if (err) {
					callback(ErrCode.GET_SESSION_ERROR, err, {area : 'null', uuid : 'null'});
				} else {
					callback(null, session);
				}
			});
		},
		// 取背包
		function(session, callback) {
			equipHandle.getBagList(session.area, session.uuid, function(err, bagList) {
				if (err) {
					callback(ErrCode.GET_BAG_ERROR, err, session);
				} else {
					callback(null, session, bagList);
				}
			});
		},
		// 开启背包格子
		function(session, bagList, callback) {
			var diamond;
			diamond = equipHandle.unlockBag(bagList);
			if (diamond !== null) {
				callback(null, session, bagList, diamond);
			} else {
				callback(ErrCode.BAG_UNLOCK_ERROR, "unlockBag fail!", session);
			}
		},
		// 修改金钱
		function(session, bagList, diamond, callback) {
			if (diamond > 0) {
				playerHandle.modBaseInfo(session.area, session.uuid, playerHandle.addPlayerDiamond.bind(null, diamond), function(err) {
					if (err) {
						callback(ErrCode.SAVE_GOLD_ERROR, err, session);
					} else {
						callback(null, session, bagList);
					}
				});
			} else {
				callback(null, session, bagList);
			}
		},
		// 保存背包
		function(session, bagList, callback) {
			equipHandle.setBagList(session.area, session.uuid, bagList, function(err) {
				if (err) {
					callback(ErrCode.SAVE_BAG_ERROR, err, session);
				} else {
					callback(null, null, session, bagList.max);
				}
			});
		}
	], function(errCode, errStr, session, max) {
		if (errCode) {
			tiny.log.error("unlockBag", session.area, session.uuid, errCode, errStr);
			onResponse(errCode, current, inArgs, outArgs);
		} else {
			outArgs.max = max;
			onResponse(ErrCode.SUCCESS, current, inArgs, outArgs);
		}
	});
};

module.exports = {
"changeEquip" : changeEquip,
"upgradeEquipStar" : upgradeEquipStar,
"splitEquip" : splitEquip,
"meltingEquip" : meltingEquip,
"rvmeltingEquip" : rvmeltingEquip,
"makeEquip" : makeEquip,
"unlockBag" : unlockBag
};

