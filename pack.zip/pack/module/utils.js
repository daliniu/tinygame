var crypto = require('crypto');
var util = require('util');
var Chance = require('chance');
var Const = require('./const');
var tiny = require('../tiny');

module.exports.invokeCallback = function(cb) {
	if (!!cb && (typeof cb === 'function')) {
		cb.apply(null, Array.prototype.slice.call(arguments, 1));
	}
};

module.exports.args = function(_args) {
	var args = [], i;
	for (i = 0; i < _args.length; ++i) {
		args.push(_args[i]);
	}
	return args;
};

module.exports.getServerTypeID = function(typename) {
	var id;
	for (id in Const.PROCESS_NAME_TABLE) {
		if (Const.PROCESS_NAME_TABLE[id] === typename) {
			return parseInt(id, 10);
		}
	}
	return 0;
};

module.exports.getServerName = function(typeid) {
	var id;
	for (id in Const.PROCESS_NAME_TABLE) {
		if (Const.PROCESS_NAME_TABLE.hasOwnProperty(id) &&
			parseInt(id, 10) === typeid) {
			return Const.PROCESS_NAME_TABLE[id];
		}
	}
	return null;
};

// module.exports.print = function(module) {
// 	return function() {
// 		console.log(module + ' : ' + Array.prototype.slice.call(arguments, 0));
// 	};
// };

// module.exports.error = function(module) {
// 	return function() {
// 		console.error(module + ' : ' + Array.prototype.slice.call(arguments, 0));
// 	};
// };

module.exports.contains = function(str, setting, spl) {
	if (!str) {
		return false;
	}
	var ts = str.split(spl), i;
	for (i = 0; i < ts.length; ++i) {
		if (setting === ts[i]) {
			return true;
		}
	}
	return false;
};

var LimitMap = function(limit) {
	this.limit = limit || 10;
	this.map = {};
	this.keys = [];
};

LimitMap.prototype.set = function(key, value) {
	var map = this.map, keys = this.keys, firstKey;
	if (!map.hasOwnProperty(key)) {
		if (keys.length >= this.limit) {
			firstKey = keys.shift();
			delete map[firstKey];
		}
		keys.push(key);
	}
	map[key] = value;
};

LimitMap.prototype.get = function(key) {
	return this.map[key];
};

LimitMap.prototype.reset = function(limit) {
	this.limit = limit || 10;
	this.map = {};
	this.keys = [];
};

LimitMap.prototype.data = function() {
	return this.map;
};

module.exports.LimitMap = LimitMap;

var chance = new Chance();

// -9007199254740992 to 9007199254740992
module.exports.randomInt = function(min, max) {
	if (min > max) {
		tiny.log.error('randomInt', 'min can not be great than max', min, max);
		return 0;
	}
	return chance.integer({min: min, max: max});
};

module.exports.randomArray = function(array) {
	return array[module.exports.randomInt(0, array.length - 1)];
};

module.exports.randomArrayN = function(_array, n) {
	var i, newArray = [], tmp, r, array = _array.concat();
	if (array.length <= n) {
		return array;
	}
	for (i = 0; i < n; i++) {
		r = module.exports.randomInt(0, array.length - 1);
		tmp = array[i];
		array[i] = array[r];
		array[r] = tmp;
	}
	for (i = 0; i < n; i++) {
		newArray.push(array[i]);
	}
	return newArray;
};

module.exports.randomScope = function(scope) {
	var i,
		sum = 0,
		ret = 0,
		temp = 0;
	for (i = 0; i < scope.length; ++i) {
		sum = sum + scope[i][0];
	}
	ret = module.exports.randomInt(1, sum);
	for (i = 0; i < scope.length; ++i) {
		temp = temp + scope[i][0];
		if (ret <= temp) {
			return scope[i][1];
		}
	}
	return -1;
};

module.exports.setSeed = function(seed) {
	if (seed) {
		chance = new Chance(seed);
	} else {
		chance = new Chance();
	}
};

module.exports.redisKeyGen = function(area, uuid, name) {
	var area = Const.REDIS_NAME[area] || area,
		uuid = Const.REDIS_NAME[uuid] || uuid,
		name = Const.REDIS_NAME[name] || name;
	// if (Const.REDIS_NAME[name]) {
	return area + ':' + uuid + ':' + name;
	// }
	// tiny.log.error('redisKeyGen', 'key not found', area, uuid, name);
	// return undefined;
};


module.exports.transCurrent = function(current) {
	var transCurrent = {};
	transCurrent.sessionId = current.sessionId;
	transCurrent.msgId = current.msgId;
	transCurrent.serverName = current.serverName;
	transCurrent.funcName = current.funcName;
	transCurrent.clientReuqest = current.clientRequest;
	transCurrent.rid = current.rid;
	return transCurrent;
};

module.exports.checkUuid = function(uuid) {
	if (uuid === undefined || uuid.length === 0) {
		return false;
	}
	return true;
};

module.exports.getObject = function(obj) {
	if (obj) {
		var a = JSON.parse(obj.toString());
		if (a !== undefined || a !== null) {
			return a;
		}
	}
	return obj;
};

module.exports.setObject = function(obj) {
	// tiny.log.trace("setObject start 111111111");
	if (module.exports.isObject(obj) || module.exports.isArray(obj)) {
		var a = JSON.stringify(obj);
		// tiny.log.trace("setObject end 111111111", a);
		return a;
	}
	return obj.toString();
	// return obj;
};

module.exports.bindImp = function(obj, imp) {
	var funcName;
	if (obj && imp) {
		for (funcName in imp) {
			if (imp.hasOwnProperty(funcName)) {
				obj[funcName] = imp[funcName];
			}
		}
	}
};

module.exports.checkValue = function(value) {
	var valueInt = parseInt(value, 10);
	if (isNaN(valueInt)) {
		return 0;
	}
	return valueInt;
};

module.exports.addAPValue = function(value) {
	if (value > Const.SUPPLY_AP_MAX) {
		return Const.SUPPLY_AP_MAX;
	}
	if (value < Const.SUPPLY_AP_MIN) {
		return Const.SUPPLY_AP_MIN;
	}
	return value;
};

module.exports.addValue = function(value) {
	if (value > Const.PLAYER_ACTION_MAX) {
		return Const.PLAYER_ACTION_MAX;
	}
	if (value < Const.PLAYER_ACTION_MIN) {
		return Const.PLAYER_ACTION_MIN;
	}
	return value;
};

module.exports.jsonToArray = function(_json) {
	var A = [], i;
	for (i in _json) {
		if (_json.hasOwnProperty(i)) {
			A.push(_json[i]);
		}
	}
	return A;
};

module.exports.isObject = function(obj) {
	return Object.prototype.toString.call(obj) === '[object Object]';
};

module.exports.isNumber = function(obj) {
	return Object.prototype.toString.call(obj) === '[object Number]';
};

module.exports.isString = function(obj) {
	return Object.prototype.toString.call(obj) === '[object String]';
};

module.exports.isArray = function(obj) {
	return Object.prototype.toString.call(obj) === '[object Array]';
};

module.exports.getValueType = function(obj) {
	return Object.prototype.toString.call(obj);
};

module.exports.jsonIsEmpty = function(_json) {
	var i, isEmpty = true;
	for (i in _json) {
		if (_json.hasOwnProperty(i)) {
			isEmpty = false;
			break;
		}
	}
	return isEmpty;
};


module.exports.getDate = function() {
	return Date.now();
};

// ����key
module.exports.userAreaKey = function(userArea) {
	return userArea.area + "|" + userArea.uuid;
};

module.exports.userAreaKey2 = function(area, uuid) {
	return area + "|" + uuid;
};
